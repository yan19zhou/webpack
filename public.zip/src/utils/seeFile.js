import { getFileShow } from "@/api/my.js";
export function seeFile(file, model) {
  console.log(file, model, 22222)
  getFileShow({
    file,
    model
  }).then(res => {
    console.log(res, 222222222222)
    return res
  })
}