
export function timeGroup(time, type) {
  let date = new Date(time);
  switch (type) {
    case "年":
      return date.getFullYear();
    case "月":
      return date.getMonth() + 1;
    case "日":
      return parseInt(date.getFullYear()) + '-' + parseInt(date.getMonth() + 1) + '-' + parseInt(date.getDate());
  }
}

function formatFunc(str) {
  return str > 9 ? str : '0' + str
}