export function stringFormat(val) {
  return val.replace(/[\-\_\?]/g, '')
}