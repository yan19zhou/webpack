<!--
 * @Description: 
 * @Author: zhouy
 * @Date: 2021-10-20 11:16:28
 * @LastEditTime: 2021-10-28 14:37:38
 * @LastEditors: zhouy
-->
<script>
import getUser from "js/getUser.js";
import { getDict, getDicText } from "js/dict.js";
import Vue from "vue";
export default {
  onLaunch: function() {
    // 换肤
    const data = uni.getStorageSync("lifeData");
    data.appTheme && document.body.setAttribute("data-theme", data.appTheme);
    data.scaling && document.body.setAttribute("data-size", data.scaling.size);
    // 获取用户信息
    getUser();
    getDict();
    uni.getSystemInfo({
      success: e => {
        Vue.prototype.statusHeight = e.statusBarHeight;
        Vue.prototype.screenHeight = e.screenHeight;
        Vue.prototype.$getDict = getDicText;
        // // #ifdef H5
        // Vue.prototype.statusHeight += 30
        // // #endif
      },
    });
  },
  onShow: function() {
    console.log("App Show");
  },
  onHide: function() {
    console.log("App Hide");
  },
};
</script>

<style lang="scss">
/* 注意要写在第一行，同时给style标签加入lang="scss"属性 */
@import "uview-ui/index.scss";
@import "style/index.scss";
@import "/static/iconfont/iconfont.css";
.uni-tabbar__label {
  @include font_size(20rpx);
}
</style>
