<!--
 * @Description: 网格选择弹窗（现在放在task页展示)
 * @Author: zhouy
 * @Date: 2021-10-20 16:01:17
 * @LastEditTime: 2021-11-03 15:22:46
 * @LastEditors: zhouy
-->
<template>
  <u-modal
    v-model="show"
    @confirm="confirm"
    ref="uModal"
    class="select-grid"
    title="请选择操作网格"
    :confirm-style="{ background: 'linear-gradient(to right, #4287ff, #344dff)', color: '#fff', marginTop: '20px' }"
    confirm-color="#4287ff"
  >
    <view class="content">
      <u-radio-group v-model="checked" active-color="#4287ff" class="u-padding-left-20">
        <u-radio :name="grid.gridCode" shape="square" v-for="grid in codes" :key="grid.gridCode">{{ grid.gridName }}{{ grid.isAdmin == "1" ? "【主管网格】" : "【代管网格】" }}</u-radio>
      </u-radio-group>
    </view>
    <u-checkbox v-model="remember" :class="'remember-me u-row-center' + (remember ? ' color-gr' : '')" icon-size="16px" shape="circle" active-color="#4fc08d"
      >记住此次选择，下次默认该次操作</u-checkbox
    >
  </u-modal>
</template>

<script>
export default {
  name: "c-selectGrid",
  data() {
    return {
      show: false,
      checked: null,
      codes: [],
      remember: Boolean(localStorage.getItem("$gridRemember")) || true,
    };
  },
  mounted() {
    this.init();
  },
  methods: {
    init() {
      let gridCode = sessionStorage.getItem("$gridCode");
      let userInfo = JSON.parse(sessionStorage.getItem("$USER_INFO"));
      if (userInfo?.grids && userInfo?.grids?.length == 1) {
        gridCode = userInfo.grids[0].gridCode;
        sessionStorage.setItem("$gridCode", gridCode);
        return;
      }
      if (userInfo?.grids?.length > 1) {
        this.codes = userInfo.grids;
      } else {
        uni.showToast({ title: "未获取到用户网格信息!" });
        return;
      }
      if (this.remember == true) {
        gridCode = localStorage.getItem("$gridCode");
      }
      if (gridCode) {
        let checkedGrid = this.codes.filter((item) => {
          return item.gridCode == gridCode;
        });
        if (checkedGrid && this.show) {
          uni.showToast({ title: `已默认选择${checkedGrid[0].gridName},如需切换网格，请跳至 【我的】进行操作!`, duration: 3000, type: "primary" });
          sessionStorage.setItem("$gridCode", gridCode);
          return;
        }
      }
      this.checked = this.codes[0].gridCode;
    },
    confirm() {
      let checkedGrid = this.codes.filter((item) => {
        return item.gridCode == this.checked;
      });
      uni.showToast({
        title: `已选择${checkedGrid[0].gridName},如需切换网格，请跳至 【我的】进行操作!`,
        // position: 'bottom',
        duration: 3000,
        type: "primary",
      });
      sessionStorage.setItem("$gridCode", this.checked);
      localStorage.setItem("$gridRemember", this.remember);
      if (this.remember) {
        localStorage.setItem("$gridCode", this.checked);
        return;
      }
      localStorage.removeItem("$gridCode");
    },
  },
};
</script>

<style lang="scss" scoped>
.select-grid {
  .content {
    font-size: 14px;
    padding: 20px 24px;
    .van-radio {
      margin: 10px;
      padding-left: 20px;
    }
  }
}
.color-gr {
  /deep/ .u-checkbox__label {
    color: #4fc08d !important;
  }
}
</style>
<style lang="scss">
.select-grid {
  .van-action-bar-button--danger {
    background: linear-gradient(to right, #4287ff, #344dff);
  }
}
.remember-me {
  text-align: center;
  margin-top: -5px !important;
  font-size: 14px;
  width: 100%;
  text-align: center;
  .van-checkbox__icon {
    margin-top: -2px;
    margin-right: -2px;
  }
}
</style>
