<!--
 * @Description: 表单组件左侧图标,字段还未确定，字段确定之后更改showIcon方法展示
 * @Author: zhouy
 * @Date: 2021-10-09 09:52:36
 * @LastEditTime: 2021-11-03 15:22:37
 * @LastEditors: zhouy
-->
<template>
  <view>
    <text
      :class="['iconfont', icon.value !== 'is_image' ? 'yellow-color' : showEye ? 'colorEye' : '', coverIcon(icon)]"
      v-for="icon in strategy"
      :key="icon"
      @click="iconClick(icon)"
    ></text>
  </view>
</template>

<script>
import { showIcon } from "@/js/form_icon.js";

export default {
  name: "c-rightIcon",
  props: {
    strategy: Object|Array,
  },
  data() {
    return {
      showEye: false,
    };
  },
  methods: {
    coverIcon(icon) {
      return showIcon(icon);
    },
    iconClick(icon) {
      this.showEye = !this.showEye;
      this.$emit("iconHandler", icon);
    },
  },
};
</script>

<style lang="scss" scoped>
.colorEye {
  color: #e2661a;
}
</style>
