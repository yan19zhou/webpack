<!--
 * @Description: 顶部导航栏（uni-app取设备状态栏高度）
 * @Author: zhouy
 * @Date: 2021-10-22 09:48:27
 * @LastEditTime: 2021-11-09 15:53:49
 * @LastEditors: zhouy
-->
<template>
  <view>
    <view
      class="title-bar"
      :class="isFix ? '' : 'flx'"
      :style="{ 'padding-top': statusHeight + 'px', 'background-color': lifeData.appNav ? '#fff' : '#28333e' }"
    >
      <view class="top-box">
        <view
          class="top-module left-the"
          @tap="backPage"
          :style="{ color: lifeData.appNav ? '#333' : '#fff' }"
        >
          <u-icon
            v-if="isBack"
            top="2rpx"
            :style="{ color: lifeData.appNav ? '#282828' : '#fff' }"
            class="back-button"
            name="arrow-left"
          ></u-icon>
          <slot name="left-slot"></slot>
        </view>
        <view class="top-module center-the">
          <slot name="center-slot">{{ title }}</slot>
        </view>
        <view class="top-module right-the" :style="{color: lifeData.appNav ? '#4687F7' : '#25bdde'}">
          <slot name="right-slot"></slot>
        </view>
      </view>
    </view>
    <view
      class="title-bar"
      :style="{ height: 'calc(' + statusHeight + 'px + 80rpx)' }"
      v-if="!isFix"
    ></view>
  </view>
</template>

<script>
/**
 *
 * @description 顶部导航栏
 * slot:
 * 		left-slot:左侧插槽
 * 		center-solt:中间插槽
 * 		right-solt:右侧插槽
 * @property {String} 			bgColor				顶部导航栏颜色;默认值：#FFF
 * @property {String, Boolean} isBack				是否显示返回;默认值：true
 * @property {String, Boolean} isBackFunction		左侧插槽是否绑定返回事件;默认值：true
 * @property {String, Boolean} isFix				是否固定在顶部，不悬浮;默认值：true
 * @example
 * <top-navigation :isBack="true" :bgColor="themeColors.white"><template #center-slot><view class="mine-name">信息</view></template></top-navigation>
 *
 *   */
export default {
  name: "c-navTop",
  data() {
    return {
      lifeData: uni.getStorageSync("lifeData"),
    };
  },
  props: {
    bgColor: {
      type: String,
      default: "",
    },
    isBack: {
      type: [Boolean, String],
      default: true,
    },
    isBackFunction: {
      type: [Boolean, String],
      default: true,
    },
    isFix: {
      type: [Boolean, String],
      default: true,
    },
    title: {
      type: String,
      default: "",
    },
  },
  computed: {},
  methods: {
    backPage() {
      if (!this.isBackFunction) {
        return;
      }
      uni.navigateBack({
        delta: 1,
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.title-bar {
  width: 750rpx;
  height: auto;
  z-index: 20;
  // position: relative;
}
.top-box {
  height: auto;
  min-height: 80rpx;
  width: 750rpx;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 30rpx;
  line-height: 80rpx;
  box-sizing: border-box;

  .back-button {
    width: 40rpx;
    height: 40rpx;
    margin-right: 32rpx;
  }
  .top-module {
    min-width: 150rpx;
    width: auto;
    display: flex;
    align-items: center;
  }
  .left-the {
    @include font_size(32rpx);
    justify-content: flex-start;
  }
  .right-the {
    @include font_size(32rpx);
    justify-content: flex-end;
  }
  .center-the {
    justify-content: center;
    font-weight: 550;
    @include font_size(30rpx);
  }
}
.flx {
  position: fixed;
  top: 0rpx;
}
</style>
