<!--
 * @Description: 
 * @Author: zhouy
 * @Date: 2021-10-29 09:44:11
 * @LastEditTime: 2021-10-29 11:42:51
 * @LastEditors: zhouy
-->
<template>
  <view>
    <u-radio-group :shape="shape" :size="size" :width="width" :wrap="wrap" v-model="text" :activeColor="activeColor">
      <u-radio
        v-for="(i, index) in $getDict(item.attr_dictionary_code)"
        :disabled="item.disabled"
        :key="index"
        :name="i.key"
        >{{ i.title }}</u-radio
      >
    </u-radio-group>
  </view>
</template>

<script>
export default {
  name: "c-radio",
  props: {
    item: Object,
    value: String | Array,
  },
  data() {
    return {
      disabled: this.item.disabled || false,
      result: "",
      shape: this.item.shape || "circle",
      activeColor: this.item.activeColor || "#2979ff",
      size: this.item.size || 34,
      wrap: this.item.wrap || false,
      width: this.item.width || "auto",
    };
  },
  computed: {
    text: {
      get() {
        return this.value;
      },
      set(val) {
        this.$emit("input", val);
      },
    },
  },
};
</script>

<style lang="scss" scoped></style>
