<!--
 * @Description: 
 * @Author: zhouy
 * @Date: 2021-10-20 16:01:17
 * @LastEditTime: 2021-11-02 15:23:41
 * @LastEditors: zhouy
-->
<template>
  <view class="c-nav">
    <view>
      <slot name="left"></slot>
    </view>
    <view>
      <slot>{{ title }} </slot>
    </view>
    <view class="right"  @click="$emit('close')">
      <slot name="right">关闭</slot>
    </view>
  </view>
</template>

<script>
export default {
  props: {
    type: Number,
  },
  computed: {
    title() {
      switch (this.type) {
        case 0:
          return "确认地址";
        case 1:
          return "选择楼栋";
        case 2:
          return "选择房屋";
      }
      return "";
    },
  },
};
</script>

<style lang="scss" scoped>
.c-nav {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  view {
    text-align: center;
  }
  .right {
    text-align: right;
    margin-right: 20rpx;
  }
}
</style>
