<template>
  <view class="house-address">
    <view class="content">
      <view class="house-nav" v-if="data.length">
        <text
          :class="{ 'nav-active': item == floorActive }"
          v-for="item in data.length"
          :key="item"
          @click="scrollTo(item)"
          >{{ item }}楼</text
        >
      </view>
      <u-empty v-else text="没有数据！" class="abs-c" mode="list"></u-empty>
      <view class="floor-block">
        <view v-for="(item, index) in data" :key="item.sslc">
          <view :id="'view' + (index + 1)" class="floor-nav">{{ item.sslc }}楼</view>
          <view class="house-item">
            <view
              :class="{ 'item-active': fw.fwdm == houseActive }"
              v-for="fw in item.fwlist"
              :key="fw.fwdm"
              @click="fwChange(fw)"
            >
              {{ fw.fjhm }}
            </view>
          </view>
        </view>
      </view>
      <view class="floor-btn" @click="bindHouse">绑定房屋</view>
    </view>
  </view>
</template>

<script>
import { getHouseAddress } from "@/api/form/form";
export default {
  data() {
    return {
      address: {},
      floorActive: 1,
      data:[]
    };
  },
  methods: {
    bindHouse() {
      // 绑定房屋
      this.$emit("chooseHouse");
    },
    scrollTo(index) {
      this.floorActive = index;
      document.querySelector("#view" + index).scrollIntoView({
        behavior: "smooth",
        block: "center",
        inline: "nearest",
      });
    },
    fwChange(item) {
      this.houseActive = item.fwdm;
      this.$u.vuex("publicAddr.houseSelect", item);
    },
    async getHouse() {
      this.data = await getHouseAddress({ houseCode: this.publicAddr.buildSelect.code });
    },
  },
};
</script>

<style lang="scss" scoped>
.house-address {
  .content {
    .house-nav {
      background-color: $uni-bg-color-gray1;
      padding: 10px;
      position: fixed;
      top: 40px;
      width: 100%;
      text-align: left;
      text {
        margin-right: 10px;
      }
      .nav-active {
        color: $color-blue;
      }
    }
    .floor-block {
      color: $color-black;
      height: calc(100vh - 120px);
      margin-top: 80px;
      overflow-y: auto;
      padding: 0 15px;
      padding-bottom: 40px;
      .house-item {
        display: flex;
        flex-wrap: wrap;
        view {
          padding: 4px;
          margin: 2px 4px;
          border-radius: 5px;

          background-color: $uni-bg-color-gray1;
        }
        .item-active {
          background: $bg-page-blue;
          color: $color-white;
        }
      }
      .floor-nav {
        margin-top: 16px;
      }
    }
    .floor-btn {
      position: fixed;
      bottom: 0;
      width: 100%;
      height: 40px;
      line-height: 40px;
      z-index: 2;
      background: $bg-page-blue;
      color: $color-white;
      text-align: center;
    }
  }
}
</style>
