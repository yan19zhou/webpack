<!--
 * @Description: 公共地址
 * @Author: zhouy
 * @Date: 2021-10-20 16:01:17
 * @LastEditTime: 2021-11-09 15:56:57
 * @LastEditors: zhouy
-->
<template>
  <!-- 统一地址 ：建筑地址和房屋地址-->
  <view class="public-address">
    <u-input v-model="text" v-bind="$attrs" @click="openPop" />
    <u-popup v-model="popShow" mode="bottom" width="750rpx" height="calc(100vh - 80px)">
      <view>
        <!-- <NavTitle class="nav-address" :type="showType" @close="close" /> -->
        <c-navTop :isBack="false" :title="title" :isFix="false">
          <div slot="right-slot">
            <view class="right" @click="close">
              关闭
            </view>
          </div>
        </c-navTop>
        <Comfirm class="address-content" v-if="showType == 0" @comfirm="comfirm" />
        <HouseAddress class="address-content" v-if="showType == 2" @chooseHouse="chooseHouse" />
        <BuildingAddress class="address-content" v-if="showType == 1" @chooseBuilding="chooseBuilding" />
      </view>
    </u-popup>
  </view>
</template>

<script>
import BuildingAddress from "./buildingAddress";
import HouseAddress from "./houseAddress";
import Comfirm from "./comfirm";

import blurMixin from "@/js/blur.js";
export default {
  name: "c-publicAddress",
  inheritAttrs: false,
  components: {
    BuildingAddress,
    Comfirm,
    HouseAddress,
  },
  mixins: [blurMixin],
  props: {
    value: String,
  },

  data() {
    return {
      popShow: false,
      showType: 99,
      // 选择地址，1楼栋地址选择，2房屋地址选择
      text: this.value,
    };
  },

  computed: {
    title() {
      switch (this.showType) {
        case 0:
          return "确认地址";
        case 1:
          return "选择楼栋";
        case 2:
          return "选择房屋";
      }
      return "";
    },
  },
  methods: {
    openPop() {
      this.popShow = true;
      this.showType = 1;
    },
    close() {
      this.popShow = false;
      this.showType = 9999;
    },
    chooseBuilding() {
      console.log(this.$attrs);
      // 判断是楼栋还是房屋 根据模型返回数据确定怎么判断 zy
      const { type } = this.$attrs.item;
      if (type == "MODEL_BUILDING") {
        //楼栋地址直接打开确认地址
        this.showType = 0;
      } else if (type == "MODEL_HOUSE") {
        // 打开房屋地址
        this.showType = 2;
      }
    },
    chooseHouse() {
      // 打开确认弹窗
      this.showType = 0;
    },
    comfirm(v) {
      close();
      this.text = v.address;
      this.$emit("input", v.address);
      this.$emit("change");
    },
  },
  watch: {
    value(newValue) {
      this.text = newValue;
    },
  },
};
</script>

<style lang="scss" scoped>
.nav-address {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 40px;
  z-index: 9999;
}
.address-content {
  height: calc(100vh - 40px);
}
// /deep/.uni-scroll-view-content{
// transform: none !important;
// }
</style>
