<template>
  <view class="comfirm-address">
    <view class="addr-list">
      <view v-for="(item, key, index) in address" :key="index" center>
        <view class="custom-title">{{ getKey(key) }}：</view>
        <view class="custom-title comfirm-text">{{ item }}</view>
      </view>
    </view>
    <view class="floor-btn" @click="comfirm">确定</view>
  </view>
</template>

<script>
import { computed, reactive } from "vue";
import { useStore } from "vuex";
export default {
  computed: {
    address() {
      const { buildSelect, houseSelect } = this.publicAddr;
      if (buildSelect) {
        buildSelect.address = buildSelect.addr
        return buildSelect;
      }
      if (houseSelect && houseSelect.fwdm) {
        const { tydz: address, fwdm: code } = houseSelect;
        return { address, code };
      }
    },
  },
  methods: {
    comfirm() {
      emit("comfirm", this.address);
    },
    getKey(key) {
      switch (key) {
        case "address":
          return "地址";
        case "code":
          return "地址编码";
        case "street":
          return "所属街道";
        case "community":
          return "所属社区";
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.comfirm-address {
  .addr-list {
    height: calc(100vh - 102px);
    overflow-y: auto;
    padding: 0 15px;
    .van-cell {
      position: relative;
      .list-icon {
        color: $color-blue;
        position: absolute;
        right: 0;
        top: 50%;
        transform: translateY(-50%);
      }
      .comfirm-text {
        color: $color-deep;
      }
    }
  }
  .floor-btn {
    position: fixed;
    bottom: 0;
    width: 100%;
    height: 40px;
    line-height: 40px;
    z-index: 2;
    background: $bg-page-blue;
    color: $color-white;
  }
}
</style>
<style lang="scss">
.building-address {
  .van-nav-bar__title {
    font-weight: bold;
  }
  .van-search__action {
    background: $bg-page-blue;
    color: $color-white;
  }
  .addr-list {
    .van-cell__title {
      display: flex;
      align-items: center;
    }
    .van-cell {
      .van-cell__value {
        padding: 8px 26px 8px 0;
        .van-icon {
          font-size: 14px;
        }
      }
    }
  }
}
</style>
