<template>
  <view class="content building-address">
    <u-search
      placeholder="请输入搜索关键词"
      v-model="keyword"
      class="building-search"
      :show-action="true"
      action-text="查询"
      @search="getBuildAddress"
    ></u-search>
    <scroll-view scroll-y="true" style="height: 300rpx;">
      <view class="addr-list" v-if="list.length">
        <u-cell-group>
          <u-cell-item v-for="item in list" :key="item.code" center @click="chooseItem(item)" :arrow="false">
            <text slot="title" class="custom-title">{{ item.addr }}</text>
            <u-icon slot="right-icon" v-show="activeCode == item.code" name="checkbox-mark" class="list-icon" />
          </u-cell-item>
        </u-cell-group>
        <u-loadmore :status="status" :load-text="loadText" />
      </view>
      <u-empty v-else class="abs-c" mode="list" text="没有数据"></u-empty>
    </scroll-view>
    <view class="confrim-btn floor-btn" @click="bindBuilding">
      绑定楼栋
    </view>
  </view>
</template>

<script>
import { getBuildingAddress } from "@/api/form/form";
export default {
  data() {
    return {
      status: "loadmore",
      loadText: {
        loadmore: "轻轻上拉",
        loading: "努力加载中",
        nomore: "实在没有了",
      },
      page: 1,
      list: [{ code: 1, addr: "jiananxincun" }],
      activeCode: "",
      keyword: "",
      active: null,
    };
  },
  methods: {
    onReachBottom() {
      if (this.page >= 3) return;
      this.status = "loading";
      this.page = ++this.page;
      setTimeout(() => {
        this.list += 10;
        if (this.page >= 3) this.status = "nomore";
        else this.status = "loading";
      }, 2000);
    },
  },
  created() {
    this.getBuildAddress();
  },
  methods: {
    getBuildAddress() {
      /* 请求楼栋列表 */
      if (this.publicAddr.buildingData) {
        this.list = this.publicAddr.buildingData;
      } else {
        getBuildingAddress({ sword: this.keyword || "宝安" }).then(res => {
          this.list = res;
          this.$u.vuex("publicAddr.buildingData", res);
        });
      }
    },
    chooseItem(item) {
      /* 列表选中 */
      this.activeCode = item.code;
      this.active = item;
      this.$u.vuex("publicAddr.buildSelect", item);
    },
    bindBuilding() {
      this.$emit("chooseBuilding", this.active);
    },
  },
};
</script>

<style lang="scss" scoped>
.building-address {
  //
  .main {
    display: grid;
    grid-template-rows: repeat(3, 40px 1fr 40px);
    margin-top: 40px;
    background: rgb(59, 46, 46);
  }

  .building-search {
    position: fixed;
     /* top: 40px; */
    left: 0;
    width: 100vw;
    height: 40px;
    z-index: 999;
  }
  .addr-list {
    height: calc(100vh - 120px);
    margin-top: 80px;
    overflow-y: auto;
    padding: 0 15px;
    padding-bottom: 40px;

    .list-icon {
      color: $color-blue;
      position: absolute;
      right: 0;
      top: 50%;
      transform: translateY(-50%);
    }
  }
  .floor-btn {
    position: absolute;
    bottom: 0;
    width: 100%;
    height: 40px;
    line-height: 40px;
    z-index: 2;
    background: $bg-page-blue;
    color: $color-white;
    text-align: center;
  }
}
</style>
<style lang="scss">
.building-address {
  .van-nav-bar__title {
    font-weight: bold;
  }
  .van-search__action {
    background: $bg-page-blue;
    color: $color-white;
  }
  .addr-list {
    .van-cell__title {
      display: flex;
      align-items: center;
    }
    .van-cell {
      padding: 0 !important;
      .van-cell__value {
        padding: 8px 26px 8px 0;
        .van-icon {
          font-size: 14px;
        }
      }
    }
  }
}
</style>
