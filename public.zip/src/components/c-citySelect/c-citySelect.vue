<!--
 * @Description: uview的城市选择器(改写一下适配本项目)
 * @Author: zhouy
 * @Date: 2021-10-27 09:50:46
 * @LastEditTime: 2021-10-29 09:15:52
 * @LastEditors: zhouy
-->
<template>
  <view class="u-demo">
    <view class="u-demo-wrap">
      <view class="u-demo-area">
        <u-input v-model="input" :placeholder="item.view_placeholder"   v-bind="$attrs" @click="show = true" />
        <city-select v-model="show" :areaCode="areaCode" @city-change="cityChange"></city-select>
      </view>
    </view>
  </view>
</template>

<script>
import UInput from "../../uview-ui/components/u-input/u-input.vue";
import citySelect from "./u-city-select.vue";
export default {
  inheritAttrs:false,
  name: "c-citySelect",
  props: {
    value: {
      type: String,
      default: "",
    },
    item:{
      type:Object,
      default:()=>{}
    }
  },
  computed: {
    areaCode() {
      // 数据返显
      return this.value.split(",") ||[]
    }
  },
  components: {
    citySelect,
    UInput,
  },
  data() {
    return {
      height: 30,
      bgColor: this.$u.color.bgColor,
      marginTop: 30,
      marginBottom: 30,
      show: false,
      input: "",
    };
  },
  mounted() {
    console.log("this.$attrs", this.$attrs);
  },
  methods: {
    cityChange(e) {
      console.log(e);
      this.input = e.province.label + "-" + e.city.label + "-" + e.area.label;
      // 区域编码传值
      this.$emit("input", [e.province.value, e.city.value, e.area.value].join(","));
    },
  },
};
</script>

<style scoped>
.btn-wrap {
  margin: 100rpx 30rpx;
}
</style>
