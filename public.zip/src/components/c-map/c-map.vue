<!--
 * @Description: 表单--地图组件--主要用于部件中取定位
 * @Author: zhouy
 * @Date: 2021-10-20 16:01:17
 * @LastEditTime: 2021-10-27 17:38:19
 * @LastEditors: zhouy
-->
<template>
  <view>
    <u-collapse class="map-com">
      <u-collapse-item title="地理信息" open>
        <view class="map-wrap">
          <view id="mapComponent"></view>
          <text class="my-locate" @click="showLocation"></text>
        </view>
      </u-collapse-item>
    </u-collapse>
  </view>
</template>

<script>
import { Map } from "@/pages/map/js/map";

export default {
  name: "c-map",
  props: {
    type: String,
    info: Object,
    modelValue: String,
  },
  data() {
    return {
      map: null,
      isShowLocation: false,
    };
  },
  created() {
    let options = {
      container: "mapComponent",
      moveCenter: true,
      initCoordinate: this.modelValue,
    };
    this.map = new Map(options);
    this.map.createMap().then(res => {
      if (res) {
        this.mapInstance = res;
        this.map.drawGridArea("CGCS2000");
      }
    });
    uni.$on("getpoint", evt => {
      // 把获取的坐标点传给form
      this.$emit("input", evt);
    });
  },
  methods: {
    showLocation() {
      this.isShowLocation = !this.isShowLocation;
      this.isShowLocation && this.map.showLocation(this.isShowLocation);
      console.log(this.mapInstance.extent.getCenter());
    },
  },
};
</script>

<style lang="scss" scoped>
.map-com {
  width: 95%;
  margin: 5px auto 20px auto !important;
  border-radius: 5px;
  box-shadow: 0px 2px 5px #ccc;
  .map-wrap {
    width: 100%;
    height: 100%;
    position: relative;
    #mapComponent {
      width: 100%;
      height: 200px;
    }
    .my-locate {
      display: inline-block;
      height: 40px;
      width: 40px;
      position: absolute;
      left: 20px;
      bottom: 20px;
      background: rgba(255, 255, 255, 0) url(/static/images/map_icon.png) no-repeat 8px -132px;
      border-radius: 6px;
      background-size: 48px 329px;
      -webkit-box-shadow: none;
      box-shadow: none;
    }
  }
}
</style>
.<style lang="scss">
.map-com {
  .van-cell__title {
    color: $color-green;
  }
  .van-collapse-item__content {
    padding-top: 0;
    padding-bottom: 0;
  }
}
</style>
