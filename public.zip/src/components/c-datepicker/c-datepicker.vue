<!--
 * @Description: 时间选择器
 * @Author: zhouy
 * @Date: 2021-11-02 09:56:05
 * @LastEditTime: 2021-11-02 11:56:30
 * @LastEditors: zhouy
-->
<template>
  <div>
    <u-input :value="value" :placeholder="item.view_placeholder" v-bind="$attrs" @click="show = true" />
    <u-picker mode="time" v-model="show" :default-time="value" :params="params" @confirm="confirm"></u-picker>
  </div>
</template>

<script>
export default {
  inheritAttrs: false,
  name: "c-datepicker",
  props: {
    value: {
      type: String,
      default: "",
    },
    formatter: {
      type: String,
      default: "YYYY-MM-DD hh:mm:ss",
    },
    item: {
      type: Object,
      default: () => {},
    },
    params: {
      type: Object,
      default: () => ({ year: true, month: true, day: true, hour: true, minute: true, second: false }),
    },
  },
  data() {
    return {
      show: false,
    };
  },
  methods: {
    confirm(e) {
      let str = "";
      for (const key in e) {
        if (Object.hasOwnProperty.call(e, key)) {
          const value = e[key];
          str += `${value}`;
          switch (key) {
            case "year":
              str += e.month ? "-" : "";
              break;
            case "month":
              str += e.day ? "-" : "";
              break;
            case "day":
              str += " ";
              break;
            case "hour":
              str += e.minute ? ":" : "";
              break;
            case "minute":
              str += e.second ? ":" : "";
              break;
            case "second":
              break;
            default:
              break;
          }
        }
      }
      this.$emit("input", str);
    },
  },
};
</script>

<style lang="scss" scoped></style>
