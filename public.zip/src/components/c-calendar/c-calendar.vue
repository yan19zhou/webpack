<!--
 * @Description:  日历
 * @Author: zhouy
 * @Date: 2021-10-28 14:05:16
 * @LastEditTime: 2021-10-29 09:18:16
 * @LastEditors: zhouy
-->
<template>
  <view>
    <u-input v-model="text" readonly @click="show = !show" />
    <u-calendar v-model="show" :mode="mode" @change="confirm"></u-calendar>
  </view>
</template>

<script>
export default {
  name: "c-calendar",
  props: {
    item: Object,
    value: String | Array,
  },
  data() {
    return {
      show: false,
      text: "",
      mode:this.item.mode||'date'
    };
  },
  methods: {
    confirm(e) {
      console.log(e);
      this.$emit("input", e.result);
      this.text = e.result
    },
  },

};
</script>

<style lang="scss" scoped></style>
