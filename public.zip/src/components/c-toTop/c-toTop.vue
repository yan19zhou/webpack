<!--
 * @Description: 返回顶部按钮
 * @Author: zhouy
 * @Date: 2021-10-20 16:01:17
 * @LastEditTime: 2021-11-03 15:23:49
 * @LastEditors: zhouy
-->
<template>
  <u-button
    icon="back-top"
    type="success"
    class="backTop"
    @click="backTop"
    v-show="flag_scroll"
  />
</template>

<script>
export default {
  name:"c-toTop",
  props: {
    ele: {
      type: String,
      default: "",
    },
  },
  data() {
    return {
      flag_scroll: false,
      timer: null,
    };
  },
  mounted() {
    window.addEventListener("scroll", this.handleScroll, true);
  },
  methods: {
    handleScroll() {
      if (this.ele && document.querySelector("#" + this.ele)) {
        let scrollTop = document.querySelector("#" + this.ele).scrollTop;
        if (scrollTop > 100) {
          this.flag_scroll = true;
        } else {
          this.flag_scroll = false;
        }
      }
    },
    backTop() {
      clearInterval(this.timers);
      // 重新点击回到顶部。清除之前的定时器
      if (this.timer != null) {
        clearInterval(this.timer);
      }
      this.timer = setInterval(() => {
        this.scrollToTopTimer();
      }, 20);
    },
    // 平缓滚动的事件
    scrollToTopTimer() {
      let scrollTop = document.querySelector("#" + this.ele).scrollTop;
      if (scrollTop > 0) {
        scrollTop -= 100;
        if (scrollTop <= 50) {
          scrollTop = 0;
          clearInterval(this.timer);
        }
      }
      document.querySelector("#" + this.ele).scrollTop = scrollTop;
    },
  },
  beforeUnmount() {
    window.removeEventListener("scroll", this.handleScroll);
    clearInterval(this.timer);
  },
};
</script>

<style lang="scss" scoped>
.backTop {
  width: 40px;
  height: 40px;
}
</style>