<!--
 * @Description: 图片上传展示组件
    与姚贤丰商量的逻辑直接图片转换成base64传给后端
 * @Author: zhouy
 * @Date: 2021-10-20 16:01:17
 * @LastEditTime: 2021-11-02 09:47:45
 * @LastEditors: zhouy
-->
<template>
  <!-- 拍照组件 -->
  <view>
    <u-field :label="item.view_label" disabled>
      <template #right>
        <c-rightIcon :strategy="item.strategy" />
      </template>
    </u-field>
    <view class="uploader">
      <u-upload
        :header="header"
        :action="action"
        @on-change="change"
        @on-remove="remove"
        @on-choose-complete="chooseComplete"
        :file-list="fileList"
        width="140"
        height="140"
      ></u-upload>
    </view>
  </view>
</template>

<script>
import { IMG_API, API } from "@/api/api-config.js";
import {upload, deleteImage} from "@/api/form/image.js"
export default {
  name: "c-photo",
  props: {
    item: Object,
  },
  data() {
    return {
      header: { Authorization: sessionStorage.getItem("token") },
      fileList: [],
      showAll: false,
      action: `${API}/form/component/upload`,
      list: [],
      showUploadList: false,
    };
  },
  methods: {
    change(res, index, lists, name) {
      //上传结果
      console.log("上传结果", res, index, lists, name);
      console.log("fileList",this.fileList);
    },
    remove(index, lists, name) {
      console.log("移除", index, lists, name);
      // 删除
     // deleteImage(model, uuid, id);
    },
   async chooseComplete(lists, name) {
      // 选择完成之后上传
      let params = await this.urlTobase64(lists);
      await upload(params);
      console.log("listChange",lists, name);
    },
    async urlTobase64(url) {
      // 图片转成base64
      let res = await new Promise(resolve => {
        uni.request({
          url: url, //要转换的url
          method: "GET",
          responseType: "arraybuffer",
          success: res => {
            resolve(res);
          },
        });
      });
      let base64 = uni.arrayBufferToBase64(res.data);
      base64 = `data:image/jpeg;base64,${base64}`; //要加上data:image/jpeg;base64, 这个前缀才能显示
      console.log(base64);
    },
  },
};
</script>

<style lang="scss" scoped>
.uploader {
  position: relative;
  padding: 0 10px;
  box-sizing: border-box;
}
</style>
