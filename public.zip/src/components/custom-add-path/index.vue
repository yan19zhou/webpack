<!--
 * @Description: 采查路径选择
 * @Author: zhouy
 * @Date: 2021-10-20 16:01:17
 * @LastEditTime: 2021-10-27 09:13:16
 * @LastEditors: zhouy
-->
<template>
  <van-dialog
    v-model:show="show"
    class="custom-add-path"
    :showConfirmButton="false"
    @open="opened"
  >
    <view class="add-wrap">
      <p class="title">
        {{
          contentType == "model"
            ? "请选择新增类型"
            : `请选择新增${addModelTitle}所属${chooseModelTitle}`
        }}
      </p>
      <view class="content model" v-if="contentType == 'model'">
        <view
          :class="['btn', active == index ? 'activeModel' : '']"
          v-for="(type, index) in modelTypes"
          :key="type.key"
          @click="checkType(index, type)"
        >
          {{ type.title }}
        </view>
      </view>
      <view
        class="content"
        v-else-if="list.length"
        :style="{ height: Math.ceil(list.length / 3) * 40 + 'px' }"
      >
        <view
          :class="['btn', active == index ? 'activeModel' : '']"
          v-for="(model, index) in list"
          :key="model.key"
          @click="checkModel(index, model)"
        >
          {{ model.title }}
        </view>
      </view>
      <view class="content" v-else>
        <p class="no-data">
          {{
            `${chooseModelTitle}数据为空，请先添加${chooseModelTitle}数据...`
          }}
        </p>
      </view>
      <view class="footer-btns">
        <view class="cancel" @click="cancel">取消</view>
        <view class="comfirm" @click="comfirm">{{ comfirmText }}</view>
      </view>
    </view>
  </van-dialog>
</template>

<script>
import { reactive, toRefs } from "vue";
import { getModelData } from "./getData.js";
export default {
  name:"custom-add-path",
  props: {
    isShow: Boolean,
    pId: String,
  },
  computed: {
    show() {
      return this.isShow;
    },
  },
  setup(props, { emit }) {
    const state = reactive({
      active: 0,
      comfirmText: "下一步",
      contentType: "model",
      modelTypes: [
        { key: "MODEL_UNIT", title: "单元" },
        { key: "MODEL_FLOOR", title: "楼层" },
        { key: "MODEL_HOUSE", title: "房屋" },
      ],
      currentItem: null,
      list: [],
      cancel() {
        emit("cancel");
      },
      queryParams: {
        model: "",
        parent: "",
        parentId: "",
      },
      addModelTitle: "",
      chooseModelTitle: "",
      parents: [],
      currentIndex: 0, //在路径第几层
      pathList: [{ key: "MODEL_UNIT", title: "单元" }],
      comfirm() {
        // 下一步
        let pathLen = state.pathList.length;
        // 点击完成
        if (
          pathLen == state.currentIndex + 1 ||
          (state.currentIndex > 0 && !state.list.length)
        ) {
          let address = "";
          if (!state.list.length) {
            address = state.parents.map((item) => item.title).join(",");
          } else {
            address = state.parents
              .map((item) => item.title)
              .concat([state.currentItem.title])
              .join(",");
          }
          let item = {
            type: "add",
            model: state.pathList[state.currentIndex].key,
            uuid: "",
            pid: state.currentIndex == 0 ? props.pId : state.currentItem.key,
            parent:
              state.currentIndex == 0
                ? "MODEL_BUILDING"
                : state.pathList[state.currentIndex - 1].key,
            address: address,
          };
          emit("refreshModel", item);
          return;
        }
        state.contentType == "model" && (state.contentType = "path");

        // 标题
        state.chooseModelTitle = state.pathList[state.currentIndex].title;
        if (pathLen - 1 == state.currentIndex + 1) {
          // 到路径的最后一层显示完成
          state.comfirmText = "完成";
        }
        state.queryParams.model = state.pathList[state.currentIndex].key;
        if (state.currentIndex == 0) {
          state.queryParams.parent = "MODEL_BUILDING";
          state.queryParams.parentId = props.pId;
        } else {
          state.parents.push(state.currentItem);
          state.queryParams.parent = state.pathList[state.currentIndex - 1].key;
          state.queryParams.parentId = state.currentItem.key;
        }
        getModelData(state);
      },
      checkType(index, item) {
        state.checkModel(index, item);
        state.addModelTitle = item.title;
        state.pathList = state.modelTypes.slice(0, index + 1);
          state.comfirmText = state.pathList.length == 1 && "完成"||"下一步";
      },
      checkModel(index, item) {
        state.active = index;
        state.currentItem = item;
      },
      opened() {
        // 打开弹窗重置显示
        state.contentType = "model";
        state.comfirmText = "下一步";
        state.currentItem = state.modelTypes[0];
        state.currentIndex = 0;
        state.active = 0;
        state.parents = [];
      },
    });

    return { ...toRefs(state) };
  },
};
</script>

<style lang="scss" scoped>
.custom-add-path {
  .add-wrap {
    width: 325px;
    min-height: 154px;
    background: #ffffff;
    padding: 16px 16px 20px 20px;
    box-sizing: border-box;
    .title {
      text-align: left;
      margin-bottom: 20px;
    }
    .content {
      display: flex;
      max-height: 50vh;
      overflow-y: auto;
      .btn {
        // width: 72px;
        // height: 32px;
        // line-height: 32px;
        padding: 4px 8px;
        margin-right: 8px;
        margin-bottom: 8px;
        border: 0.5px solid #b0b0b0;
        border-radius: 17px;
      }
      .activeModel {
        background: $color-blue;
        color: $color-white;
      }
      .no-data {
        color: $uni-text-color-grey;
        font-size: 13px;
        text-align: center;
      }
    }
    .model {
      .btn {
        width: 72px;
        height: 32px;
        padding: 0;
        line-height: 32px;
      }
    }
    .footer-btns {
      position: absolute;
      bottom: 20px;
      right: 16px;
      display: flex;
      .comfirm {
        margin-left: 20px;
        color: $color-blue;
      }
    }
  }
}
</style>
<style lang="scss">
.custom-add-path {
  border-radius: 0 !important;
}
</style>