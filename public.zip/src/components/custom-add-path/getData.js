import { getPathData } from "@/api/form/components.js";

/* 模型列表 */
export const getModelData = (state) => {
  getPathData(state.queryParams).then((res) => {
    console.log(res);
    if (res) {
      state.list = res;
      // 默认选中第一个
      if (res.length) {
        state.currentItem = res[0];
        state.active = 0;
        state.currentIndex++;
      }
    }
  });
};
