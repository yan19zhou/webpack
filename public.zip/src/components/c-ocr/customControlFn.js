/*
 * @Description:表单--- OCR组件
 * @Author: zhouy
 * @Date: 2021-10-20 16:01:16
 * @LastEditTime: 2021-10-27 09:32:31
 * @LastEditors: zhouy
 */

import {  Toast } from "vant";
import wx from 'wx-jsapi';
import ajax from '../../api/ajax';

/*
 * customControl#ocrInput 证件号码(人口)
 * ocr组件使用微信api选择本地图片或者拍照，请求后端接口解析图片获取内容赋值给表单
 * @params
 * @attr: "Cardno" 字段名  "证件号"
 * @imageData: 图片地址
 * @model : 模型名称 "MODEL_POPULATION"
 */
export function getOcrImg(formData,field,modelName) {
  wx.chooseImage({
    count: 1, // 默认9
    sizeType: ["compressed"], // 可以指定是原图还是压缩图，默认二者都有
    // sourceType: ['camera'], // 可以指定来源是相册还是相机，默认二者都有
    success: function(res) {
      var localIds = res.localIds[0]; // 返回选定照片的本地ID列表，localId可以作为img标签的src属性显示图片
      wx.getLocalImgData({
        localId: localIds, //图片的localID
        success: function(res) {
          var localData = res.localData; // localData是图片的base64数据，可以用img标签显示
          if (localData.indexOf("data:image") != 0) {
            //判断是否有这样的头部
            localData = "data:image/jpeg;base64," + localData;
          }
          localData = localData
            .replace(/\r|\n/g, "")
            .replace("data:image/jgp", "data:image/jpeg");
            ajax.ajaxJson(
            process.env.VUE_APP_COMMON_CONTEXT + `/api/ocr/idcard`,
            { model: modelName, attr: field, imageData: localData },
            function(data) {
              if (data.code == 200 && data.data) {
                if (data.data.hasData) {
                  let person = data.data.data;
                  if (person != null) {
                    if (modelName == "MODEL_POPULATION_DECLARE") {
                      delete person.uuid;
                    }
                  }
                  //表单赋值证件号从数据库中取得的数据
                  formData=person;
                } else {
                    formData[field] = data.data.result;
                }
              }
              //data.data返回的数据:
              //{
              //	data:{...},				//对应result证件号从数据库中取得的记录。
              //	result:"",				//OCR识别到文本数据。
              //	HasData:[true|false]	//对应data中不为null时为true，否则为false
              //}
            },
            function(err) {
              Toast( "OCR服务请求错误错误原因：" + err);
            }
          );
        },
      });
    },
  });
}
