<!--
 * @Description: 粗糙的一个下拉组件
 * @Author: zhouy
 * @Date: 2021-10-20 15:25:25
 * @LastEditTime: 2021-11-18 14:40:12
 * @LastEditors: zhouy
-->
<template>
  <view class="c-dropdown">
    <u-mask
      :custom-style="{ background: 'rgba(0, 0, 0, 0)' }"
      :maskClickAble="true"
      :z-index="98"
      :show="showList"
      @click="changeDisplay"
    ></u-mask>
    <view @click="changeDisplay" ref="btnWarp" class="btnWarp">
      <slot name="reference"
        ><button>{{ text }}</button></slot
      >
    </view>
    <view
      class="list"
      ref="listWarp"
      :style="{ left: offsetLeft + 'px', top: offsetTop + 'px', height: height + 'px' }"
    >
      <slot>
        <view
          :class="['item', activeIndex == index ? 'active' : '']"
          v-for="(item, index) in options"
          :key="item.value"
          @click="selected(item, index)"
          >{{ item.label }}
          <!-- <u-icon v-show="activeIndex == index" name="checkbox-mark" class="active-icon"></u-icon> -->
        </view>
      </slot>
    </view>
  </view>
</template>

<script>
export default {
  name: "c-dropdown",
  props: {
    options: {
      type: Array,
      default: () => [],
    },
    text: {
      type: String,
      default: "默认",
    },
    value: {
      type: String | Object,
      default: null,
    },
  },
  data() {
    return {
      showList: false,
      activeIndex: null,
      offsetTop: 0,
      offsetLeft: 0,
      height: 0,
    };
  },
  methods: {
    selected(item, index) {
      this.activeIndex = index;
      this.$emit("input", item);
      this.listHide();
    },
    listHide() {
      this.showList = false;
      this.height = 0;
    },
    changeDisplay(e) {
      this.showList = !this.showList;
      if (this.showList) {
        /* 
          获取按钮外包元素的定位，用来给下拉列表定位
        */
        this.$u.getRect(".btnWarp").then(data => {
          this.offsetTop = data.top + data.height + 10;
          this.$u.getRect(".list").then(res => {
            this.offsetLeft = data.left - (res.width - data.width) / 2;
          });
        });
        this.height = this.options.length * 40;
      } else {
        this.height = 0;
      }
    },
  },
  watch: {
    value(newValue) {
      if (this.showList) {
        this.listHide();
      }
      if (Object.keys(newValue).length) {
        this.activeIndex = this.options.findIndex(item => item.value == newValue.value);
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.c-dropdown {
  .list {
    min-width: 120px;
    position: fixed;
    z-index: 99;
    padding: 0 8px;
    background: #fff;
    box-shadow: 0 2px 5px #ccc;
    border-radius: 4px;
    transition: height 0.3s;
    overflow: hidden;
    transform-origin: 50% 0 0;

    .item {
      &:first-child {
        margin-top: 8px;
      }
      padding: 8px 4px;
      white-space: nowrap;

      .active-icon {
        color: $color-blue;
      }
    }

    .active {
      color: $color-blue;
      font-weight: bold;
    }
  }
}
</style>
