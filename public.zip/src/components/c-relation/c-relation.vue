<!--
 * @Description: 表单---关系组件，在表单中显示关联上级字段信息
 * @Author: zhouy
 * @Date: 2021-10-09 09:52:36
 * @LastEditTime: 2021-10-27 16:38:47
 * @LastEditors: zhouy
-->
<template>
  <view class="relation-components">
    <view v-for="relation in list" :key="relation.model">
      <!-- <view class="item-title">{{ relation.model_name }}</view> -->
      <u-field
        v-model="field[relation.name]"
        readonly
        :label="relation.base.describe"
        :type="type"
        v-for="(field, index) in relation.$result"
        :key="index"
        class="relation-field"
      />
    </view>
  </view>
</template>

<script>
import { getRelationData } from "@/api/form/components.js";
export default {
  name: "c-relation",
  props: {
    item: Object,
  },
  data() {
    return {
       list: [] 
    }
  },
  created () {
    this.initData(this.item.default_value, this.ids.from, this.ids.fromKey);
  },
  methods: {
    initData(value, parent_key, parent_id) {
      let params = {
        default_value: value,
        parent: parent_key,
        parentId: parent_id,
      };
      getRelationData(params).then(res => {
        console.log(res);
        this.list = res;
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.relation-components {
  text-align: left;
  padding: 0 0.05rem;
  border-left: 16px solid #b3b3b3;
  .item-title {
    // color: $color-blue;
    font-size: 12px;
    position: relative;
    // padding-left: 13px;
    // &::before {
    //   content: "";
    //   position: absolute;
    //   left: 0;
    //   top: 3px;
    //   width: 3px;
    //   height: 12px;
    //   background: $color-blue;
    // }
  }
  .relation-field {
    padding-left: 0 !important;
    // border-bottom: 1px solid #b3b3b3;
  }
}
</style>
