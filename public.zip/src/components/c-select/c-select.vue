<!--
 * @Description: u-select 多列级联不能满足本项目业务需求
 * @Author: zhouy
 * @Date: 2021-10-28 14:05:16
 * @LastEditTime: 2021-11-03 14:28:44
 * @LastEditors: zhouy
-->
<template>
  <view class="c-select">
    <u-input v-model="text" readonly @click="show = !show" />
    <u-select
      v-model="show"
      :list="list"
      :default-value="item.defaultValue"
      value-name="key"
      mode="mutil-column-auto"
      label-name="title"
      @confirm="confirm"
    ></u-select>
  </view>
</template>

<script>
export default {
  name: "c-select",
  props: {
    item: Object,
    value: String | Array,
  },
  data() {
    return {
      show: false,
      text: "",
      defaultValue: [0],
      list: [],
    };
  },
  mounted() {
    this.initData();
  },
  methods: {
    initData() {
      !this.list.length && (this.list = this.$getDict(this.item.attr_dictionary_code));
      if (this.value) {
        let codes = this.value.split(",");
        this.defaultValue = this.setDefault(this.list, codes);
        console.log(this.defaultValue);
      } else {
        this.text = "";
      }
    },
    confirm(e) {
      let value = e.map(item => item.value).join(",");
      this.text = e.map(item => item.label).join(",");
      this.$emit("input", value);
    },

    setDefault(list, codes) {
      let indexs = [];
      const getIndexs = function(list) {
        if (!list.length || !codes) return;
        let len = indexs.length;
        list.map((v, i) => {
          if (v.key == codes[len]) {
            indexs.push(i);
            if (len < codes.length && v.children.length) {
              getIndexs(v.children);
            }
          }
        });
      };
      getIndexs(list);
      return indexs;
    },
  },
};
</script>

<style lang="scss" scoped>
.c-select{
  width: 100%;
}
</style>
