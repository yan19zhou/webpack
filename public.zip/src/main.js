/*
 * @Description:
 * @Author: zhouy
 * @Date: 2021-10-20 11:16:28
 * @LastEditTime: 2021-11-19 11:37:24
 * @LastEditors: zhouy
 */

import Vue from "vue";
import App from "./App";
import { getUrlParams } from "utils/utils";
import uView from "uview-ui";
Vue.use(uView);
import CustomComponents from "js/customComponents";
Vue.use(CustomComponents);
Vue.config.productionTip = false;
import store from "@/store";
// 初始化微信api
import "./js/initWX";

// 引入uView提供的对vuex的简写法文件
let vuexStore = require("@/store/$u.mixin.js");
Vue.mixin(vuexStore);

let USERKEY = getUrlParams(window.location.href, "userkey");
  USERKEY =
   "eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2Mzk4ODUxMDcsImlhdCI6MTYzNzI5MzEwNywidXNlcmluZm8iOiJ7XCJhdmF0YXJcIjpcIlwiLFwiY29ycENvZGVcIjpcIldHWVwiLFwiY3JlYXRlQnlcIjpcIlwiLFwiZW1haWxcIjpcIjEyMzQ1NlwiLFwibG9naW5Db2RlXCI6XCJ6aG91eVwiLFwibW9iaWxlXCI6XCIxMjM0NTZcIixcInBhc3N3b3JkXCI6XCJhN2ZlNWU3NjljOTMzNWE5OTcwNTE3ZDY1OGJkNGI3YWJhODU1N2RlY2UwMWUyZWFlYjg2Yjg0MVwiLFwicGhvbmVcIjpcIjEyMzQ1NlwiLFwicmVtYXJrc1wiOlwiXCIsXCJzZXhcIjpcIjJcIixcInNpZ25cIjpcIlwiLFwic3RhdHVzXCI6XCIwXCIsXCJ1cGRhdGVCeVwiOlwiemhvdXlcIixcInVwZGF0ZURhdGVcIjoxNjMzNzYyNTYxMDAwLFwidXNlckNvZGVcIjpcInpob3V5XCIsXCJ1c2VyTmFtZVwiOlwi5ZGo55CwMVwiLFwidXNlclR5cGVcIjpcIldHWVwiLFwid3hPcGVuaWRcIjpcIlwifSIsImp0aSI6InRva2VuSWQifQ.7pfVnpnBK-qahKtksMt7cUUWcGTOBr7ui1lZi8HeNxI";
sessionStorage.setItem("token", USERKEY);

App.mpType = "app";

const app = new Vue({
  store,
  ...App,
});
app.$mount();
