import ajax from "../ajax";
import { API, MODEL_API, BI } from "../api-config";


/* 表单模型 */
export const getFormModel = (modelName) => {
  return ajax.get(MODEL_API + `/api/apply/model/${modelName}`);
};

/* 表单数据反显 */
// /api/form/locator/data/{model}/{sign}

export const getFormData = (model, sign, params) => {
  return ajax.postJson(`${API}/form/operate/query/${model}/${sign}`, params);
};
/* 表单数据保存 */
export const saveForm = (model, params) => {
  return ajax.postJson(`${API}/form/operate/save/${model}`, params);
};

/* 定制表单页面右侧建筑树 */
export const getBuildingTree = (buildingId) => {
  return ajax.get(BI + `/api/ld/panel/${buildingId}`);
};
// 获取楼栋地址
export const getBuildingAddress = (params) => {
  return ajax.post(API + "/open/queryAddr", params);
};
// 获取房屋地址
export const getHouseAddress = (params) => {
  return ajax.post(API + "/open/queryHouseInfo", params);
};

/* 
  人口列表
  模型列表通用接口
  @params

  */
export const getModelList = (model, params) => {
  return ajax.postJson(`${BI}/api/form/locator/search/${model}`, params);
};

/* 通用模型列表初始化获取业务主键和筛选路径 */
export const initFormModelList = (model, params) => {
  return ajax.get(MODEL_API + "/api/apply/model/search/init/" + model, params);
};

export const getModelListFromParent = (model, parent, parentId, params) => {
  return ajax.postJson(`${BI}/api/form/locator/index/${parent}/${model}/${parentId}`, params);
}
/* 
  通用列表模型删除
*/
export const DelMoel = (model, params) => {
  return ajax.post(`${BI}/api/form/operate/delete/${model}`, params);
};

/* 
  *  删除扩展表信息
*/
export const delExtendTable = (model, extend, params) => {
  return ajax.post(`${API}/form/operate/delete/${model}/${extend}`, params);
}
/*
 * 获取采查策略
 */
export const getStrategys = () => {
  return ajax.get(BI + "/api/strategy/query");
};




/* 走访 */
// 
// 查询采查对象走访
export const getVisitLast = (model, params) => {
  return ajax.post(`${API}/form/operate/visit/${model}/last`, params);
}

// 保存采查对象走访
export const saveVisit = (model, params) => {
  return ajax.post(`${API}/form/operate/visit/${model}`, params);
}

export const removeVrImage = (param) => {
  return ajax.post(`${API}/vr/config/xml/scene/delete?r=${Math.random()}`, param)
}

export const getVr = (param) => {
  return ajax.post(`${API}/vr/config/xml/scene/list`, param);
}

export const submitVr = (param) => {
  return ajax.post(`${API}/vr/config/xml/add?r=${Math.random()}`, param);
}

export const uploadVrImage = (param) => {
  return ajax.post(`${API}/upload/img/vr?r=${Math.random()}`, param);
}