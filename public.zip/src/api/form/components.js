import ajax from "../ajax";
import { CONTEXT, BI,API } from "../api-config";

// 国家城市 √
export const getAddress = (params) => {
  return ajax.get(BI + "/api/area/data", params);
};


/* 
    模型路径筛选
    @params:
      parent_id: 104799  
*/
// 初始化通用表单模型

export const getPathData = ( params) => {
  return ajax.postJson(API+"/form/locator/next",params);
};


//关联组件
export const getRelationData = ( params) => {
  return ajax.postJson(`${API}/form/component/relation_obj`,params);
};