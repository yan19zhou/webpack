import ajax from "../ajax";
import { API } from "../api-config";

// 图片上传
export const upload = (params) => {
  return ajax.postJson(`${API}/form/component/upload`, params);
};

// 图片删除
export const deleteImage = (model, uuid, id) => {
  return ajax.post(`${API}/form/component/image/delete/${model}/${uuid}`, {
    id: id,
  });
};
// 图片记录
/* 
{
  "bus_id": "string",
  "field": "string",
  "model": "string"
}
*/
export const getImageRecord = (params) => {
  return ajax.postJson(`${API}/form/component/image/record`, params);
};
//根据给的图片id获取图片信息
export const getImagePreview = (uuid) => {
  return ajax.postJson(`${API}/form/component/image/preview`, { uuid: uuid });
};
