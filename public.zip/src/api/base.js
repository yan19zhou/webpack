import ajax from './ajax';
import {CONTEXT,MODEL_API} from "./api-config"
//接口
export function dict(params){
    return ajax.post(CONTEXT + "/api/dict", params);
}
export function getUserInfo() {
    return ajax.post(CONTEXT + "/api/account/info");
}

export function getWxCheck(params)  {
    return ajax.post(CONTEXT + "/api/config/jsconfig", params);
}

export function uploadImg(params){
    return ajax.post(CONTEXT + "/api/file/uploadImg", params);
}

// 获取图标
export function getIcons(){
    return ajax.post(MODEL_API + "/api/config/icon/model/list");
}