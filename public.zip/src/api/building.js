import ajax from "./ajax";
import { BI,API} from "./api-config";

// 楼栋列表

export const getBuildingList = (params) => {
  return ajax.get(BI + "/api/ld/grid/building", params);
};

// 地图检索显示楼栋
export const searchBuilding = (word) => {
  return ajax.get(BI + "/api/ld/topSearchLd", { keyWord: word});
};
// 楼栋人口快速查询

export const getQuickResult = (params) => {
  return ajax.get(API + "/common/map/search", params);
};