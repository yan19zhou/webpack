export const CONTEXT = process.env.VUE_APP_AUTH_API;
export const BASE_API = process.env.VUE_APP_BASE_API; //周寒本地
export const BI = process.env.VUE_APP_BASE_BI;
export const API = BI + "/api";
export const MODEL_API = process.env.VUE_APP_MODEL_API;
export const IMG_API = process.env.VUE_APP_IMG_API
export const Task_API = process.env.VUE_APP_TASK_API