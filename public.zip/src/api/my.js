/*
 * @Description: 
 * @Author: zhouy
 * @Date: 2021-11-09 10:14:48
 * @LastEditTime: 2021-11-09 10:22:11
 * @LastEditors: zhouy
 */
import ajax from "./ajax";
import { API, Task_API } from "./api-config";

export const getUserTask = (params) => {
  const param = {
    url: `${API}/task/get_user_task?r=${Math.random()}`,
    method: "POST",
    data: params
  };

  return ajax.ajax(param)
}

export const getTodayCount = (params) => {
  const param = {
    url: `${API}/task/complete/counts/today?r=${Math.random()}`,
    method: "POST",
    data: params
  };

  return ajax.ajax(param)
}

export const getUserTaskDetail = (params) => {
  const param = {
    url: `${API}/task/get_user_task_detail?r=${Math.random()}`,
    method: "POST",
    data: params
  };

  return ajax.ajax(param)
}

// 今日采查列表
export const getCollectionRecord = () => {
  return ajax.get(`${API}/task/log/collection_record?r=${Math.random()}`, {})
}

// 今日走访列表
export const getVisitRecord = () => {
  return ajax.get(`${API}/task/log/visit_record?r=${Math.random()}`, {})
}

//数据详情
export const geTaskQueryEdit = (params) => {
  return ajax.post(`${API}/task/query/edit?r=${Math.random()}`, params)
}
export const geTaskDetailEdit = (params) => {
  return ajax.post(`${API}/task/task/detail/${params}?r=${Math.random()}`)
}

// 反馈
export const postFeedback = (params) => {
  return ajax.postJson(`${Task_API}/dynamic-form/v1/model/sys_feedback/data`, params)
}
// 上传附件
export const postUploadAttachment = (params) => {
  return ajax.postJson(`${Task_API}/dynamic-form/v1/model/sys_feedback_attachment/datas`, params)
}
// 删除附件
export const postDeleteAttachment = (params) => {
  return ajax.postJson(`${Task_API}/dynamic-form/v1/file/del/${params.model}/${params.file}`)
}
// 查看文件
export const getFileShow = (params) => {
  return ajax.get(`${Task_API}/dynamic-form/v1/file/browse/${params.model}/${params.file}`)
}
// 查看回复
export const getFeedbackResult = (params) => {
  return ajax.get(`${Task_API}/dynamic-form/v1/model/sys_feedback_result/data`, params)
}
// 我的反馈
export const getMyFeedback = (params) => {
  return ajax.get(`${Task_API}/dynamic-form/v1/model/sys_feedback/data`, params)
}
// 查看附件
export const getSeeAttachment = (params) => {
  return ajax.get(`${Task_API}//dynamic-form/v1/model/sys_feedback_attachment/data`, params)
}
// 消息
export const getMessage = (params) => {
  return ajax.get(`${Task_API}/dynamic-form/v1/model/sys_message/data`, params)
}
// 用户信息
export const postUserMessage = (params) => {
  return ajax.postJson(`${Task_API}/dynamic-form/v1/api/dynamic/user_message`, params)
}
// 未读消息记录
export const postNoReadMessage = (params) => {
  return ajax.postJson(`${Task_API}/dynamic-form/v1/api/dynamic/no_read_message`, params)
}