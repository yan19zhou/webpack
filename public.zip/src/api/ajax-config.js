/*
 * @Description: 
 * @Author: zhouy
 * @Date: 2021-10-20 11:27:20
 * @LastEditTime: 2021-10-28 10:52:52
 * @LastEditors: zhouy
 */
import {  API } from "./api-config";
/**
 * 请求失败后的错误统一处理
 * @param {Number} status 请求失败的状态码
 */
export const errorHandle = (status, msg) => {
    // 状态码判断
    switch (status) {
      case 400:
        uni.showToast({ title: "请求参数错误"})
        break;
      case 401:
        uni.showToast({ title: "用户没有权限，请重新登录"})
       
        break;
      case 403:
        uni.showToast({ title: "登录过期，请重新登录"})
        sessionStorage.removeItem("token");
        break;
      case 404:
        uni.showToast({ title: "请求的资源不存在"})
        break;
      case 500:
        uni.showToast({ title: "服务器出错，请联系管理员处理"})
        break;
      default:
        uni.showToast({ title: msg})
        break;
    }
    return;
  };

  export const list = [
    `${API}/form/component/relation_obj`,
    `${API}/form/operate/query/`,
    `${API}/form/operate/save/`,
    `${API}/form/operate/delete/`,
    `${API}/form/locator/search/`,
    `${API}/form/locator/next`,
    `${API}/form/locator/index/`,
  ];