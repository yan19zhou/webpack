import { MODEL_API } from "./api-config";
import ajax from "./ajax";

// 获取部件
export function GetParts() {
    return ajax.get(MODEL_API+"/api/apply/model/node/page");
}

