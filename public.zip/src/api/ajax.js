/**
 * axios封装
 * 请求拦截、响应拦截、错误统一处理
 */
import axios from "axios";
import qs from "qs";
import { Decrypt } from "@/utils/utils.js";
import { BASE_API } from "./api-config";
import { errorHandle, list } from "./ajax-config";
// import store from "@/store/index";

const instance = axios.create({
  baseURL: BASE_API, // api的base_url
  timeout: 30000, // request timeout
});

const DefaultParam = {
  repeatable: false,
};

let ajax = {
  // PREFIX:process.env.VUE_APP_BASE_API,
  PREFIX: "",
  Author: "icp",
  requestingApi: new Set(),
  extractUrl: function(url) {
    return url /* ? url.split('?')[0] : '' */;
  },
  isRequesting: function(url) {
    let api = this.extractUrl(url);
    return this.requestingApi.has(api);
  },
  addRequest: function(url) {
    let api = this.extractUrl(url);
    this.requestingApi.add(api);
  },
  deleteRequest: function(url) {
    let api = this.extractUrl(url);
    this.requestingApi.delete(api);
  },
  get: function(url, param, extendParam) {
    let params = {
      url: url + "?random=" + Math.random(),
      // url,
      method: "GET",
    };
    if (param) {
      params.params = param;
    }
    return this.ajax(params, extendParam);
  },
  post: function(url, param, extendParam) {
    var params = {
      url,
      method: "POST",
    };
    if (param) params.data = qs.stringify(param);
    return this.ajax(params, extendParam);
  },
  postJson: function(url, paramJson, extendParam) {
    return this.ajax(
      {
        url,
        method: "POST",
        data: paramJson,
      },
      extendParam
    );
  },
  patchJson: function(url, paramJson, extendParam) {
    return this.ajax(
      {
        url,
        method: "PATCH",
        data: paramJson,
      },
      extendParam
    );
  },
  delete: function(url, extendParam) {
    return this.ajax(
      {
        url: url,
        method: "DELETE",
      },
      extendParam
    );
  },
  ajax: function(param, extendParam) {
    let params = Object.assign({}, DefaultParam, param, extendParam || {});
    params.crossDomain = params.url.indexOf("http") === 0;
    let url = params.url;
    if (!params.crossDomain) {
      url = params.url = this.PREFIX + params.url;
    }

    if (params.method != "GET") {
      if (this.isRequesting(url)) {
        return new Promise(resolve => {
          resolve({
            ok: false,
            msg: "重复请求",
          });
        });
      }
      if (params.repeatable === false) {
        this.addRequest(url);
      }
    }
    // h5临时token
    let token;

    token = sessionStorage.getItem("token");
    // axios.defaults.timeout= 2500;
    let header = {
      author: this.Author,
      Authorization: token,
      "Content-Type": "application/json;charset=UTF-8",
    };
    // 给请求头添加坐标
    header["coords"] = sessionStorage.getItem("_UserPeriodLocation");
    // 给请求头添加网格
    header["gridCode"] = sessionStorage.getItem("$gridCode");
    let defaultParam = {
      headers: header,
      responseType: "json",
      validateStatus: function() {
        return true;
      },
      paramsSerializer: params => {
        return qs.stringify(params, {
          allowDots: true,
        });
      },
    };
    let that = this;
    params = Object.assign({}, defaultParam, params);

    return new Promise(resolve => {
      uni.showLoading({ mask: true });
      return instance
        .request(params)
        .then(response => {
          that.deleteRequest(params.url);
          let data = response.data;

          data.ok = response.status == 200;
          //获取服务器产生的token，覆盖浏览器的token，刷新时间
          if (response.headers.authorization) {
            localStorage.setItem("token", response.headers.authorization);
          }
          resolve(data.data || data);
          //请求完撤销重复请求判断
          that.deleteRequest(params.url);
        })
        .catch(() => {
          uni.hideLoading();
          that.deleteRequest(params.url);
        });
    });
  },
};
instance.interceptors.response.use(
  res => {
    uni.hideLoading();
    let status = res.status;
    let code = res.data.code;

    // 如果后端统一封装返回，即所有的请求都是200, 错误码由返回结果提供，则使用以下代码获取状态
    if (status != 200) {
      errorHandle(status);
      return Promise.reject(res.data.msg);
    } else if (code !== 200) {
      errorHandle(code, res.data.msg);
      return Promise.reject(res.data.msg);
    } else {
      // 需要被拦截的接口地址

      let currentUrl = res.config.url.split("?")[0];
      let isSecret = false;
      list.map(item => {
        if (currentUrl.indexOf(item) > -1) {
          isSecret = true;
        }
      });
      if (isSecret) {
        res.data.data = JSON.parse(Decrypt(res.data.data));
      }
      return res;
    }
  },
  error => {
    uni.hideLoading();
    if (error.response) {
      let status = error.response.status;
      errorHandle(status);
    } else {
      throw new Error("网络异常！", error);
    }
    return Promise.reject(error);
  }
);
export default ajax;
