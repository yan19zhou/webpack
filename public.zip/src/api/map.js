import ajax from "./ajax";
import { API,BI } from "./api-config";

export const getPartNodes = () => {
  return ajax.post(BI + "/api/bj/select/nodes");
};

export const getGridArea=(spatial='CGCS2000',param) =>{
// spatial: CGCS2000 // 坐标系
// param: codes // 网格编码
  return ajax.postJson(`${API}/map/${spatial}/polygon`,param);
}

// 保存坐标
export const saveLocation = (param)=>{
  return ajax.postJson(`${API}/save_task/save_coordinates`,param);
}

/* 
部件

*/
// 获取部件bj/searchSub
export const getMapParts = (modelName)=>{
  return ajax.post(`${API}/bj/searchSub`,{
    modelName: modelName
});
}
// /bj/getParts 获取部件下级菜单
export const getPartMenus = (modelName)=>{
  return ajax.post(`${API}/bj/getParts`,{model:modelName});
}

// 部件自定义保存

export const savePartMenus = (modelNameArr)=>{
  return ajax.post(`${API}/bj/config`,{modelName:modelNameArr});
}
// 地图部件查询

export const searchParts = (word) => {
  return ajax.get(BI + "/api/bj/getParts", { keyWord: word});
};