import ajax from "./ajax";
import { Task_API } from "./api-config";

// 查询任务信息
export const postTaskInfo = (params) => {
  return ajax.postJson(`${Task_API}/dynamic-form/v1/api/dynamic/task-info`, params)
}

// 查询任务统计
export const postTaskStatistics = (params) => {
  return ajax.postJson(`${Task_API}/dynamic-form/v1/api/dynamic/task_statistics`, params, {repeatable: true})
}