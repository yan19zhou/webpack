/*
 * @Description: @Description
 * @Author: zhouy
 * @Date: 2021-10-20 11:31:58
 * @LastEditTime: 2021-11-16 18:07:31
 * @LastEditors: zhouy
 */
import { MODEL_API } from "@/api/api-config.js";
/**
 * 异步加载js脚本
 * @param {String} src 脚本url地址
 */
function loadScript(src) {
  return new Promise(resolve => {
    // 如果已经加载了本js，直接调用回调
    if (_checkIsLoadScript(src)) {
      resolve();
    }
    let scriptNode = document.createElement("script");
    scriptNode.setAttribute("type", "text/javascript");
    scriptNode.setAttribute("src", src);
    scriptNode.classList.add("no-random");
    document.body.appendChild(scriptNode);
    if (scriptNode.readyState) {
      //IE 判断
      scriptNode.onreadystatechange = () => {
        if (scriptNode.readyState == "complete" || scriptNode.readyState == "loaded") {
          console.log("complete");
          resolve();
        }
      };
    } else {
      scriptNode.onload = () => {
        console.log("script loaded");
        resolve();
      };
    }
  });
}

function _checkIsLoadScript(src) {
  let scriptObjs = document.getElementsByTagName("script");
  for (let sObj of scriptObjs) {
    if (sObj.src == src) {
      return true;
    }
  }
  return false;
}

/**
 * 加载显示规则脚本
 * @param {String} modelName 模型名称
 */
export function showController() {
  let commonSrc = MODEL_API + "/api/apply/js/common/script.js";
  if (!_checkIsLoadScript(commonSrc)) {
    loadScript(commonSrc).then(() => {
      return;
    });
  }
}

export function loadIconCss() {
  var link = document.createElement("link");
  link.setAttribute("rel", "stylesheet");
  link.setAttribute("type", "text/css");
  link.setAttribute("href", MODEL_API + "/icon/css/iconfont.css");
  var heads = document.getElementsByTagName("head");
  if (heads.length) {
    heads[0].appendChild(link);
  } else {
    document.documentElement.appendChild(link);
  }
}


