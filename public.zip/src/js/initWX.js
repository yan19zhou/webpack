/*
 * @Description: 
 * @Author: zhouy
 * @Date: 2021-10-20 11:31:58
 * @LastEditTime: 2021-10-28 10:53:42
 * @LastEditors: zhouy
 */
// 微信授权操作
import wx from "wx-jsapi";
import { getWxCheck } from "@/api/base.js";
import PeriodLocation from "@/js/Location";
getWxCheck({
  userKey: sessionStorage.getItem("token"),
  requestUrl: window.location.href.split("#")[0],
}).then(function(data) {
  wx.config({
    // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
    debug: false,
    // 必填，公众号的唯一标识
    appId: data.appId,
    // 必填，生成签名的时间戳
    timestamp: data.timestamp,
    // 必填，生成签名的随机串
    nonceStr: data.noncestr,
    // 必填，签名，见附录1
    signature: data.signature,
    // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
    jsApiList: [
      "checkJsApi",
      "onMenuShareTimeline",
      "onMenuShareAppMessage",
      "onMenuShareQQ",
      "onMenuShareWeibo",
      "onMenuShareQZone",
      "hideMenuItems",
      "showMenuItems",
      "hideAllNonBaseMenuItem",
      "showAllNonBaseMenuItem",
      "translateVoice",
      "startRecord",
      "stopRecord",
      "onVoiceRecordEnd",
      "playVoice",
      "onVoicePlayEnd",
      "pauseVoice",
      "stopVoice",
      "uploadVoice",
      "downloadVoice",
      "chooseImage",
      "previewImage",
      "uploadImage",
      "downloadImage",
      "getNetworkType",
      "openLocation",
      "getLocation",
      "hideOptionMenu",
      "showOptionMenu",
      "closeWindow",
      "scanQRCode",
      "openProductSpecificView",
      "addCard",
      "chooseCard",
      "openCard",
    ],
  });
  wx.ready(function() {
    new PeriodLocation();
  });

  wx.error(function(res) {
    alert("出错了：" + res.errMsg); //这个地方的好处就是wx.config配置错误，会弹出窗口哪里错误，然后根据微信文档查询即可。
  });
});
window["wx"] = wx;
