import { upload } from "@/api/form/image.js";

export default function uploadImage() {
  // 选择图片上传图片
  return new Promise((resolve, reject) => {
    window["wx"].chooseImage({
      count:1,
      success: function(res) {
        let images = [];
        var localIds = res.localIds; // 返回选定照片的本地ID列表，localId可以作为img标签的src属性显示图片
        for (let i = 0; i < localIds.length; i++) {
          const id = localIds[i];
          window["wx"].getLocalImgData({
            localId: id, //图片的localID
            success: function(res) {
              var localData = res.localData; // localData是图片的base64数据，可以用img标签显示
              if (localData.indexOf("data:image") != 0) {
                //判断是否有这样的头部
                localData = "data:image/jpeg;base64," + localData;
              }
              localData = localData
                .replace(/\r|\n/g, "")
                .replace("data:image/jgp", "data:image/jpeg");
              upload({ imageData: localData }).then((result) => {
                images.push(result);
                resolve(images);
              });
            },
            fail(err) {
              reject(err);
            },
          });
        }
      },
      fail(err) {
        reject(err);
      },
    });
  });
}
