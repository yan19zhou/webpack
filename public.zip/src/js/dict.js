/*
 * @Description: 
 * @Author: zhouy
 * @Date: 2021-10-20 11:31:58
 * @LastEditTime: 2021-10-28 14:36:21
 * @LastEditors: zhouy
 */

import { dict,getIcons } from "@/api/base.js";
export function getDict() {
    dict().then((res) => {
      let data = JSON.stringify(res);
      localStorage.setItem("$SYSTEM_STATIC_DICT", data);
    });
  }

/**
 * 根据码值对类型和Code寻找码值实际内容
 */
export function getDicText(type, code) {
    var staticDict = JSON.parse(localStorage.getItem("$SYSTEM_STATIC_DICT")) || {};
    if (typeof(staticDict) == "undefined" || typeof(staticDict[arguments[0]]) == "undefined") {
        console.log("没有这个type:" + type);
        return '';
    }
    var value;
    //没有code则返回typeList
    if (typeof(code) == 'undefined') {
        return staticDict[type];
    }
    //有值则进行对应的码值翻译
    value = getDictByCode(staticDict[arguments[0]], code)
    return value || '';
}

function getDictByCode(dicts, code) {
    let value = "";
    for (var i = 0; i < dicts.length; i++) {
        //		var tem = staticDict[type][i].fieldcode;
        if (dicts[i].key == code) {
            value = dicts[i].title;
            break;
        } else if (value == "" && dicts[i].children && dicts[i].children.length) {
            value = getDictByCode(dicts[i].children, code)
        }
    }
    return value
}

export function setGlobalIcons(){
    getIcons().then(res=>{
        if (res) {
           sessionStorage.setItem("globalIcons",JSON.stringify(res)) 
        }
    })
}