const blurMixin = {
  methods: {
    blur() {
      document.activeElement.blur();
    },
  },
};

export default blurMixin;