function getLocationPoint() {
  const getLocationByH5 = new Promise(( resolve,reject) => {
    if (navigator.geolocation) {
      console.log("开始H5定位");
      navigator.geolocation.getCurrentPosition(
        (position) => {
          let latitude = position.coords.latitude, //获取纬度
            longitude = position.coords.longitude; //获取经度
            console.log("H5定位结果:",`${longitude},${latitude}`);
          resolve(`${latitude},${longitude}`);
        },
        (err) => {
          console.log("H5定位失败");
          reject(err);
        }
      );
    }
  });

  const getLocationByWX = new Promise((resolve,reject) => {
    console.log("开始微信定位");
     window["wx"].getLocation({
      // type: 'wgs84',
      // isHighAccuracy:true,
      // highAccuracyExpireTime:1000,
      success(res) {
        const latitude = res.latitude;
        const longitude = res.longitude;
        console.log("微信定位结果：", `${longitude},${latitude}`);
        resolve(`${longitude},${latitude}`);
      },
      fail: function(res) {
        console.log("微信定位失败：", res);
        reject(res);
      },
      cancel: function(res) {
        console.log("微信定位取消：", res);
        resolve(res);
      },
    }); 
  });

 return new Promise((resolve, reject) => {
    Promise.any([getLocationByH5, getLocationByWX]).then((value) => {
        resolve(value);
      }).catch(err=>{
          reject(err)
      });
 })  
}
export default class PeriodLocation {
  constructor() {
    console.log("初始化完成");
    this._init();
  }
  async _init() {
    let self = this;
    this.isInitSuccess = false;
    await this.set().then(() => {
      self.isInitSuccess = true;
      self.instance = window.setInterval(this.set, 1800000); //1800000
    });
  }
  // 创建实例时初始化的内容
  get() {
    if (this.isInitSuccess && sessionStorage.getItem("_UserPeriodLocation")) {
      return sessionStorage.getItem("_UserPeriodLocation");
    } else {
      console.log("初始化未完成");
    }
  }
   set() {
    return new Promise((resolve) => {
      getLocationPoint()
        .then((data) => {
          if (data) {
            console.log("设置坐标", data);
            sessionStorage.setItem("_UserPeriodLocation", data);
            resolve('success');
          }
        })
        .catch(() => {
          console.log("获取坐标失败");
          sessionStorage.setItem("_UserPeriodLocation", "113.89415777136486,22.576602314168014")
        });
    });
  }
  end() {
    clearInterval(this.instance);
  }
}
