/*
 * @Description: 
 * @Author: zhouy
 * @Date: 2021-10-20 11:30:17
 * @LastEditTime: 2021-10-20 11:30:18
 * @LastEditors: zhouy
 */
import { getUserInfo } from "@/api/base.js";
import watermark from "@/utils/watermark.js";


function getUser() {
      return new Promise((resolve, reject) => {
        getUserInfo()
          .then((res) => {
            resolve(true);
            // state.userInfo = res;
            sessionStorage.setItem("$USER_INFO", JSON.stringify(res));
            // localStorage.setItem("viewcode",res.company[0].areaCode)
            // 设置水印
            watermark({
              watermark_txt: res.name,
            });
          })
          .catch((err) => {
            reject(err);
          });
      });
    }


export default getUser;
