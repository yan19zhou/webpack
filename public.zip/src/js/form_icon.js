/*
 * @Description: 
 * @Author: zhouy
 * @Date: 2021-10-20 11:31:58
 * @LastEditTime: 2021-11-02 09:53:37
 * @LastEditors: zhouy
 */
export function showIcon(item) {
  // 表单严采必采之类表单class获取
  const strategys = JSON.parse(sessionStorage.getItem("$strategys"))||[];
  for (let i = 0; i < strategys.length; i++) {
    const ele = strategys[i];
    if (ele.value == item) {
      return ele.icon;
    }
  }
}

export function filterIcon(strategy) {
  for (const key in strategy) {
    if (Object.hasOwnProperty.call(strategy, key)) {
      const element = strategy[key];
      if (!element) {
        delete strategy[key];
      }
    }
  }
  return strategy;
}
