<template>
  <view class="task-info">
    <top></top>
    <view class="head">
      <view class="head-left">
        <view class="title">楼栋专项行动</view>
        <view class="describe">
          <view>专项任务</view>
          <view class="time">2021-09-01</view>
          <view style="color: #4687F7">人</view>
        </view>
        <view v-if="isCrumbs" class="crumbs">
          <view class="crumbs-box">
            <u-icon name="photo"></u-icon>
            <view>建华大厦</view>
          </view>
        </view>
      </view>
      <view class="head-right">
        <u-button
          @click="lookup"
          :class="['rapid', show ? 'rapid' : 'rapid-active']"
          :ripple="true"
          shape="circle"
        >
          快速采查
          <u-icon name="arrow-right"></u-icon>
        </u-button>
      </view>
    </view>
    <view class="content">
      <crumbs v-if="show"></crumbs>
      <fast v-else></fast>
    </view>
  </view>
</template>

<script>
import top from './components/top.vue'
import crumbs from './components/crumbs.vue'
import fast from './components/fast.vue'
export default {
  components: {
    top,
    crumbs,
    fast
  },
  data() {
    return {
      isCrumbs: false,
      show: true,
      crumbsList: []
    }
  },
  methods: {
    lookup() {
      this.show = !this.show
      console.log(this.show)
    }
  }
}
</script>

<style lang="scss" scoped>
.task-info {
  .head {
    padding: 10px;
    display: flex;
    background-color: #fff;
    justify-content: space-between;
    box-shadow: 0px 1px 4px 0px rgba(23, 23, 23, 0.1);
    .head-left {
      .title {
        font-size: 17px;
        font-weight: bold;
      }
      .describe {
        display: flex;
        margin-top: 5px;
        font-size: 11px;
        color: #999;
      }
      .time {
        margin: 0 8px;
      }
      .crumbs {
        margin-top: 5px;
      }
      .crumbs,
      .crumbs-box {
        display: flex;
      }
    }
    .head-right {
      .rapid {
        width: 101px;
        height: 37px;
        color: #fff;
        font-size: 14px;
        background: linear-gradient(209deg, #528ffc, $color-blue);
      }
      .rapid-active {
        background: linear-gradient(24deg, #fc9652, #efac2c);
      }
    }
  }
  .content {
    padding: 15px;
    overflow-y: auto;
    height: calc(100vh - 174px);
  }
}
</style>