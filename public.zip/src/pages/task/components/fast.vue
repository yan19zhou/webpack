<template>
  <view class="fast">
    <view v-for="(item,index) in 10" :key="index" class="fast-box">
      <view class="box-top">建华大厦-1栋-1单元-202</view>
      <view class="box-bottom">
        <view v-for="(item,index) in 12" :key="index" class="box-block">
          <u-icon
            size="28"
            name="photo"
          ></u-icon>
          <view class="male">王雪琴</view>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
.fast {
  .fast-box {
    margin-bottom: 28rpx;
    background: #fffffc;
    border: 0px solid #b9b9b9;
    box-shadow: 0px 4rpx 8rpx 0px rgba(23, 23, 23, 0.1);
  }
  .box-top {
    color: #000;
    padding: 24rpx;
    @include font_size(26rpx);
    line-height: 38rpx;
    background: #f8f8f8;
  }
  .box-bottom {
    display: flex;
    flex-wrap: wrap;
    padding: 26rpx 0 4rpx 40rpx;
  }
  .box-block {
    @include font_size(22rpx);
    display: flex;
    align-items: center;
    flex-direction: column;
    margin-right: 40rpx;
    margin-bottom: 38rpx;
    .male,.female {
      margin-top: 18rpx;
    }
    .male {
      color: #4687F7;
    }
    .female {
      color: #FF45AA;
    }
  }
}
</style>