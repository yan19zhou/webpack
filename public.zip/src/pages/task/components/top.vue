<template>
  <view class="header">
    <u-search
      v-model="keyword"
      :show-action="false"
      :clearabled="true"
      shape="square"
      size="40"
      placeholder="检索任务"
    ></u-search>
    <view class="scan">
      <u-icon name="scan" size="40"></u-icon>
      <view class="scan-title">扫一扫</view>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      keyword: "",
    };
  },
};
</script>

<style lang="scss" scoped>
.header {
  padding: 30rpx;
  display: flex;
  align-items: center;
  background-color: #fff;
  border-bottom: 2rpx solid #ccc;
  /deep/ .u-input {
    @include font_size(32rpx);
  }
  /deep/ .u-icon__icon {
    @include font_size(30rpx);
  }
  .scan {
    display: flex;
    align-items: center;
    flex-direction: column;
    margin-left: 20rpx;
    .scan-title {
      @include font_size(20rpx);
    }
  }
}
</style>
