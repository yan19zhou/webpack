<template>
  <view class="crumbs">
    <view v-for="(item, index) in crumbs.data" :key="index" class="crumbs-box">
      <view class="box-top">
        <view class="box-name">
          <view class="reach">
            <u-icon class="reach-describe" label-color="#fff" label="导航" name="photo"></u-icon>
          </view>
          <u-icon label="建安大厦建安大厦建安大厦建安大厦建安大厦" label-color="#333" name="photo"></u-icon>
        </view>
        <view class="surplus">
          剩余
          <span class="surplus-num">5</span>个
        </view>
      </view>
      <view ref="open" class="box-bottom">
        <view class="bottom-item">
          <view
            @click="crumbsClick('单元')"
            v-for="(i, index) in item.attr.newArr"
            :key="index"
            class="box-item box-item-start"
            >{{ i }}</view
          >
          <view v-if="item.attr.newArr.length >= 9" @click="openChange(item, index)" class="open box-item-start">{{
            item.attr.start ? "展开" : "收起"
          }}</view>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
import { dataJson } from "../data";
export default {
  data() {
    return {
      crumbs: [],
    };
  },
  created() {
    let data = dataJson().data;
    data.data.forEach(item => {
      item.attr.newArr = item.attr.jwd.slice(0, 9);
      if (item.attr.jwd.length > 10) {
        item.attr.start = true;
      } else {
        item.attr.start = false;
      }
    });
    this.crumbs = data;
  },
  methods: {
    crumbsClick(val) {
      console.log(val);
    },
    openChange(data, k) {
      if (data.attr.start) {
        data.attr.newArr = data.attr.jwd;
        this.$refs.open[k].$el.style.maxHeight = "100%";
      } else {
        data.attr.newArr = data.attr.jwd.slice(0, 9);
        this.$refs.open[k].$el.style.maxHeight = "128rpx";
      }
      data.attr.start = !data.attr.start;
    },
  },
};
</script>

<style lang="scss" scoped>
.crumbs {
  .crumbs-box {
    padding: 30rpx;
    border-radius: 20rpx;
    background: #fffffc;
    border: 0px solid #e0e0e0;
    box-shadow: 0px 4rpx 8rpx 0px rgba(23, 23, 23, 0.1);
    &:not(:last-child) {
      margin-bottom: 24rpx;
    }
  }
  .box-top {
    display: flex;
    justify-content: space-between;
    /deep/ .box-name {
      display: flex;
      align-items: center;
      .u-icon__icon {
        @include font_size(32rpx);
      }
      .u-icon__label {
        @include font_size(28rpx);
      }
    }
    /deep/ .reach {
      display: flex;
      padding: 10rpx 18rpx;
      margin-right: 20rpx;
      white-space: nowrap;
      border-radius: 30rpx;
      align-items: center;
      justify-content: center;
      background-color: #2e74f0;
      .u-icon__icon,
      .u-icon__label {
        @include font_size(20rpx);
      }
    }
  }
  .surplus {
    @include font_size(24rpx);
    white-space: nowrap;
    .surplus-num {
      @include font_size(32rpx);
      padding: 0 12rpx;
      color: #ef7f1c;
    }
  }
  .box-bottom {
    max-height: 128rpx;
    overflow: hidden;
    display: flex;
    margin-top: 34rpx;
    justify-content: space-between;
    .bottom-item {
      display: flex;
      flex-wrap: wrap;
      .box-item {
        width: 110rpx;
        height: 56rpx;
        @include font_size(20rpx);
        color: #333333;
        line-height: 56rpx;
        margin-right: 8rpx;
        text-align: center;
        position: relative;
        margin-bottom: 8rpx;
        border-radius: 22rpx;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        border: 2rpx solid #e5e5e5;
        background-color: #fffffc;
      }
    }
    .box-item-start::after {
      content: "";
      width: 10rpx;
      height: 10rpx;
      position: absolute;
      top: 2rpx;
      right: 6rpx;
      border-radius: 50%;
      background-color: #ef7f1c;
    }
    .open {
      min-width: 110rpx;
      @include font_size(22rpx);
      max-height: 48rpx;
      color: #2e74f0;
      line-height: 48rpx;
      position: relative;
      text-align: center;
      white-space: nowrap;
      border-radius: 22rpx;
      border: 2rpx solid #2e74f0;
    }
  }
}
</style>
