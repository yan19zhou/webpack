export function dataJson() {
  const data = {
    "data": {
      "pageSize": 10,
      "pageNum": 1,
      "pageCount": 1,
      "recordCount": 1,
      "data": [{
        "task_id": 1,
        "id": 1,
        "name": "地址大厦",
        "full_name": "地址大厦",
        "attr": { "jwd": ["1单元", "2单元"] },
        "c0": 12,
        "c1": 7,
        "c2": 5
      }, {
        "task_id": 1,
        "id": 2,
        "name": "108",
        "full_name": "18栋-1单元-1层-108",
        "attr": { "jwd": ["1单元", "2单元", "3单元", "4单元", "5单元", "6单元", "7单元", "8单元", "9单元", "10单元", "11单元"] },
        "c0": 12,
        "c1": 7,
        "c2": 5
      }]
    }
  }
  return data
}
