<template>
  <view class="task-info">
    <top></top>
    <view class="head">
      <view class="head-left">
        <view class="title">楼栋专项行动</view>
        <view class="describe">
          <view>专项任务</view>
          <view class="time">2021-09-01</view>
          <view style="color: #4687F7">人</view>
        </view>
        <view v-if="isCrumbs" class="crumbs">
          <view class="crumbs-box">
            <u-icon name="photo"></u-icon>
            <view>建华大厦</view>
          </view>
        </view>
      </view>
      <view class="head-right">
        <u-button
          @click="lookup"
          :class="['rapid', show ? '' : 'rapid-active']"
          :ripple="true"
          shape="circle"
        >
          快速采查
          <u-icon name="arrow-right" size="32"></u-icon>
        </u-button>
      </view>
    </view>
    <view class="content">
      <crumbs v-if="show"></crumbs>
      <fast v-else></fast>
    </view>
  </view>
</template>

<script>
import top from './components/top.vue'
import crumbs from './components/crumbs.vue'
import fast from './components/fast.vue'
export default {
  components: {
    top,
    crumbs,
    fast
  },
  data() {
    return {
      isCrumbs: false,
      show: true,
      crumbsList: []
    }
  },
  methods: {
    // 快速采查
    lookup() {
      this.show = !this.show
      console.log(this.show)
    }
  }
}
</script>

<style lang="scss" scoped>
.task-info {
  .head {
    padding: 20rpx;
    display: flex;
    background-color: #fff;
    justify-content: space-between;
    box-shadow: 0px 2rpx 8rpx 0px rgba(23, 23, 23, 0.1);
    .head-left {
      .title {
        @include font_size(34rpx);
        font-weight: bold;
      }
      .describe {
        color: #999;
        display: flex;
        margin-top: 10rpx;
        @include font_size(22rpx);
      }
      .time {
        margin: 0 16rpx;
      }
      .crumbs {
        margin-top: 10rpx;
      }
      .crumbs,
      .crumbs-box {
        display: flex;
      }
    }
    .head-right {
      .rapid {
        min-width: 202rpx;
        height: 74rpx;
        color: #fff;
        @include font_size(28rpx);
        background: linear-gradient(209deg, #528ffc, $color-blue);
      }
      .rapid-active {
        background: linear-gradient(24deg, #fc9652, #efac2c);
      }
      /deep/ .u-btn {
        padding: 0 20rpx;
      }
    }
  }
  .content {
    padding: 30rpx;
    overflow-y: auto;
    height: calc(100vh - 348rpx);
  }
}
</style>