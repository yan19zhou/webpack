<!--
 * @Description: 
 * @Author: zhouy
 * @Date: 2021-10-19 16:03:20
 * @LastEditTime: 2021-11-12 16:20:15
 * @LastEditors: zhouy
-->
<template>
  <view class="task">
    <top></top>
    <view class="content">
      <u-tabs bar-width="375" :list="tabs" :is-scroll="false" :current="current" @change="tabsChange"></u-tabs>
      <u-tabs
        :height="60"
        :show-bar="false"
        :list="labelList"
        :is-scroll="true"
        :current="labelIndex"
        @change="labelChange"
        class="label"
        active-color="#4287ff"
      ></u-tabs>

      <scroll-view @scrolltolower="loadMore" scroll-y="true" class="task-list">
        <view @click="task(item.id)" v-for="item in taskObj.data" :key="item.id" class="task-box">
          <view class="left">
            <view class="title">{{ item.name }}</view>
            <view class="tips">
              {{ item.model_name }}
              <span class="time">{{ item.one_end_date | format }}</span>
            </view>
          </view>
          <view v-if="item.statistics" class="right">
            <view class="quantity">
              <view class="label-num">{{ item.statistics.c2 > -1 ? item.statistics.c2 : "-" }}</view>
              <view class="label-title">未完成</view>
            </view>
            <view class="quantity">
              <view class="label-num">{{ item.statistics.c1 > -1 ? item.statistics.c1 : "-" }}</view>
              <view class="label-title">已完成</view>
            </view>
            <view class="quantity">
              <view class="label-num">{{ item.statistics.c0 > -1 ? item.statistics.c0 : "-" }}</view>
              <view class="label-title">总数</view>
            </view>
          </view>
        </view>
      </scroll-view>
    </view>
    <c-selectGrid ref="selectGrid" />
  </view>
</template>

<script>
import top from "./components/top.vue";
import { postTaskInfo, postTaskStatistics } from "@/api/task.js";
export default {
  name: "task",
  onShow() {
    this.$nextTick(() => this.getUserGrid());
  },
  components: {
    top
  },
  data() {
    return {
      tabs: [
        {
          name: "正在进行",
        },
        {
          name: "历史任务",
        },
      ],
      labelList: [
        {
          name: "全部",
          value: "qb",
        },
        {
          name: "专项任务",
          value: "zx",
        },
        {
          name: "周期任务",
          value: "zq",
        },
        {
          name: "核查任务",
          value: "cc",
        },
      ],
      current: 0,
      labelIndex: 0,
      taskObj: {},
      pageNum: 1,
      isLoadMore: false,
    };
  },
  filters: {
    format(val) {
      return val.split(" ")[0];
    },
  },
  onLoad() {
    this.initData();
  },
  // 下拉刷新
  onPullDownRefresh() {
    this.taskObj = {};
    this.isLoadMore = false;
    this.pageNum = 1;
    this.initData();
    setTimeout(function() {
      uni.stopPullDownRefresh();
    }, 1000);
  },
  methods: {
    
    getUserGrid() {
      const gridCode = sessionStorage.getItem("$gridCode");
      const userInfo = sessionStorage.getItem("$USER_INFO");
      this.$refs.selectGrid && (this.$refs.selectGrid.show = userInfo && !gridCode);
    },
    // 上拉加载
    loadMore() {
      if (this.isLoadMore) {
        return;
      }
      if (this.taskObj.pageCount > 1 && this.taskObj.pageCount > this.pageNum) {
        this.isLoadMore = true;
        ++this.pageNum;
        this.initData();
      }
    },
    // 初始化数据
    initData() {
      let obj = {
        token: sessionStorage.token,
        params: { status: this.current ? "5" : "2" },
        pageNum: this.pageNum
      };
      if (this.labelList[this.labelIndex].value !== "qb") {
        obj.params.type = this.labelList[this.labelIndex].value;
      }
      // 任务列表
      postTaskInfo(obj).then(res => {
        this.pageNum = res.pageNum;
        res.data &&
          res.data.forEach(item => {
            item.statistics = {};
            // 任务统计
            postTaskStatistics({ id: item.id }).then(data => {
              item.statistics = data;
            });
          });
        this.taskObj = res;
        console.log(res);
      });
    },
    // tab栏切换
    tabsChange(index) {
      this.current = index;
      this.initData();
    },
    // 任务栏切换
    labelChange(index) {
      this.labelIndex = index;
      this.initData();
    },
    // 任务详情
    task(id) {
      uni.navigateTo({
        url: `task-info?id=${id}`,
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.task {
  .content {
    padding-bottom: 24rpx;
    /deep/ .u-tab-item {
      @include font_size(30rpx);
    }
    .label /deep/ {
      padding: 20rpx 0;
      .u-tab-item {
        margin-left: 10rpx;
        border-radius: 40rpx;
        border: 2rpx solid #dfdfdf;
      }
    }
    .task-list {
      height: calc(100vh - 440rpx);
      overflow-y: auto;
    }
    .task-box {
      padding: 20rpx 30rpx;
      display: flex;
      border-bottom: 2rpx solid #cccccc;
      .title {
        color: #333;
        @include font_size(32rpx);
        margin-bottom: 10rpx;
        overflow: hidden;
        display: -webkit-box;
        -webkit-line-clamp: 1;
        -webkit-box-orient: vertical;
      }
      .tips {
        @include font_size(20rpx);
        color: $color-blue;
      }
      .time {
        color: #999;
        margin-left: 10rpx;
      }
      .right {
        flex: 1;
        display: flex;
        white-space: nowrap;
        flex-direction: row-reverse;
        & .quantity:nth-of-type(3) .label-num {
          color: #4a86ef;
        }
        & .quantity:nth-of-type(2) .label-num {
          color: #00d889;
        }
        & .quantity:nth-of-type(1) .label-num {
          color: #ef7f1c;
        }
      }
      .quantity {
        display: flex;
        margin-left: 20rpx;
        align-items: center;
        flex-direction: column;
      }
      .label-num {
        max-width: 80rpx;
        @include font_size(28rpx);
        font-weight: bold;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .label-title {
        @include font_size(20rpx);
        margin-top: 10rpx;
        color: #999;
      }
    }
  }
}
</style>
