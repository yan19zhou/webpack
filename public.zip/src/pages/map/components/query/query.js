import {getQuickResult} from "@/api/building.js"

export function setConditionFormField(type) {
  // 查询条件配置数据
  let data = {
    MODEL_POPULATION: [
      {
        label: "楼栋/房屋编码",
        name: "code",
        type: "input",
      },
      {
        label: "姓名",
        name: "name",
        type: "input",
      },
      {
        label: "身份证号",
        name: "card",
        type: "input",
      },
      {
        label: "手机号",
        name: "tel",
        type: "input",
      },
      {
        label: "人员状态",
        name: "personState",
        type: "select",
        dict: "PERSON_STATE",
      },
      {
        label: "住址",
        name: "address",
        type: "input",
      },
    ],
    MODEL_HOUSE: [
      {
        label: "楼栋/房屋编码",
        name: "code",
        type: "input",
      },
      {
        label: "地址",
        name: "address",
        type: "input",
      },
    ],
  };
  let formList = data[type];
  let FormData = {};
  formList.map((item) => {
    FormData[item.name] = "";
  });
  return { formList: formList, FormData: FormData };
}

export function setResultField(type) {
  // 查询条件配置数据
  let data = {
    MODEL_POPULATION: [
      {
        label: "证件号码",
        field: "card",
        icon: "iconicon-1",
      },
      {
        label: "手机号码",
        field: "tel",
        icon: "iconyaoyiyao",
      },
      {
        label: "人员状态",
        field: "person_state",
        dict: "PERSON_STATE",
        icon: "iconrenwuguanli",
      },
      {
        label: "房屋编码",
        field: "housing_code",
        icon: "iconfangjian",
      },
      {
        label: "居住地址",
        field: "address",
        icon: "iconloudong",
      },
      {
        label: "居住网格",
        field: "grid_name",
        icon: "iconzujian",
      },
      {
        label: "更新时间",
        field: "time",
        icon: "icondingshi",
      },
    ],
    MODEL_HOUSE: [
      {
        field: "name"
      },
      {
        label: "房屋编码",
        field: "housing_code",
        icon: "iconfangjian",
      },
      {
        label: "网格",
        field: "grid_name",
        icon: "iconzujian",
      },
      {
        label: "社区",
        field: "community_name",
        icon: "iconloudong",
      },
      {
        label: "街道",
        field: "street_name",
        icon: "iconloudong",
      },
      {
        label: "更新时间",
        field: "time",
        icon: "icondingshi",
      },
    ],
  };

  return  data[type];
}


export function getResult(resultState,params){
  resultState.list=[];
  resultState.total=0;
  getQuickResult(params).then(res=>{
   if (res) {
    resultState.list = res.records;
    resultState.total =res.total
    if (params.current == res.pages||!res.records.lenght) {
      resultState.finished = true;
      return;
    }
    params.current++;
   }
    console.log(resultState);
  })
}