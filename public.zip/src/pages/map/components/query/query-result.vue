<template>
  <view class="search-result">
    <view class="nav van-hairline--bottom" @click="back">
      <i class="iconfont iconleft-"></i>
      <span>为您搜索到{{ total }}条结果</span>
    </view>
    <van-list
      v-model:loading="loading"
      :finished="finished"
      finished-text="没有更多了"
      @load="onLoad"
    >
      <view v-for="item in list" :key="item">
        <ResultItem
          v-if="item"
          :info="item"
          :type="type"
          @click="toDetail(item)"
        />
      </view>
    </van-list>
  </view>
</template>

<script>
import { reactive, toRefs, getCurrentInstance } from "vue";

import ResultItem from "./result-item";
import { getResult } from "./query";
import { useRouter } from "vue-router";
export default {
  components: {
    ResultItem,
  },
  props: {
    type: String,
  },
  setup(props, { emit }) {
    const router = useRouter();
    const resultState = reactive({
      count: 0,
      back() {
        //返回查询页面
        emit("back");
      },
      toDetail(item) {
        // to表单详细页面
        console.log();
        router.push({
          path: "/commonForm",
          query: {
            to: props.type,
            from:
              props.type == "MODEL_POPULATION" ? "MODEL_HOUSE" : "MODEL_FLOOR",
            fromKey: item.parentId,
            toKey: item.uuid,
            name: item.name,
            address: item.address,
            pathStart: "MODEL_BUILDING",
          },
        });
      },
      list: [],
      total: 0,
      loading: false,
      finished: false,
    });

    const { proxy } = getCurrentInstance();

    let params = reactive({});
    proxy.$bus.on("quickQuery1", (data) => {
      params = Object.assign({ current: 1, size: 15 }, data);
      onLoad();
    });
    const onLoad = () => {
      // 更新数据
      getResult(resultState, params);
    };
    return {
      ...toRefs(resultState),
      onLoad,
    };
  },
};
</script>

<style lang="scss" scoped>
.search-result {
  height: 100%;
  .nav {
    width: 100%;
    color: $uni-text-color-grey;
    line-height: 40px;
    text-align: left;
    padding-left: 18px;
    box-sizing: border-box;
    i {
      font-size: 16px;
      margin-right: 10px;
    }
    span {
      font-size: 14px;
    }
  }
  .van-list {
    padding: 0 20px;
    height: calc(100% - 50px);
    overflow-y: auto;
  }
}
</style>