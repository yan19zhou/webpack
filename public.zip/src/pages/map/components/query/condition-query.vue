<template>
  <van-popup
    closeable
    :show="isshow"
    close-icon="close"
    position="left"
    :style="{ height: '88%' }"
    @click-overlay="close"
    @click-close-icon="close"
    class="condition-query"
  >
    <transition name="van-slide-left">
      <van-tabs
        v-model:active="activeName"
        title-active-color="#4287ff"
        v-show="!isResult"
      >
        <van-tab
          :title="item.title"
          :name="item.name"
          v-for="item in tabList"
          :key="item.name"
        >
          <ConditionBuilding :type="activeName" @search="search" />
        </van-tab>
      </van-tabs>
    </transition>
    <transition name="van-slide-right">
      <QueryResult v-show="isResult" @back="back" :type="activeName"/>
    </transition>
  </van-popup>
</template>

<script>
import { reactive, toRefs } from "vue";
import ConditionBuilding from "./condition-building";
import QueryResult from "./query-result";

export default {
  props: {
    isshow: Boolean,
  },
  components: {
    ConditionBuilding,
    QueryResult,
  },
  setup(props, { emit }) {
    const tabList = [
      { title: "查人口", name: "MODEL_POPULATION" },
      { title: "查楼房", name: "MODEL_HOUSE" },
    ];
    const state = reactive({
      activeName: "MODEL_POPULATION", // 当前选中tab
      tabList: tabList, // tab数据
      isResult: false, // 是否查询结果页面
      close() {
        // 弹窗关闭
        emit("close");
      },
      search() {
        // 搜索
        // 请求查询接口，返回结果之后跳转到查询结果页面
        state.isResult = true;
      },
      back() {
        // 查询结果页面返回到搜索条件页面
        state.isResult = false;
      },
    });

    return {
      ...toRefs(state),
    };
  },
};
</script>

<style lang="scss" scoped>
.condition-query {
  width: 100;
  height: 80%;
  background: #fff;
  opacity: 1;
  transform: scale(1, 1);
  transition: 0.25s;
}
</style>
<style lang="scss">
.condition-query {
  .van-tabs__line {
    width: 50%;
    background: $color-blue;
  }
  .van-tabs {
    height: 100%;
  }
  .van-tabs__content {
    height: calc(100% - 50px);
    overflow-y: auto;
  }
}
</style>