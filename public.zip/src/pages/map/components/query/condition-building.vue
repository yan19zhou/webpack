<template>
  <form ref="formEl" id="formEl" class="search-form">
    <view class="form-item" v-for="field in formList" :key="field.name">
      <label for="">{{ field.label }}</label>
      <input
        v-if="field.type == 'input'"
        type="text "
        :name="field.name"
        v-model="FormData[field.name]"
        autocomplete="off"
      />
      <van-popover
        v-else-if="field.type == 'select'"
        v-model:show="showPopover"
        :actions="personStatusOptions(field.dict)"
        @select="(e) => onSelect(e, field.name)"
        placement="top-start"
        :overlay="true"
        className="conditaion-building-pop"
      >
        <template #reference>
          <input
            type="text "
            readonly
            :name="field.name"
            placeholder="-请选择-"
            v-model="select"
          />
        </template>
      </van-popover>

      <van-icon
        v-show="FormData[field.name] && field.type == 'input'"
        name="clear"
        @click="FormData[field.name] = ''"
      />
    </view>
    <view @click="search" class="search-btn search-submit" type="submit">
      搜索
    </view>
    <view @click="reset" class="search-btn search-reset">重置</view>
  </form>
</template>

<script>
import { reactive, toRefs, ref, getCurrentInstance } from "vue";

import { setConditionFormField } from "./query";
import { getDicText } from "@/js/dict.js";
export default {
  props: {
    type: String,
  },
  setup(props, { emit }) {

    let { formList, FormData } = setConditionFormField(props.type);
    let formEl = ref(null);

    const { proxy } = getCurrentInstance();
    const state = reactive({
      formList: reactive(formList),
      FormData: reactive(FormData),
      search:()=>{
        state.FormData['model'] = props.type
        proxy.$bus.emit("quickQuery1", state.FormData);
        emit("search");
      },
      reset() {
        formEl.value.reset();
        for (var key in state.FormData) {
          state.FormData[key] = "";
        }
        console.log(state.FormData);
      },
    });

    //人员状态
    const showPopover = ref(false);
    let personState = reactive({
      select: ref(""),
      personStatusOptions(dict) {
        let list = getDicText(dict);
        let arr = [];
        list.map((item) => {
          arr.push({ text: item.title, value: item.key });
        });
        return arr;
      },
      onSelect(action, name) {
        console.log(action, name, personState.select);
        personState.select = action.text;
        state.FormData[name] = action.value;
      },
    });

    return {
      ...toRefs(state),
      ...toRefs(personState),
      formEl,
      showPopover,
    };
  },
};
</script>

<style lang="scss" scoped>
.search-form {
  padding: 20px;
  box-sizing: border-box;
  .form-item {
    color: $color-deep;
    text-align: left;
    position: relative;
    input {
      width: 100%;
      height: 36px;
      margin-top: 5px;
      margin-bottom: 15px;
      padding: 0 20px;
      border: solid 0.5px rgba(128, 128, 128, 0.5);
      border-radius: 5px;
      box-sizing: border-box;
    }
    input::placeholder {
      color: $uni-text-color-grey;
    }
    .van-icon-clear {
      color: $color-weak;
      font-size: 16px;
      position: absolute;
      right: 10px;
      bottom: 26px;
    }
  }

  .search-btn {
    display: block;
    width: 100%;
    height: 36px;
    line-height: 36px;
    text-align: center;
    border-radius: 5px;
  }
  .search-submit {
    background: $bg-page-blue;;
    color: #fff;
    margin-top: 10px;
  }
  .search-reset {
    border: solid 0.5px rgba(128, 128, 128, 0.5);
    margin-top: 10px;
  }
}
</style>
<style lang="scss">
.search-form {
  .van-popover__wrapper {
    display: block;
  }
}
.conditaion-building-pop {
  background: $color-white;
  border-radius: 5px;
  .van-popover__action {
    width: auto;
  }
  .van-popover__action-text {
    color: $color-deep;
  }
  .van-popover__arrow {
    position: absolute;
    width: 0;
    height: 0;
    border-color: transparent;
    border-style: solid;
    border-width: 0.12rem;
    bottom: 0;
    left: 0.32rem;
    border-top-color: $color-white;
    border-bottom-width: 0;
    transform: translate(-50%, 100%);
  }
}
</style>