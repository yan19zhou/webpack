<template>
  <view class="query-result-item van-hairline--bottom">
    <view v-for="(item, key) in fields" :key="item.field">
      <view class="item-title" v-if="key == 0">
        <span>{{ info[item.field] || "臣田村中区92A号101" }}</span>
        <i class="iconfont iconright-"></i>
      </view>
      <view v-else class="item-content">
        <view class="item-content-name">
          <i :class="['iconfont text-blue', item.icon]"></i>
          {{ item.label }}:
        </view>
        <view class="item-content-value">{{ info[item.field] }}</view>
      </view>
    </view>
  </view>
</template>

<script>
import { reactive, toRefs, watch } from "vue";
import { setResultField } from "./query";
export default {
  props: {
    type: String,
    info: Object,
  },
  setup(props) {
    const state = reactive({
      fields: setResultField(props.type),
    });
    watch(
      () => props.type,
      (newValue) => {
        state.fields = setResultField(newValue);
        console.log(state.fields);
      }
    );
    watch(
      () => props.info,
      (newValue) => {
        console.log("result------",newValue);
      },{
        immediate:true
      }
    );
    return {
      ...toRefs(state),
    };
  },
};
</script>

<style lang="scss" scoped>
.query-result-item {
  text-align: left;
  color: $color-deep;
  padding-bottom: 12px;
  box-sizing: border-box;
  .item-title {
    font-size: 16px;
    font-weight: bold;
    padding: 10px 0;
    display: flex;
    justify-content: space-between;
    .iconright- {
      line-height: 24px;
    }
  }
  .item-content {
    margin-bottom: 7px;
    padding: 0 3px;
    font-size: 14px;
    .item-content-name {
      padding-bottom: 2px;
      i {
        font-size: 16px;
      }
    }
    .item-content-value {
      padding-left: 17px;
    }
  }
}
</style>