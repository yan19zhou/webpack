<template>
  <view class="fabLeft" id="fabLeft">
    <view class="slide-fade">
      <view
        :class="['slide-item fc', activeIndex == index ? 'active-item' : '']"
        v-for="(item, index) in menuDatas"
        @click="handlerItem(item, index)"
        :key="item.uuid"
      >
        <i :class="['iconfont', item.modelIcon || defaultIcon]"></i>
        <span>{{ item.modelDecribe }}</span>
      </view>
    </view>
    <view class="custom-btn fc" @click="popupOpened = true">
      <i class="iconfont icongengduo"></i>
      <span>自定义</span>
    </view>
    <!--弹出框的内窗口-->
    <van-popup
      class="full-screen background-color"
      close-icon-position="top-left"
      position="bottom"
      :style="{ height: '86%' }"
      closeable
      v-model:show="popupOpened"
      @opened="opened"
    >
      <view class="popup-content">
        <view class="block">
          <view class="more-part-content" id="more-parts">
            <view class="my-parts">
              <h3
                style="
                  display: flex;
                  justify-content: space-between;
                  align-items: center;
                "
              >
                <view class="my-type">
                  我的分类
                  <span>拖动排序</span>
                </view>
                <view class="editBtn" @click="editBtn">
                  <a class="link popup-close" href=" #"></a>
                  {{ isEditing ? "完成" : "编辑" }}
                </view>
              </h3>
              <view class="flex" ref="dragEl">
                <view
                  class="item fc"
                  style="cursor: move"
                  v-for="(item, index) in menuDatas"
                  :key="index"
                >
                  <view class="sortable-box">
                    <view class="img">
                      <i
                        style="color: $uni-text-color"
                        :class="['iconfont', item.modelIcon || defaultIcon]"
                      ></i>
                    </view>
                    <view class="title text-ellipsis">
                      {{ item.modelDecribe }}
                    </view>
                  </view>
                  <view
                    class="del-icon"
                    v-if="isEditing"
                    @click.stop="del(index, item)"
                  >
                    <van-icon name="clear" class="ml10" />
                  </view>
                </view>
              </view>
            </view>
            <view class="other-parts">
              <h3 class="my-type">
                可选分类
                <span>点击添加分类</span>
              </h3>
              <view class="flex">
                <ul class="sortable-box">
                  <li class="item fc" v-for="(item, i) in addLists" :key="i">
                    <view class="img">
                      <i
                        style="color: $uni-text-color"
                        :class="['iconfont', item.modelIcon || defaultIcon]"
                      ></i>
                    </view>
                    <view class="title text-ellipsis">
                      {{ item.modelDecribe }}
                    </view>
                    <view
                      class="del-icon"
                      v-if="isEditing"
                      v-on:click="addMenuList(i, item)"
                    >
                      <van-icon name="add" class="ml10" />
                    </view>
                  </li>
                </ul>
              </view>
            </view>
          </view>
        </view>
      </view>
    </van-popup>
  </view>
</template>

<script>
import { getPartNodes, savePartMenus } from "@/api/map.js";

import Sortable from "sortablejs";
import { ref } from "vue";
export default {
  props: {
    type: String,
  },

  setup() {
    const dragEl = ref(null);

    const opened = () => {
      console.log(dragEl.value);
      new Sortable(dragEl.value, {
        onEnd: function () {
          // 获取排序之后的data数据
          /*  value.splice(evt.newIndex, 0, value.splice(evt.oldIndex, 1)[0]);
          var newArray = value.slice(0);
          value = [];
          nextTick(function () {
            value = newArray;
            console.log(value);
          }); */
        },
      });
    };
    return { dragEl, opened };
  },
  data() {
    return {
      popupOpened: false,
      activeIndex: 0,
      isEditing: false, //控制
      menuData: [], //已选数据
      addLists: [], //可选数据
      myparts: [], //给后台发送已选数据,
      menuDatas: [], // 左侧菜单栏数据
      defaultIcon: "iconloudongsheshibujian",
    };
  },
  created() {
    this._getPartNodes();
  },
  methods: {
    _getPartNodes() {
      getPartNodes().then((res) => {
        this.addLists = res.chooseNodes;
        this.menuDatas = res.menuDatas;
      });
    },
    handlerItem(item, index) {
      this.activeIndex = index;
      this.$emit("choosePart", item);
    },
    showPop() {
      this.popupOpened = true;
      console.log(this.popupOpened);
    },
    editBtn() {
      // 编辑
      this.isEditing = !this.isEditing;
      if (!this.isEditing) {
        let modelNames = this.menuDatas.map((item) => {
          return item.modelName;
        });
        savePartMenus(JSON.stringify(modelNames)).then((res) => {
          this.addLists = res.chooseNodes;
          this.menuDatas = res.menuDatas;
        });
      }
    },
    del(index, item) {
      console.log(index, item);
      this.menuDatas.splice(index, 1);
      this.addLists.push(item);
    },
    addMenuList(i, item) {
      this.addLists.splice(i, 1);
      this.menuDatas.push(item);
    },
  },
};
</script>

<style lang='scss' scoped>
.fabLeft {
  width: 56px;
  height: 250px;
  position: absolute;
  top: 20%;
  box-shadow: 1px 1px 6px 1px rgba(0, 0, 0, 0.4);
  background: #fff;
  padding-top: 6px;
  padding-bottom: 6px;
  display: flex;
  flex-direction: column;
  z-index: 99;
  .slide-fade {
    flex: 1;
    overflow-y: auto;
    .slide-item {
      height: 56px;
      flex-direction: column;
      span {
        width: 100%;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
    }
    .active-item {
      color: $color-blue;
      background-image: url("/static/images/active-top.png");
      background-repeat: no-repeat;
      background-position: left top;
      background-size: 8px 8px;
    }
  }
  .custom-btn {
    flex: 0 0 55px;
    flex-direction: column;
  }
}

/**部件导航弹出框的显示 */

.popup-content {
  margin-top: 40px;
  height: calc(100% - 50px);
  overflow: scroll;
  .my-type {
    color: $uni-text-color;
    span {
      color: $color-deep;
      font-size: 10px;
      margin-left: 8px;
    }
  }

  .flex {
    display: flex;
    margin-top: 25px;
    .item {
      width: 50px;
      height: 44px;
      margin-right: 16px;
      margin-bottom: 10px;
      position: relative;
      flex-direction: column;
    }
  }
}
/*更多parts*/
.block {
  padding: 0 0 0 20px;
  margin-top: 15px;
}
.full-screen {
  height: 100%;
  width: 100%;
}
.other-parts {
  text-align: left;
}
#more-parts {
  top: 7%;
  border-radius: 10px;
  ul,
  li {
    padding: 0;
  }
  li {
    list-style: none;
  }
  ul {
    display: flex;
    flex-wrap: wrap;
  }
  h3 {
    font-weight: 100;
    font-size: 13px;
    margin-top: 10px;
  }
  .sortable-box {
    width: 100%;
    .title {
      width: 100%;
      font-size: 9px;
      color: $uni-text-color;
      text-overflow: ellipsis;
      transform: scale(0.8);
      overflow: hidden;
    }
  }

  .img {
    text-align: center;
    & > img {
      width: 50%;
    }
  }

  .del-icon {
    position: absolute;
    right: -9px;
    top: -9px;
    color: $color-red;
    .van-icon {
      font-size: 20px;
    }
  }
}
.editBtn {
  width: 48px;
  border-radius: 20px;
  color: $color-blue;
  border: 1px solid $color-blue;
  text-align: center;
  line-height: 20px;
  font-size: 12px;
  cursor: pointer;
  margin-right: 14px;
}
</style>
<style lang="scss">
.fabLeft {
  .van-popup__close-icon {
    color: $uni-text-color;
  }
}
</style>
