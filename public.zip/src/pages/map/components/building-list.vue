<template>
  <view class="panel-building-list" :style="{ left: isShow ? '0' : '-50%' }">
    <view class="building-list-ctrl-btn p-ar" @click="openBuildingList">
      <span>楼栋</span>
      <van-icon
        class="btn-text btn-icon"
        :name="isShow ? 'arrow' : 'arrow-left'"
      />
    </view>
    <view class="panel-building-list-content" >
      <view class="panel-building-list-title">辖区楼栋列表</view>
      <view class="panel-building-list-info" v-if="state.buildingList.length">
        <view
          v-for="(build, index) in state.buildingList"
          :key="build.uuid"
          class="panel-building-list-inner"
          @click="routerToBuilding(build)"
        >
          <view class="panel-building-list-inner-header">
            <span class="num">{{ index + 1 }}</span>
            <span class="txt">{{ build.name ? build.name : "楼栋" }}</span>
          </view>
          <view class="panel-building-list-inner-content">
            <view>
              <span>{{ build.buildingCode }}</span>
            </view>
            <view class="building-list-address">
              <span>地址: </span
              >{{ build.address ? build.address : "暂无地址" }}
            </view>
          </view>
        </view>
      </view>
      <view v-else class="pc"><van-empty description="暂无数据" /></view>
    </view>
  </view>
</template>

<script>
import { reactive, ref } from "vue";
import { useRouter } from "vue-router";
import { getBuildingData } from "../js/getDatas";
export default {
  setup() {
    let state = reactive({buildingList:[]});
    let isShow = ref(false);
    getBuildingData(state);

    const openBuildingList = () => {
      isShow.value = !isShow.value;
    };

    const router = useRouter();
    const routerToBuilding = (item) => {
      // 跳转到对应表单页面
      // console.log(item);
      router.push({
        path: "/customForm",
        query: {
          to: "MODEL_BUILDING",
          from: "",
          fromKey: "",
          toKey: item.uuid,
          name: item.name,
          address: item.address,
          pathStart:"MODEL_BUILDING"
        },
      });
    };
    return { state, openBuildingList, isShow, routerToBuilding };
  },
};
</script>

<style lang="scss" scoped>
.panel-building-list {
  position: absolute;
  top: 50%;
  z-index: 1500;
  width: 50%;
  height: 100%;
  background: #fff;
  left: -50%;
  top: 0;
  transition: left 0.5s ease-in-out;
  .building-list-ctrl-btn {
    text-align: center;
    z-index: 999;
    width: 22px;
    height: 70px;
    color: #505050;
    font-weight: 600;
    padding: 12px 8px 10px 3px;
    background: url("/static/images/tbtn.png") no-repeat;
    background-size: 100% 100%;
    font-size: 12px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-evenly;
  }
  .panel-building-list-content {
    height: calc(100% - 10px);
    text-align: left;
    border-right: 1px solid #cecece;
    .panel-building-list-title {
      color: #999;
      padding: 10px 10px 0px 10px;
      font-size: 15px;
    }

    .panel-building-list-info {
      height: calc(100% - 10px);
      overflow-y: auto;
      padding-bottom: 30px;
      .panel-building-list-inner {
        padding: 10px;
        border-bottom: 1px solid #cecece;
        &:last-child {
          padding: 10px;
          border-bottom: 0px;
        }
      }
      .panel-building-list-inner-header {
        .num {
          display: inline-block;
          height: 20px;
          width: 20px;
          color: #fff;
          background: $color-blue;
          border-radius: 50%;
          text-align: center;
          font-size: 10px;
          line-height: 22px;
          margin-right: 2px;
        }
        .txt {
          font-size: 15px;
          font-weight: 600;
          color: #333;
          position: relative;
          top: 2px;
        }
      }
      .panel-building-list-inner-content {
        padding-left: 23px;
        line-height: 25px;
        font-size: 12px;
        .building-list-address {
          color: #999;
        }
      }
    }
  }
}
</style>

<style lang="scss">
.building-list-ctrl-btn .van-icon {
  color: $color-blue;
  margin-top: 4px;
  font-size: 12px;
}
</style>