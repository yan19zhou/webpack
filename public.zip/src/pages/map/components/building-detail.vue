<template>
  <view class="building-detail" v-show="show">
    <view class="building-top van-hairline--bottom">
      <view class="title">
        <view class="title-left">
          <view class="left-name">{{ buildingDetail.info.name }}</view>
          <view class="left-dis">距您{{ buildingDetail.info.dis }}米</view>
        </view>
        <view class="title-right" @click="toWay">
          <img src="@/static/images/icon/button-route-yuan.png" alt="" />
        </view>
      </view>
      <view class="address">
        <img src="@/static/images/icon/unit7.png" alt="" />
        <span>{{ buildingDetail.info.address }}</span>
      </view>
    </view>
    <view v-if="activeStart == 'MODEL_BUILDING'" class="building-bottom">
      <view
        class="repositon"
        @click="reposition"
        :class="{ positioning: isPositioning }"
      >
        <i class="iconfont iconyidong1"></i>
        <span>{{ isPositioning ? "重新定位中" : "重新定位" }}</span>
      </view>
      <view v-if="!isPositioning" class="task" @click="toTask">
        <i class="iconfont iconrenwuguanli"></i>任务
      </view>
      <view v-else class="task" @click="positionCancel">取消</view>
      <view v-if="!isPositioning" class="collect" @click="toCollect">
        <img src="@/static/images/icon/unit9.png" alt="" />采集
      </view>
      <view v-else class="collect" @click="positionSave">保存位置</view>
    </view>
    <view v-else class="part-bottom">
      <view class="part-detail" @click="toPartDetail">
        <img src="@/static/images/icon/unit9.png" alt="" />详情
      </view>
    </view>
  </view>
</template>

<script>
import { reactive, ref, getCurrentInstance, toRefs } from "vue";
import { useRouter } from "vue-router";

import gcoord from "gcoord";
export default {
  props: {
    activeStart: String,
  },
  setup(props, { emit }) {
    let show = ref(false);
    const { proxy } = getCurrentInstance();
    let buildingDetail = reactive({ info: {} });
    uni.$on("showMapPop", (e) => {
      if (e.type == "show") {
        show.value = true;
        buildingDetail.info = e.attr;
      } else {
        show.value = false;
      }
    });

    // 定位
    const router = useRouter();
    let isPositioning = ref(false);
    let positionState = reactive({
      reposition: () => {
        isPositioning.value = true;
        emit("reposition");
      },
      positionCancel: () => {
        //取消定位
        isPositioning.value = false;
        emit("positionCancel");
      },
      positionSave: () => {
        //保存重新定位
        emit("positionSave", buildingDetail.info);
      },
      saveSuccess: () => {
        isPositioning.value = false;
      },
      toWay: () => {
        //导航
        let { name, address, coordinate } = toRefs(buildingDetail.info);
        let primaryCoordinate = coordinate.value.split(",");
        let coordinates = gcoord.transform(
          primaryCoordinate, // 经纬度坐标
          gcoord.WGS84, // 当前坐标系
          gcoord.GCJ02 // 目标坐标系
        );
        let longitude = coordinates[0];
        let latitude = coordinates[1];

        window["wx"].openLocation({
          latitude: latitude,
          longitude: longitude,
          name: name,
          address: address,
          scale: 18,
        });
      },
      toTask: () => {
        //任务
      },
      toCollect: () => {
        //采集
        console.log(buildingDetail.info);
        routerLink("/commonForm");
      },
      toPartDetail() {
        console.log(buildingDetail.info);
       routerLink("/nextForm");
      },
    });
    // 路由跳转
    function routerLink(path) {
      router.push({
        path: path,
        query: {
          toKey: buildingDetail.info.uuid,
          to: buildingDetail.info.modelName,
          name: buildingDetail.info.name,
          pathStart: props.activeStart,
          from: buildingDetail.info.parent_model,
          fromKey: buildingDetail.info.parent_id,
        },
      });
    }
    return { show, buildingDetail, isPositioning, ...toRefs(positionState) };
  },
};
</script>

<style lang="scss" scoped>
.building-detail {
  width: 100%;
  position: fixed;
  bottom: 51px;
  left: 0;
  background: #fff;
  .building-top,
  .building-bottom,
  .part-bottom {
    width: 100%;
  }
  .building-top {
    height: 105px;
    padding: 10px 24px;
    box-sizing: border-box;

    .title {
      display: flex;
      justify-content: space-between;
      margin-bottom: 5px;
      .title-left {
        .left-name {
          font-size: 17px;
          font-weight: 800;
        }
        .left-dis {
          text-align: left;
        }
      }
      .title-right {
        width: 30px;
        height: 30px;
        img {
          width: 100%;
        }
      }
    }
    .address {
      text-align: left;
      color: $uni-text-color-grey;
      font-size: 14px;
      img {
        width: 20px;
        margin-right: 10px;
      }
    }
  }
  .building-bottom,
  .part-bottom {
    display: flex;
    justify-content: space-around;
    align-items: center;
    height: 60px;
    .positioning {
      opacity: 0.6;
    }
    .repositon {
      width: 70px;
      display: flex;
      flex-direction: column;
      i {
        color: $color-orange;
        font-size: 26px;
      }
    }
    .task,
    .collect,
    .part-detail {
      width: 120px;
      height: 36px;
      border-radius: 29px;
      line-height: 36px;
      i {
        margin-right: 4px;
      }
    }
    .task {
      border: solid 1px $color-deep;
      i {
        color: $color-black;
        font-size: 20px;
        display: inline-block;
        transform: translateY(3px);
      }
      span {
        color: $uni-text-color-grey;
      }
    }
    .collect,
    .part-detail {
      background: $color-blue;
      color: $color-white;
      img {
        width: 20px;
        height: 20px;
        transform: translateY(8px);
      }
    }
  }
  .part-bottom {
    justify-content: flex-end;
    .part-detail {
      margin-right: 15px;
    }
  }
}
</style>