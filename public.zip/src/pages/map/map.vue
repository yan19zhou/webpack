<template>
  <view class="map-wrap">
    <view id="map"></view>
  </view>
</template>
 
<script>
import { Map } from "./js/map";
export default {
  props: {
    type: String,
  },

  data() {
    return {
      map: null,
    };
  },
  mounted() {
    this.map = new Map();
    this.map.createMap().then((res) => {
      if (res) {
        this.mapInstance = res;
        this.map.drawGridArea("CGCS2000");
      }
    });
  },

};
</script>
 
<style lang="scss" scoped>
.map-wrap {
  width: 100%;
  height: 100%;
  position: relative;
  #map {
    width: 100%;
    height: 100%;
  }
  .center-point {
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -100%);
    font-size: 24px;
    color: $color-blue;
  }
}
</style>
