// map页面数据请求
import { getBuildingList,searchBuilding } from "@/api/building.js";
import { saveLocation, getMapParts, getPartMenus,searchParts } from "@/api/map.js";
import { MODEL_API } from "@/api/api-config.js";

export function getBuildingData(state) {
  return new Promise((resolve, reject) => {
    getBuildingList()
      .then((res) => {
        state && (state.buildingList = res);
        sessionStorage.setItem("_buildingList", JSON.stringify(res));
        resolve(res);
      })
      .catch((err) => {
        reject(err);
      });
  });
}

export function savePosition(params, map, modelName) {
  return new Promise((resolve, reject) => {
    saveLocation(params)
      .then(() => {
        getBuildingData()
          .then((result) => {
            map.creatLayer(getBuildingsParam(result, modelName));
            resolve("OK");
          })
          .catch((err) => {
            reject(err);
          });
      })
      .catch((err) => {
        reject(err);
      });
  });
}

export function getPartMapInfo(hasMenu, modelName, map) {
  // 获取地图上的部件信息
  if (hasMenu) {
    // 获取部件的二级菜单
    getPartMenus(modelName).then((res) => {
      _processData(res, map, modelName)
    });
  } else {
    getMapParts(modelName).then((res) => {
      _processData(res, map, modelName)
    });
  }
}

function _processData(res, map, modelName) {
  if (!res.length) {
    map.creatLayer([]);
  } else {
    map.creatLayer(getBuildingsParam(res, modelName));
  }
}
export function getBuildingsParam(data, modelName) {
  let icons = JSON.parse(sessionStorage.getItem("globalIcons"));
  let icon = icons.objectIcon[modelName].map;
  let param = [];
  for (let i = 0; i < data.length; i++) {
    let item = {};
    item.cood = data[i].coordinate?data[i].coordinate.split(","):data[i].coordinates.split(",");
    item.attr = {
      name: data[i].name,
      address: data[i].address,
      uuid: data[i].uuid,
      far: data[i].far,
      iconPath: MODEL_API + icon,
      coordinate: item.cood,
      modelName:modelName,
      parent_model:data[i].$parent_model,
      parent_id:data[i].$parent_id
    };
    param.push(item);
  }
  return param;
}

// 查询
export function searchMapParts(keyword,modelName,map){
  if (modelName=="MODEL_BUILDING") {
    searchBuilding(keyword).then(res=>{
      _processData(res, map, modelName)
    })
  }else{
    searchParts(keyword).then(res=>{
      _processData(res, map, modelName)
    })
  }

}