import { loadModules, setDefaultOptions, loadCss } from "esri-loader";

import { getGridArea } from "@/api/map.js";
import { MODEL_API } from "@/api/api-config.js";
setDefaultOptions({ version: "3.29" });
loadCss("3.29");
let image = require("static/images/location.png");
export class Map {
  constructor(options = {}) {
    /* 
    options:container 容器id
            openPop：是否打开弹窗
            extentChangeEvent:是否添加移动监听
            addGridArea:是否花网格区域
            showPositionIcon:是否定位到当前位置
    */
    this.options = {
      container: options.container || "map", // 地图容器
      openPop: options.container || false, // 是否弹出地图底部操作面板
      extentChangeEvent: options.container || true, // 监听地图移动
      addGridArea: options.addGridArea || true, // 画网格区域
      showPositionIcon: options.showPositionIcon || false, // 显示部件，楼栋图标点
      moveCenter: options.moveCenter || false, // 显示中心点 并移动中心实现定位
      initCoordinate: options.initCoordinate, // 初始化坐标点，目前用在部件表单反显
    };
    this.codes = [sessionStorage.getItem("$gridCode")]; //当前网格
    this.graphicLayer; // 图层
    this._activePoint; // 当前选中的点图层
    this._isMovePoint = false;
    this.localPosition = sessionStorage.getItem("_UserPeriodLocation");
    this.localPoint; //当前位置点
    this.icon_size_before = { width: 33, height: 33 };
    this.icon_size_after = { width: 40, height: 40 };

  }
  createMap() {
    let _this = this;
    return new Promise((resolve, reject) => {
      loadModules([
        "esri",
        "esri/map",
        "esri/geometry/geodesicUtils",
        "esri/layers/ArcGISTiledMapServiceLayer",
        "esri/layers/GraphicsLayer",
      ])
        .then(
          ([
            esri,
            Map,
            GeodesicUtils,
            ArcGISTiledMapServiceLayer,
            GraphicsLayer,
          ]) => {
            if (!_this.mapInstance) {
              _this.mapInstance = new Map(_this.options.container, {
                logo: false,
                zoom: 3,
                center: [113.86277157552, 22.694593614000075],
              });
              //添加地图图层
              _this.layer = new ArcGISTiledMapServiceLayer(
                "https://ldxxcc.baoan.gov.cn/ldxcxc/arcgis/rest/services/BAKSJ/DTVEC_QS_ZQ_BA/MapServer"
              );
              // _this.layer = new ArcGISTiledMapServiceLayer("http://10.99.85.107:6080/arcgis/rest/services/BAKSJ/DTVEC_QS_ZQ_BA/MapServer")
              _this.mapInstance.addLayer(_this.layer);
              _this.geodesicUtils = GeodesicUtils;
              _this.graphicLayer = new GraphicsLayer();
              // 复制esri对象
              _this.esri = esri;
              // 调用其他方法时进入
              // 添加一个地图移动的监听事件
              if (_this.options.extentChangeEvent) {
                _this._AddExtentChangeEvent();
              }
              // 定位到当前网格并画出网格线
              if (_this.options.addGridArea) {
                _this.drawGridArea();
              }
              // 定位到当前位置
              if (_this.options.showPositionIcon) {
                _this._showPositionIcon();
              }
              if (_this.options.initCoordinate) {
                _this._toInitialPosition();
              }
            }

            // 监听地图点击事件
            // if (_this.options.openPop) {
            _this._addMapEvent();
            // }
            resolve(_this.mapInstance);
          }
        )
        .catch((err) => {
          reject(err);
        });
    });
  }
  emitPopupToggle(type, attr) {
    uni.$emit("showMapPop", { type, attr });
  }
  //返回楼栋数据时添加标注并定位
  creatLayer(data) {
    
    let _this = this;
    let isChangeExpand = true; // 是否调整地图视野和中心点
    if (data) {
      sessionStorage.setItem("_buildingPoints", JSON.stringify(data));
    } else {
      data = JSON.parse(sessionStorage.getItem("_buildingPoints")) || [];
      isChangeExpand = false;
    }
    //对标记点重新赋值
    _this._isMovePoint = false;
    _this.graphicLayer.clear();
    let points = []; // 图形坐标
    //获取楼栋坐标，进行标点
    for (let i = 0; i < data.length; i++) {
      // 创建图层
      let iconPath = data[i].attr.iconPath
        ? data[i].attr.iconPath
        : "assets/images/icon/position.svg";
      _this.addPoint(data[i].cood, iconPath, data[i].attr);
      let pt = new _this.esri.geometry.Point(
        data[i].cood[0],
        data[i].cood[1],
        _this.mapInstance.spatialReference
      );
      points.push(pt); // 添加坐标
    }
    _this.mapInstance.addLayer(_this.graphicLayer);
    if (points.length > 0) {
      let polygon = new _this.esri.geometry.Polygon(
        new _this.esri.SpatialReference(4490)
      );
      polygon.addRing(points); // 添加坐标
      if (isChangeExpand) {
        _this.mapInstance.setExtent(polygon.getExtent().expand(2.5)); // 改变缩放程度
      }
    }
  }
  addPoint(location, image, attr) {
    // console.log(location, image);
    var ptTemp = new this.esri.geometry.Point(
      location,
      this.mapInstance.spatialReference
    );
    var markerSymbolTemp = new this.esri.symbol.PictureMarkerSymbol(
      image,
      this.icon_size_before.width,
      this.icon_size_before.height
    ).setOffset(0, 15);
    var dragGraphicTemp = new this.esri.Graphic(ptTemp, markerSymbolTemp, attr);
    this.graphicLayer.add(dragGraphicTemp);
  }
  showLocation(type) {
    //显示当前位置
    if (type) {
      if (this.localPosition) {
        this.graphicLayer.clear();
        let [x, y] = this.localPosition.split(",");
        var ptLocal = new this.esri.geometry.Point(
          [x, y],
          new this.esri.SpatialReference(4490)
        );
        //创建标注
        var symbol = new this.esri.symbol.SimpleMarkerSymbol(
          this.esri.symbol.SimpleMarkerSymbol.STYLE_CIRCLE,
          12,
          new this.esri.symbol.SimpleLineSymbol(
            this.esri.symbol.SimpleLineSymbol.STYLE_SOLID,
            new this.esri.Color([210, 105, 30, 0.5]),
            8
          ),
          new this.esri.Color([210, 105, 30, 0.9])
        );
        //创建图层
        this.localPoint = new this.esri.Graphic(ptLocal, symbol);
        // this.mapInstance.centerAndZoom(ptLocal, 8);
        this.graphicLayer.add(this.localPoint);
        // 当前位置是否在网格内
        if (this.gridPolygon) {
          var localPoint = new this.esri.geometry.Point(
            [x, y],
            new this.esri.SpatialReference(4490)
          );
          // 当前位置在网格内
          if (this.gridPolygon.contains(localPoint)) {
            uni.showToast({title:"当前位置不在所属网格内"});
          }
        }
      } else {
        alert(
          "Browser doesn't support Geolocation. Visit http://caniuse.com to see browser support for the Geolocation API."
        );
      }
    } else {
      this.localPoint && this.graphicLayer.clear();
    }
  }
  _addPolygon(data) {
    // 网格线图层
    if (!data.length) return;
    let boundLayer = new this.esri.layers.GraphicsLayer({
      className: "svg_class",
    });
    // 网格线
    let lineSymbol = new this.esri.symbol.SimpleLineSymbol(
      this.esri.symbol.SimpleLineSymbol.STYLE_SOLID,
      new this.esri.Color([10, 0, 0]),
      1
    );
    let symbol = new this.esri.symbol.SimpleFillSymbol(
      this.esri.symbol.SimpleFillSymbol.STYLE_SOLID,
      lineSymbol,
      new this.esri.Color([255, 255, 0, 0.9])
    );
    let renderer = new this.esri.renderer.ClassBreaksRenderer(symbol, "PCount");

    renderer.addBreak(
      0,
      100,
      new this.esri.symbol.SimpleFillSymbol(
        this.esri.symbol.SimpleFillSymbol.STYLE_SOLID,
        lineSymbol,
        new this.esri.Color([199, 235, 250, 0])
      )
    );
    //渲染
    boundLayer.setRenderer(renderer);
    this.mapInstance.addLayer(boundLayer);
    let attributes;
    let polygonSymbol = new this.esri.symbol.SimpleFillSymbol(
      "solid",
      new this.esri.symbol.SimpleLineSymbol(
        "solid",
        new this.esri.Color([248, 192, 21, 1]),
        4
      ),
      new this.esri.Color([3, 126, 245, 0.23])
    ); //面样式对象
    this.gridPolygon = new this.esri.geometry.Polygon(
      new this.esri.SpatialReference(4490)
    );
    this.gridPolygon.addRing(data[0].coordinates.coordinates[0]);
    let gra = new this.esri.Graphic(this.gridPolygon);
    gra.setSymbol(polygonSymbol);
    attributes = data[0];
    //给地图赋值一个属性graattribute["code"]做后台数据绑定
    attributes["PCount"] = 2;
    attributes["gridCode"] = this.codes[0]; // 添加网格号
    gra.setAttributes(attributes);
    boundLayer.add(gra);
    this.mapInstance.setExtent(this.gridPolygon.getExtent().expand(1.2)); // 地图定位
    boundLayer.setRenderer(renderer);
    boundLayer.refresh();
  }
  drawGridArea(spatial) {
    //spatial:坐标系
    //获取网格数据并划出网格
    let params = {
      codeList: this.codes.slice(0, 1),
    };
    getGridArea(spatial, params).then((res) => {
      this._addPolygon(res);
    });
  }
  getDis(coordinate) {
    // 获取当前位置离目标点距离
    let _this = this;
    let dis;
    if (this.localPosition) {
      let [x, y] = this.localPosition.split(","),
        cood = coordinate.split(",");
      //当前坐标
      let ptLocal = new _this.esri.geometry.Point(
        [x, y],
        new _this.esri.SpatialReference(4490)
      );
      //点击坐标
      let ptclick = new _this.esri.geometry.Point(
        [Number(cood[0]), Number(cood[1])],
        new _this.esri.SpatialReference(4490)
      );
      //测量距离 详见：https://developers.arcgis.com/javascript/3/jsapi/esri.geometry.geodesicutils-amd.html#geodesiclengths
      let polyline = new _this.esri.geometry.Polyline(
        _this.mapInstance.spatialReference
      );
      polyline.addPath([ptLocal, ptclick]);
      //Units为测量单位，详见：https://developers.arcgis.com/javascript/3/jsapi/units-amd.html
      dis = _this.geodesicUtils
        .geodesicLengths([polyline], _this.esri.Units.METERS)[0]
        .toFixed(2);
    } else {
      dis = 0;
    }
    return dis;
  }
  setActivePointCenter() {
    // 以当前选择对象为中心点
    this._isMovePoint = true;

    let tempPoint = new this.esri.geometry.Point(
      this._activePoint.graphic.geometry.x,
      this._activePoint.graphic.geometry.y,
      this.mapInstance.spatialReference
    );
    this.mapInstance.centerAt(tempPoint); // 定位到中心点
    this._activePoint.graphic.symbol.url = `${MODEL_API}/icon/img/map/chosen_building.png`;
    this.graphicLayer.refresh();
  }
  _addMapEvent() {
    let _this = this;
    // 地图点击事件
    let temp;
    _this.mapInstance.on("click", function(evt) {
      if (evt.graphic) {
        if (evt.graphic.symbol) {
          if (
            evt.graphic.symbol instanceof _this.esri.symbol.SimpleFillSymbol
          ) {
            _this.emitPopupToggle("hide");
            _this.creatLayer([]);
            return;
          }
          if (temp) {
            temp.symbol.width = _this.icon_size_before.width;
            temp.symbol.height = _this.icon_size_before.height;
            _this.graphicLayer.refresh();
          }
          temp = evt.graphic;
          _this._activePoint = evt;
          evt.graphic.symbol.width = _this.icon_size_after.width;
          evt.graphic.symbol.height = _this.icon_size_after.height;
          _this.graphicLayer.refresh();
          let attr = evt.graphic.attributes;
          attr.dis = _this.getDis(attr.coordinate);

          _this.emitPopupToggle("show", attr);
        } else {
          if (temp) {
            temp.symbol.width = _this.icon_size_before.width;
            temp.symbol.height = _this.icon_size_before.height;
            _this.graphicLayer.refresh();
          }
          _this.emitPopupToggle("hide");
          _this.creatLayer([]);
        }
      } else {
        if (temp) {
          temp.symbol.width = _this.icon_size_before.width;
          temp.symbol.height = _this.icon_size_before.height;
          _this.graphicLayer.refresh();
        }
        _this.emitPopupToggle("hide");
        _this.creatLayer();
      }
    });
  }
  _AddExtentChangeEvent() {
    let _this = this;
    _this.mapInstance.on("extent-change", function() {
      if (_this.mapInstance.extent.xmin) {
        let x = _this.mapInstance.extent.getCenter().x,
          y = _this.mapInstance.extent.getCenter().y;
        if (_this.options.moveCenter) {
          //对标记点重新赋值
          _this.graphicLayer.clear();
          _this.addPoint([x, y], image);
          uni.$emit("getpoint", `${x},${y}`);
          _this.graphicLayer.refresh();
          _this.mapInstance.addLayer(_this.graphicLayer);
        }
        if (_this._isMovePoint) {
          let geometry = _this._activePoint.graphic.geometry;
          geometry.x = x;
          geometry.y = y;
          _this._activePoint.graphic.setGeometry(geometry);
          _this.graphicLayer.refresh();
        }
      }
    });
  }
  _toInitialPosition() {

    let crood =this.options.initCoordinate.split(",")

    let point_arcgis = new this.esri.geometry.Point(
      crood[0],
      crood[1],
      this.mapInstance.spatialReference
    );
    this.mapInstance.centerAndZoom(point_arcgis, 5);
  }
}
