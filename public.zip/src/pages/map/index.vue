<template>
  <!-- 地图 -->
  <view class="map-view">
    <!-- <van-tabs
      v-model:active="active"
      title-active-color="#4768F3"
      color="#4768F3"
      title-inactive-color="#999"
      class="map-tabs"
      line-width="82"
      line-height="2"
      @change="tabChange"
    >
      <van-tab title="楼栋" name="MODEL_BUILDING"></van-tab>
      <van-tab title="部件" name="MODEL_CITY_COMPONENTS"></van-tab>
    </van-tabs>
    <van-search
      v-model="state.keyword"
      show-action
      placeholder="请输入搜索关键词"
      @search="onSearch"
      class="search"
    >
      <template #action>
        <a class="scan" @click="scanSearch">
          <van-icon name="scan" class="scan-icon" />
          <span>扫一扫</span>
        </a>
      </template>
    </van-search> -->
    <view class="main">
      <!-- <BuildingList
        start="MODEL_BUILDING"
        v-show="active == 'MODEL_BUILDING'"
        :key="kes.building"
      />
      <PartsBar
        ref="partNode"
        start="MODEL_CITY_COMPONENTS"
        v-show="active == 'MODEL_CITY_COMPONENTS'"
        @choosePart="choosePart"
      /> -->
      <Map :points="points" ref="map" :key="kes.map"/>
      <view class="right-btns">
        <view class="query-btn icon-wrap" @click="queryAdd">
          <text class="icon iconfont iconsousuo1" v-if="active == 'MODEL_BUILDING'"></text>
          <!-- <van-icon name="plus" v-else /> -->
        </view>
        <view class="position-btn">
          <view
            v-if="active == 'MODEL_BUILDING'"
            :class="[
              'buildings-btn',
              'icon-wrap',
              isShowBuilding ? 'text-blue' : '',
            ]"
            @click="setBuildingPosition"
          >
            <i class="iconfont iconxianshisuoyou"></i>
          </view>
          <view
            :class="[
              'self-position',
              'icon-wrap',
              isShowLocation ? 'text-blue' : '',
            ]"
            @click="showLocation"
          >
            <i class="iconfont icondingwei"></i>
          </view>
        </view>
      </view>
      <!-- <transition name="van-slide-up">
        <condition-query
          @close="colse"
          :isshow="isShowSearchPage"
        ></condition-query>
      </transition> -->
    </view>
    <!-- <transition name="van-slide-up">
      <BuildingDetail
        ref="buildingDetail"
        @reposition="reposition"
        @positionCancel="positionCancel"
        @positionSave="positionSave"
        :activeStart="active"
      />
    </transition> -->
  </view>
</template>

<script>

import BuildingList from "./components/building-list";
import PartsBar from "./components/parts-bar.vue";
import Map from "./map";
import BuildingDetail from "./components/building-detail";
import ConditionQuery from "./components/query/condition-query";

import { scanQrcode } from "@/js/wxCommon.js";

import {
  savePosition,
  getBuildingsParam,
  getPartMapInfo,
  searchMapParts
} from "./js/getDatas.js";
export default {
  name: "mapIndex",
  components: {
    // BuildingList,
    // PartsBar,
    Map,
    // BuildingDetail,
    // ConditionQuery,
  },
  setup() {
    let active = ref("MODEL_BUILDING");
    let state = reactive({ keyword: "" });
    let map = ref(null);

    /* 
   右侧按钮操作
*/
    //楼栋显示地图坐标点
    const router = useRouter();
    let points = reactive(null);
    let modelName = ref("MODEL_BUILDING"); // 当前部件的modelName

    let rightOperate = reactive({
      isShowBuilding: false, // 是否显示楼栋群
      isShowLocation: false, // 是否现在当前坐标
      isShowSearchPage: false, // 是否显示查询页面
      setBuildingPosition() {
        rightOperate.isShowBuilding = !rightOperate.isShowBuilding;
        if (rightOperate.isShowBuilding) {
          rightOperate.isShowLocation = false;
          let list = JSON.parse(sessionStorage.getItem("_buildingList"));
          points = getBuildingsParam(list, modelName.value);
          map.value.map.creatLayer(points);
        } else {
          map.value.map.creatLayer([]);
        }
      },
      showLocation() {
        // 显示隐藏当前位置
        rightOperate.isShowLocation = !rightOperate.isShowLocation;
        rightOperate.isShowLocation && (rightOperate.isShowBuilding = false);
        map.value.map.showLocation(rightOperate.isShowLocation);
      },
      queryAdd() {
        // 查询或添加
        if (active.value == "MODEL_BUILDING") {
          //快速查询
          if (!rightOperate.isShowSearchPage)
            rightOperate.isShowSearchPage = true;
        } else {
          //快捷添加部件
          router.push({
            path: "/commonForm",
            query: {
              toKey: "",
              to: currentPart.modelName,
              name: currentPart.modelDecribe,
              pathStart: active.value,
            },
          });
        }
      },
      colse() {
        rightOperate.isShowSearchPage = false;
      },
    });

    // 底部小弹窗
    let buildingDetail = ref(null);
    let positionState = reactive({
      reposition: () => {
        map.value.map.setActivePointCenter();
      },
      positionCancel: () => {
        map.value.map.creatLayer([]);
      },
      positionSave: ({ uuid }) => {
        //保存重新定位
        console.log(uuid);
        let point = map.value.map._activePoint.graphic.geometry;
        console.log(point);
        let params = {
          uuid: uuid,
          coordinates: `${point.x},${point.y}`,
          tableName: modelName.value,
        };
        savePosition(params, map.value.map, modelName.value).then((res) => {
          if (res == "OK") {
            console.log();
            buildingDetail.value.saveSuccess();
          }
        });
      },
    });

    // 部件
    const partNode = ref(null);
    let currentPart = reactive({});
    const choosePart = (item) => {
      currentPart = item;
      getPartMapInfo(item.hasMenu, item.modelName, map.value.map);
    };
    const tabChange = () => {
      if (active.value == "MODEL_CITY_COMPONENTS") {
        let item = partNode.value.menuDatas[partNode.value.activeIndex];
        if (item) {
          currentPart = item;
        getPartMapInfo(item.hasMenu, item.modelName, map.value.map);
        }
      }
    };
    // 顶部查询组件
    const onSearch = () => {
      if (active.value == "MODEL_CITY_COMPONENTS") {
        modelName.value = currentPart.modelName;
      } else {
        modelName.value = "MODEL_BUILDING";
      }
      searchMapParts(state.keyword, modelName.value, map.value.map);
    };
    const scanSearch = () => {
      scanQrcode((res) => {
        console.log(res);
        state.keyword = res.resultStr;
        onSearch();
      });
    };

    return {
      active,
      state,
      map,
      points,
      buildingDetail,
      choosePart,
      tabChange,
      partNode,
      ...toRefs(positionState),
      ...toRefs(rightOperate),
      onSearch,
      scanSearch,
    };
  },
  data() {
    return {
      gridCode: sessionStorage.getItem("$gridCode"),
      kes:{
        map:0,
        building:0
      },
      points:[]
    };
  },
  onTabItemTap() {
    if (this.gridCode !== sessionStorage.getItem("$gridCode")) {
      // 如果更改了网格，重新初始化地图
      this.kes.map=Math.random();
      this.kes.building =Math.random();
      this.gridCode = sessionStorage.getItem("$gridCode");

    }
  },
};
</script>
<style lang="scss" scoped >
.map-view {
  .map-tabs {
    width: 200px;
    height: 48px;
    margin: 0 auto;
  }
  .search {
    display: flex;
    align-items: center;
    height: 48px;
    // margin-top: 12px;
    padding-left: 16px;

    .scan {
      width: 50px;
      display: flex;
      flex-direction: column;

      .scan-icon {
        font-size: 24px;
      }
      span {
        font-size: 12px;
      }
    }
  }
  .main {
    position: relative;
    height: calc(100vh - 50px);
    .map {
      width: 100%;
      height: 100%;
    }
    .right-btns {
      color: $uni-text-color;
      z-index: 50;
      .icon-wrap {
        width: 36px;
        height: 36px;
        font-size: 16px;
        position: absolute;
        right: 20px;
        line-height: 36px;
        text-align: center;
        background-color: #fff;
        box-shadow: 1px 2px 6px #aaa;
        border-radius: 50%;
      }

      .query-btn {
        top: 40px;
        .van-icon {
          font-size: 20px;
          line-height: 38px;
        }
      }
      .buildings-btn {
        bottom: 150px;
      }
      .self-position {
        bottom: 100px;
      }
    }
  }
}
</style>
<style lang="scss">
.search {
  .van-search__action {
    line-height: 20px;
  }
  .van-cell {
    line-height: 24px;
    padding: 4px !important;
  }
}
</style>