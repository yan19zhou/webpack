<template>
  <view style="overflow: hidden">
    <!-- nav导航栏 -->
    <!-- 筛选 -->
    <view class="header flex-bw">
      <span class="f18 text-dark">{{ modelName }}</span>
      <Strategys-search type="next-form" @change="strategysChange" />
    </view>
    <!-- VR -->
    <router-link
      v-if="showVr && Ids.toKey"
      :to="{ path: '/collectVr', query: { bid: Ids.toKey, type: Ids.to } }"
      exact
    >
      <view v-if="showVr" class="row link-VR flex-bw" style="">
        <view style="display: flex; align-items: center">
          <i class="iconfont iconvedio"></i><span>采集VR</span>
        </view>
        <van-icon name="arrow" color="#fff" />
      </view>
    </router-link>
    <view class="form">
      <Form :Ids="Ids" @vrChange="vrChange" :modelName="model" />
    </view>
    <!-- 显示隐藏选择列表按钮 -->
    <view class="right-btns">
      <van-button
        icon="search"
        type="primary"
        class="handler-list mb8"
        @click="handlerList"
      />
      <c-toTop ele="form-container" />
    </view>
    <!-- 选择列表 -->
    <Popup
      :isshow="showPopup"
      :Ids="Ids"
      @changeValue="changeValue"
      :modelName="modelName"
      @close="closeP"
    />
  </view>
</template>

<script>
import Form from "./components/form";
import Popup from "./components/popupList/next-popup.vue";
import StrategysSearch from "./components/strategys-search";
import { useRoute, onBeforeRouteUpdate } from "vue-router";
import { reactive, ref, provide } from "vue";
export default {
  components: {
    Form,
    Popup,
    StrategysSearch,
  },
  setup() {
    let route = useRoute();

    let Ids = reactive(
      Object.assign(
        { to: "", from: "", fromKey: "", toKey: "", name: "" },
        route.query
      )
    );
    let showPopup = ref(false);
    if (!Ids.toKey) {
      showPopup.value = true;
    }
    const handlerList = () => {
      showPopup.value = true;
    };
    const closeP = () => {
      showPopup.value = false;
    };
    let modelName = ref(Ids.name);
    let model = ref(Ids.to);
    onBeforeRouteUpdate((to) => {
        Ids.name = to.query.name;
        Ids.to = to.query.to;
        Ids.from = to.query.from;
        Ids.fromKey = to.query.fromKey;
        model.value = to.query.to;
        modelName.value = to.query.name;
        var k = to.query.from + to.query.fromKey + to.query.to;
        if (!Ids.toKey) {
          Ids.toKey = sessionStorage.getItem(k);
          sessionStorage.setItem(k, "");
          setTimeout(() => {
            showPopup.value = true;
          });
        }
    });
    let showVr = ref(false);
    const vrChange = (item) => {
      if (item.type) {
        showVr.value = item.type;
      }
      if (item.toKey) {
        Ids.toKey = item.toKey;
      }
    };
    /**
     * 改变表单主键信息
     */
    const changeValue = (item) => {
      Ids.toKey = item.uuid;
      var k = Ids.from + Ids.fromKey + Ids.to;
      sessionStorage.setItem(k, item.uuid);
      showPopup.value = false;
    };
    /* 采查策略 */
    let strategys = reactive({ checked: [] });
    const strategysChange = (v) => {
      strategys.checked = v;
    };
    provide("checked", strategys);

    return {
      Ids,
      handlerList,
      showPopup,
      showVr,
      vrChange,
      closeP,
      modelName,
      model,
      changeValue,
      strategysChange,
    };
  },
};
</script>

<style lang="scss" scoped>
.header {
  height: 40px;
  span {
    font-weight: 400;
  }
}
.form {
  height: calc(100% - 40px);
  overflow-y: auto;
}
.right-btns {
  width: 50px;
  position: fixed;
  right: 0;
  bottom: 56px;
  .handler-list {
    width: 40px;
    height: 40px;
  }
}
.flex-bw {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding-left: 20px;
  padding-right: 20px;
  padding-top: 0.4rem;
  padding-bottom: 0.4rem;
  box-sizing: border-box;
  @include font_size(36rpx);
}
.link-VR {
  height: 30px;
  line-height: 30px;
  color: #fff;
  background: $color-blue;
  .iconvedio {
    margin-right: 6px;
    font-size: 14px;
    color: #fff;
  }
}
</style>