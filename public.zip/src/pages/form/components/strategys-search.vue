<!--
 * @Description: 采查策略筛选组件
 * @Author: zhouy
 * @Date: 2021-10-20 11:16:29
 * @LastEditTime: 2021-10-22 16:07:11
 * @LastEditors: zhouy
-->
<template>
  <c-dropdown>
    <u-checkbox-group v-model="checked" @change="closed" v-if="list && list.length">
      <u-cell-group>
        <u-cell-item v-for="(item, index) in list" :key="item.value">
          <u-checkbox :name="item.value" :ref="(el) => (checkboxRefs[index] = el)" class="mr4 checkbox-icon">
            {{ item.name }}
          </u-checkbox>
        </u-cell-item>
      </u-cell-group>
    </u-checkbox-group>
    <template #reference>
      <view class="search text-blue" >
        <text class="iconfont iconshaixuan mr4 f12"></text>
        <text>筛选...</text>
      </view>
    </template>
  </c-dropdown>
</template>

<script>
import { getStrategys } from "@/api/form/form.js";

export default {
  name: "StrategysSearch",
  data() {
    return {
      checked: [],
      checkboxRefs: [],
      list: [],
    };
  },
  methods: {
    toggle(index) {
      this.checkboxRefs[index].toggle();
    },
    async getData() {
      this.list = await getStrategys();
      sessionStorage.setItem("$strategys", JSON.stringify(this.list));
    },
    closed() {
      this.$emit("change", checked);
    },
    handlerSearch() {
      uni.$emit("handlerSearch");
    },
  },
};
</script>

<style lang="scss" scoped>
.search {
  padding: 6px 16px;
  margin-left: 12px;
  // flex: 0 0 auto;
  white-space: nowrap;
  border-radius: 20px;
  @include font_size(28rpx);
  box-shadow: 0px 0px 15px #fff, 0 0 10px #4287ff80;
}
</style>
<style lang="scss">
.checkbox-icon {
  .van-icon {
    font-size: 16px;
  }
}
</style>
