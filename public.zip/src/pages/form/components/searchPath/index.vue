<!--
 * @Descriptiosear  通用表单 模型选择列表路径选择组件
 * @Author: zhouy
 * @Date: 2021-10-09 09:52:36
 * @LastEditTime: 2021-10-25 18:25:43
 * @LastEditors: zhouy
-->
<template>
  <view>
    <view class="search-path">
      <van-field v-model="path" readonly placeholder="选择路径" type="text" autosize>
        <template #right-icon>
          <view class="search-btn" @click.stop="showAddressPop">
            <text class="iconfont iconshaixuan f14"></text>
            <text>筛选</text>
          </view>
        </template>
      </van-field>
    </view>
    <address-linkage v-if="openPopFlag" @getAddressData="getAddressData"> </address-linkage>
  </view>
</template>

<script>
import addressLinkage from "./selectAddress";
export default {
  name: "searchPath",
  components: {
    addressLinkage,
  },
  data() {
    return {
      openPopFlag: false,
      path: null,
    };
  },
  methods: {
    getAddressData(obj) {
      let str = "";
      console.log(obj);
      // 反显路径
      for (let i = 0; i < obj.arr.length; i++) {
        const ele = obj.arr[i];
        if (ele) {
          str += ele.title + " ";
        }
      }
      this.path = str;
      this.openPopFlag = obj.openPopFlag;
      this.$emit("getAddressUuid", obj.arr);
    },
    showAddressPop() {
      this.openPopFlag = true;
    },
  },
};
</script>

<style lang="scss" scoped>
.search-path {
  .search-btn {
    color: $color-blue;

    span {
      margin-left: 4px;
    }
  }
}
</style>
