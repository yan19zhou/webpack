<template>
  <view class="container">
    <view
      class="mask_container"
      @click.stop="closePopup"
      v-show="closeFlag"
    ></view>

    <view class="address_container" v-show="closeFlag">
      <span class="close" @click.stop="closePopup"></span>
      <view class="address_detail_info">
        <van-tabs
          v-model:active="activeName"
          @change="change"
          line-width="80px"
        >
          <van-tab
            :title="selectItems[index] || '请选择'"
            :name="item.key"
            :class="['address_nav_name', { nav_active: currentIndex == index }]"
            @click.stop="changeTab(index)"
            v-for="(item, index) in pathList"
            :key="item.key"
          >
            <view class="address_panel">
              <view class="address_panel_list">
                <van-cell
                  v-for="(item, i) in dataList[currentIndex]"
                  :title="item.title"
                  :key="item.key"
                  @click.stop="touchItem(item, i)"
                >
                  <template #right-icon>
                    <van-icon
                      v-if="item.title == selectItems[currentIndex]"
                      name="success"
                      class="select-icon"
                      color="#ff3b30"
                    />
                  </template>
                </van-cell>
              </view>
            </view>
          </van-tab>
        </van-tabs>
      </view>
    </view>
  </view>
</template>

<script>
import { getPathData } from "@/api/form/components.js";
export default {
  data() {
    return {
      closeFlag: true,
      activeName: "",
      currentIndex: 0,
      selectItems: [],
      dataList: [],
      parent_id: "",
      parent: "",
      pathArr: [],
    };
  },
  props: {
    address: String,
  },
  inject: ["getpathList"],
  computed: {
    pathList() {
      // pathList为多维数组，目前暂时取第一条，预留多路径情况
      var newArr = JSON.parse(JSON.stringify(this.getpathList()[0])); //join后再拆分为新数组
      newArr.pop();
      return newArr;
    },
  },
  created() {
    this.initAddressData();
  },
  mounted() {
    this.$nextTick(() => {
      this.returnTop(this.currentIndex);
    });
  },
  methods: {
    change(v) {
      this.currentIndex = this.pathList.findIndex((item) => {
        return item.key == v;
      });
    },
    // 首次渲染接口数据
    initAddressData() {
      this.getData(this.pathList[0].key);
    },

    // 获取一级楼栋数据
    getData(model) {
      let params = {
        model: model,
        parent: this.parent,
        parentId: this.parent_id,
      };
      getPathData(params).then((res) => {
        this.dataList[this.currentIndex] = res;
      });
    },
    touchItem(item) {
      let _this = this;
      this.pathArr = [];
      this.selectItems[this.currentIndex] = item.title;
      this.pathArr[this.currentIndex] = {
        title: item.title,
        key: item.key,
        model: this.pathList[this.currentIndex].key,
      };
      this.currentIndex++;
      this.parent = this.activeName;
      this.parent_id = item.key;
      if (this.currentIndex == this.pathList.length) {
        // 点击最后一项时
        this.closeFlag = false;
        this.getAddressData(this.pathArr);
        return;
      }
      let params = {
        model: this.pathList[this.currentIndex].key,
        parent: this.parent,
        parentId: this.parent_id,
      };
      getPathData(params).then((res) => {
        _this.dataList[_this.currentIndex] = res;
        _this.activeName = _this.pathList[_this.currentIndex].key;
        // _this.selectItems[_this.currentIndex] = _this.selectItems.slice(0, this.currentIndex);
        // 如果回点上级把下级选中清空
        for (let i = _this.currentIndex; i < _this.pathArr.length; i++) {
          _this.pathArr[i] = { title: "", key: "" };
          _this.selectItems[i]=''
        }
      });
    },
    // 点击tabBar切换
    changeTab(index) {
      this.currentIndex = index;
      // console.log(text)
      // if () {}
      this.$nextTick(() => {
        this.returnTop(index);
      });
    },
    getAddressData(arr) {
      let obj = {
        arr: arr,
        openPopFlag: this.closeFlag,
      };
      this.$emit("getAddressData", obj);
    },

    // 关闭弹窗
    closePopup() {
      this.closeFlag = false;
      this.getAddressData(this.pathArr);
    },
    returnTop(currentIndex) {
      // 条目的容器，进行向上滚动操作(address_panel_list)
      let addressPanelList = document.getElementsByClassName(
        "address_panel_list"
      );
      let activeItem = document.getElementsByClassName("panel_item_active");
      let activeItemIndex = currentIndex;
      // 可视区屏幕高度
      let clientHeight =
        document.documentElement.clientHeight || document.body.clientHeight;
      // 地址ul面板距离顶部的距离
      let addressPanelClientTop = addressPanelList[
        activeItemIndex
      ].getBoundingClientRect().top;
      // 距离容器顶部距离
      let addressPanelTop = addressPanelList[activeItemIndex].offsetTop;
      // 激活元素距离容器顶部距离
      if (activeItem[activeItemIndex] != undefined) {
        let activeItemTop = activeItem[activeItemIndex].offsetTop;
        // 判断激活元素是否进入容器可视区
        let distance =
          addressPanelClientTop -
          addressPanelTop +
          activeItemTop -
          clientHeight;
        if (distance >= 0) {
          // 激活元素在容器底部，不在容器可视范围，进行滚动，让激活元素到可视区
          let scrollTopMargin = distance + addressPanelTop;
          addressPanelList[currentIndex].scrollTop = scrollTopMargin;
        }
      }
    },
  },
};
</script>

<style lang="scss" scoped>
// 布局
@mixin center(
  $justifyContent: center,
  $alignItems: center,
  $flexDirection: row
) {
  display: flex;
  display: -webkit-flex;
  justify-content: $justifyContent;
  align-items: $alignItems;
  flex-direction: $flexDirection;
}

@mixin close_sign() {
  display: inline-block;
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  right: 10px;

  &:after {
    content: "\2715"; //形状X
    color: #666666;
    font-size: 12px;
    cursor: pointer;
  }
}
p,
view,
ul,
li {
  padding: 0;
  margin: 0;
}

$addressBgColor: #fff;
$addressHeight: 50px;

.mask_container {
  position: fixed;
  z-index: 100;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background-color: rgba(0, 0, 0, 0.4);
}

.address_container {
  position: fixed;
  z-index: 1000;
  height: 75vh;
  width: 100%;
  background-color: $addressBgColor;
  left: 0;
  bottom: 0;
  .close {
    @include close_sign();
    width: 20px;
    height: 20px;
    text-align: center;
    line-height: 20px;
    top: 20px;
    border-radius: 50%;
    background: #cccccc63;
    z-index: 9999;
  }
  .address_nav {
    height: 50px;
    border-bottom: 1px #ccc solid;
    background-color: $addressBgColor;
    @include center(flex-start);

    .address_nav_name {
      height: 100%;
      padding: 0 10px;
      @include center();

      &.nav_active {
        border-bottom: 1px solid red;
      }
    }
  }
  .address_detail_info {
    height: calc(100% - 40px);
    // tab标题

    // 主体内容
    .address_panel {
      height: calc(100% - 70px);
      .address_panel_list {
        overflow-y: auto;
        height: 100%;
      }
    }
  }
}
.select-icon {
  line-height: 24px;
  font-size: 18px;
}
</style>
<style lang="scss">
.address_detail_info {
  .van-tab {
    display: inline-block;
    flex: initial;
    padding: 20px;
  }
  .van-cell__title {
    padding-left: 10px;
  }
}
</style>

