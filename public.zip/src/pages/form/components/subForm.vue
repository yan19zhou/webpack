<template>
  <!-- 子模型组件 -->
  <van-collapse v-model="activeNames" class="sub-form" accordion="true">
    <van-collapse-item :name="index + 1" class="sub-form-item" v-for="(table, index) in modelAttrs" :key="table.base.table_name" :title="table.base.table_comment">
      <template #title>
        <view class="sub-form-title">
          {{ table.base.table_comment }}
        </view>
      </template>
      <van-steps class="sub-form-step" direction="vertical" :active="-999" inactive-icon="">
        <van-step v-for="(item, i) in state.data[index]" :key="item">
          <p class="step-title">
            <span>{{ table.base.table_comment + i }}</span>
            <i class="iconfont iconlajitong1 color-red" @click="deleteExtendtable(item, index, i)" v-if="table.base.sign_more"></i>
          </p>
          <Form :parentIds="parentIds" :modelAttrs="table.attrs" :formData="state.data[index][i]" :ref="(e) => setItemRef(e, index, i)" />
        </van-step>
      </van-steps>
      <view class="add-btn" @click="add(index)" v-if="table.base.sign_more">
        <van-icon name="add" color="#4287FF" class="add-icon" />
        <span class="add-text">添加{{ table.base.table_comment }}</span>
      </view>
    </van-collapse-item>
  </van-collapse>
</template>

<script>
import Form from "./baseForm.vue";
import { getFormObj } from "../js/getModel";
import { delExtendTable } from "@/api/form/form.js";
import { reactive, ref, onBeforeUpdate, watch } from "vue";

export default {
  components: {
    Form,
  },
  props: {
    parentIds: Object,
    modelAttrs: Object,
  },
  setup(props) {
    const activeNames = ref([]);
    let state = reactive({ data: [] });
    // form节点
    let itemRefs = reactive(initArr(props.modelAttrs.length));
    const setItemRef = (el, index, i) => {
      itemRefs[index][i] = el;
    };
    onBeforeUpdate(() => {
      itemRefs = initArr(props.modelAttrs.length);
    });

    watch(
      () => activeNames,
      (newValue) => {
        let i = newValue.value - 1;
        if (newValue.value) {
          if (state.data[i]) return;
          let table_name = props.modelAttrs[i].base.table_name;
          if (props.parentIds.toKey) {
            loadData(table_name, i, props.modelAttrs[i]);
          } else {
            state.data[i] = getAttr(props.modelAttrs[i]);
          }
        }
      },
      { deep: true }
    );

    /* 加载模型扩展表单反显数据*/
    const loadData = (tableName, index, item) => {
      let params = {
        extend_name: tableName,
        parent_id: props.parentIds.fromKey,
        uuid: props.parentIds.toKey,
      };
      getFormObj(props.parentIds.to, "extend", params, state, index, function(res) {
        // 当sign_more为false，且 data没有数据时，默认加载一个空表单
        if (item.base.sign_more || res.length) {
          return;
        }
        state.data[index] = getAttr(item);
      });
    };

    /* 添加模型扩展 */

    const add = (index) => {
      if (state.data.length == 0) {
        state.data = initData(props.modelAttrs);
      } else {
        let arr = initData(props.modelAttrs)[index];
        state.data[index].push(arr[0]);
      }
    };
    // 删除模型扩展
    /* 注销 */
    const deleteExtendtable = (item, index, i) => {
      if (item.uuid) {
        uni.showModal({
          title: "注销",
          content: "是否确定注销该项",
          confirmColor: "#4287ff",
          success: (res) => {
            if (res.cancel) return;
            // on confirm
            let extendTableName = props.modelAttrs[index].base.table_name;
            let params = Object.assign(
              {},
              {
                parent: props.parentIds.from,
                pid: props.parentIds.fromKey,
                uid: props.parentIds.toKey,
                sid: item.uuid,
              }
            );
            delExtendTable(props.parentIds.to, extendTableName, params)
              .then((res) => {
                console.log(res);
                uni.showToast({ title: "删除成功" });
              })
              .catche((err) => {
                uni.showToast({ title: err });
              });
          },
        });
      } else {
        state.data[index].splice(i, 1);
      }
    };
    const getData = () => {
      // 获取表单数据，填入一个数组返回给form页面提交
      let tempArr = {};
      for (let i = 0; i < itemRefs.length; i++) {
        const el = itemRefs[i];
        const table_name = props.modelAttrs[i].base.table_name;
        tempArr[table_name] = [];
        if (el.length) {
          for (let j = 0; j < el.length; j++) {
            const v = el[j];
            if (v) {
              v.formIn.submit();
              v.submit().then((res) => {
                if (Object.keys(res).length) {
                  tempArr[table_name].push(res);
                }
              });
            }
          }
        }
      }
      return new Promise((resolve) => {
        resolve(tempArr);
      });
    };
    return {
      activeNames,
      state,
      add,
      setItemRef,
      getData,
      deleteExtendtable,
    };
  },
};

function initData(modelAttrs) {
  /* 初始化把子表模型的对象提取出来 */
  let base = [];
  modelAttrs.map((item, index) => {
    base[index] = getAttr(item);
  });
  return base;
}
function getAttr(item) {
  let arr = [];
  item.attrs.map((v, i) => {
    let obj = {};
    v.fields.map((el) => {
      obj[el.name] = el.base.default_value;
    });
    arr[i] = obj;
  });
  return arr;
}
function initArr(i) {
  var arr = new Array(); //声明一维数组
  for (var x = 0; x < i; x++) {
    arr[x] = new Array(); //声明二维数组
    for (var y = 0; y < i; y++) {
      arr[x][y] = 0; //数组初始化为0
    }
  }
  return arr;
}
</script>

<style lang="scss" scoped>
.sub-form {
  .sub-form-item {
    width: 95%;
    margin: 5px auto !important;
    border-radius: 5px;
    box-shadow: 0px 2px 5px #ccc;
    .sub-form-step {
      padding-left: 0.5rem;
      .step-title {
        width: 97.5%;
        text-align: left;
        display: flex;
        justify-content: space-between;
        margin: 20px 0 12px 0;
        span {
          display: inline-block;
          padding: 5px 10px;
          color: $color-white;
          background: #606060;
          border-radius: 3px;
        }
        i {
          color: $color-red;
        }
      }
    }
    .sub-form-title {
      color: $color-green;
      text-align: left;
      // .sub-form-title-icon {
      //   transform: rotate(90deg);
      // }
    }
    .add-btn {
      width: 95%;
      height: 1rem;
      display: flex;
      align-items: center;
      border: 0.02rem #bebebe dashed;
      border-radius: 0.06rem;
      margin: 10px auto;

      .add-icon {
        font-size: 30px;
        margin-left: 26px;
        margin-right: 16px;
      }
      .add-text {
        color: $color-deep;
      }
    }
  }
}
</style>
<style lang="scss">
.sub-form {
  .van-collapse-item__content {
    padding-left: 0;
    padding-right: 0;
  }
  .sub-form-step {
    .van-step__circle-container {
      left: -0.28rem !important;
    }
    .van-step__circle {
      width: 0.16rem;
      height: 0.16rem;
      background: #606060;
    }
    .van-step__title {
      .van-form {
        width: 97.5%;
        margin-left: 0 !important;
      }
    }
    .van-step__line {
      background: transparent;
      border-left: 2px dashed rgba(0, 0, 0, 0.3);
      height: calc(100% + 16px);
    }
  }
  .van-hairline:last-child .van-step__line {
    border-left: none;
  }
}
</style>
