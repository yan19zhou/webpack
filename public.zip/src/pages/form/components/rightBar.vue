<template>
  <view class="mask" v-show="isShow"></view>
  <view class="right-bar">
    <!-- 定制表单页面右侧收缩栏 -->
    <view class="content" :style="{ right: isShow ? '0' : '-6.2rem' }">
      <view class="oper-btn" @click="hideBar" v-show="isShow">
        <span class="btn-text"> 收起 </span>
        <van-icon class="btn-text btn-icon" name="arrow" />
      </view>
      <view class="header">
        <view class="header-top">
          <span class="top-title">定位</span>
          <view class="top-btns">
            <view class="btns-add" v-show="!showLogoutIcon" @click="add">
              <i class="iconfont iconxinzengdizhi"></i>
              <span>新增</span>
            </view>
            <view
              class="btns-del"
              @click="showLogout(true)"
              v-show="!showLogoutIcon"
            >
              <i class="iconfont iconlajitong1"></i>
              <span>快速注销</span>
            </view>
            <view
              class="btns-del"
              @click="showLogout(false)"
              v-show="showLogoutIcon"
            >
              <span>取消注销</span>
            </view>
          </view>
        </view>
        <view class="header-bottom border_1px">
          <i class="iconfont icondingwei"></i>
          <span>{{ chainName }}</span>
        </view>
      </view>
      <view class="tree">
        <RightTree
          v-if="state.list"
          :data="state.list"
          :peripheral="peripheral"
          :showLogoutIcon="showLogoutIcon"
          @clickNode="clickNode"
          @refreshData="refreshData"
        />
      </view>
    </view>
  </view>
</template>

<script>
import { reactive, ref } from "vue";
import RightTree from "./buildingRightTree";
import { getBuildingTree } from "@/api/form/form";
export default {
  components: {
    RightTree,
  },
  props: {
    buildingId: String,
    name: String,
    isShow: Boolean,
  },
  setup(props, { emit }) {
    let state = reactive({});
    let peripheral = reactive({});
	var chainName = ref(props.name);
    // 请求树形数据
    const loadData = () => {
      getBuildingTree(props.buildingId).then((res) => {
        peripheral = res.peripheral;
        peripheral.pid = props.buildingId;
        state.list = [
          { name: props.name, uuid: props.buildingId, children: res.units },
        ];
      });
    };
    loadData();
    const hideBar = () => {
      emit("hideBar");
    };
    let showLogoutIcon = ref(false);
    const showLogout = (type) => {
      showLogoutIcon.value = type;
    };
    const clickNode = (item) => {
      // 选中之后请求对应表单模型
		chainName.value = item.address;
      emit("refreshModel", item);
    };

    const refreshData = () => {
      // 注销操作之后刷新树
      loadData();
    };
    const add = () => {
      //新增
      emit("add")
    };

    return { hideBar, state, showLogout,peripheral,add, showLogoutIcon, clickNode ,refreshData,chainName};
  },
};
</script>

<style lang="scss" scoped>
.mask {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.34);
  z-index: 99;
}
.right-bar {
  height: 100vh;
  position: fixed;
  right: 0;
  top: 0;
  z-index: 999;
  .content {
    width: 6.2rem;
    height: 100%;
    background: #f6f7fb;
    position: absolute;
    right: 0;
    top: 0;
    transition: right 0.5s ease-in-out;
    .header {
      background: $bg-page-dark-blue;
      color: $color-white;
      .header-top {
        height: 60px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        .top-title {
          font-size: 18px;
          font-weight: bold;
          line-height: 18px;
          margin-left: 12px;
        }
        .top-btns {
          display: flex;
          margin-right: 8px;
          .btns-add,
          .btns-del {
            padding: 6px 12px;
            border: 1px solid #ffffff5b;
            border-radius: 24px;
            i {
              margin-right: 5px;
            }
          }
          .btns-add {
            margin-right: 8px;
          }
        }
      }
      .header-bottom {
        height: 40px;
        color: $color-white;
        text-align: left;
        line-height: 40px;
        i {
          color: #accaff;
          margin-right: 12px;
          margin-left: 18px;
        }
      }
    }
  }
  .oper-btn {
    width: 0;
    height: 80px;
    border-right: 26px solid #fff;
    border-top: 18px solid transparent;
    border-bottom: 18px solid transparent;
    position: absolute;
    left: -25px;
    top: 50%;
    transform: translateY(-50%);
    font-size: 14px;
    display: flex;
    justify-content: space-evenly;
    flex-direction: column;
    .btn-text {
      transform: translateX(5px);
    }
    .btn-icon {
      color: $color-blue;
    }
  }
}
</style>