<template>
  <view>
    <!-- 
  表单页面
 -->
    <!-- 基础表组件 -->
    <view class="form-container" id="form-container">
      <!-- <span>{{ name }}</span> -->
      <Form v-if="state.attrs" ref="baseForm" :parentIds="Ids" :modelAttrs="state.attrs" :formData="state.data" @submit="baseSubmit" />
      <!-- 子表组件(新增) -->
      <subForm v-if="state.extend_tables.length" :parentIds="Ids" :modelAttrs="state.extend_tables" ref="subForm" />
      <!-- 关联组件之前表单的sub -->
      <Relation v-if="state.relations.length && Ids.toKey" :parentIds="Ids" :modelRelations="state.relations" />
    </view>

    <!-- 底部按钮  走访--提交  -->
    <view class="submitButtoms">
      <view :class="['btn-visit cursor', uuid ? '' : 'toGray']" @click="visit">
        <view class="btn-visit-title f16">走访</view>
        <view class="btn-visit-text">
          <span>上次走访时间</span>
          <span>{{ state.visitTime || "从未走访" }}</span>
        </view>
      </view>
      <view class="btn-submit f16 cursor" @click="submit">提交</view>
    </view>
    <!--  -->
    <ErrorPopup :isshow="errors.showError" :errorList="errors.errorList" @close="errors.showError = false" />
  </view>
</template>

<script>
import Form from "./baseForm.vue";
import subForm from "./subForm.vue";
import Relation from "./relations.vue";
import ErrorPopup from "./formError.vue";

import { pwdEncrypt, debounce } from "utils/utils.js";
import { getModel, getFormObj, getVisitInfo, saveVisitInfo } from "../js/getModel";
import { saveForm } from "@/api/form/form";

export default {
  props: { Ids: Object, modelName: String },
  components: {
    Form,
    subForm,
    Relation,
    ErrorPopup,
  },
  data() {
    return {
      baseForm: null,
      subForm: null,
      errors: {},
      uuid: this.Ids.toKey,
      state: {
        attrs: [],
        relations: [],
        extend_tables: [],
        visitTime: "",
        data: null,
      },
    };
  },
  methods: {
    async baseSubmit(v) {
      console.log(v);
      if (v.type == "error") {
        this.errors.errorList = v.info;
        this.errors.showError = true;
        return;
      }

      let FormData = {
        _default: this.baseForm.value.submitOjb,
      };
      if (this.subForm) {
        let subFormData = await this.subForm.getData();
        FormData = Object.assign(FormData, subFormData);
      }
      console.log(FormData);
      let params = {
        belongedGrid: sessionStorage.getItem("$gridCode"), // 所属网格
        encryptFormData: pwdEncrypt(JSON.stringify(FormData)),
        id: this.Ids.toKey,
        parent: this.Ids.from,
        parentId: this.Ids.fromKey,
        taskList: [],
      };
      console.log(params);
      saveForm(this.Ids.to, params).then((res) => {
        if (!this.Ids.toKey) {
          this.$emit("vrChange", { toKey: res.uuid });
        }
        uni.showModal({
          title: "完成",
          content: "保存成功",
          showCancel: false,
          confirmColor: "#4287ff",
          success: (res) => {
            uni.navigateBack();
          },
        });
      });
    },
    submit: debounce(() => {
      this.baseForm.formIn.submit();
    }),
    visit() {
      // 走访
      console.log("visit");
      let params = {
        uuid: this.Ids.toKey,
        pid: this.Ids.fromKey,
        parent: this.Ids.from,
        visiting_coordinates: sessionStorage.getItem("_UserPeriodLocation") || "113.89415777136486,22.576602314168014",
      };
      saveVisitInfo(this.Ids.to, params, this.state);
    },
    vrChange(type) {
      this.$emit("vrChange", { type: type });
    },
  },
  watch: {
    modelName: {
      handler(newValue) {
        this.state.attrs = [];
        this.state.relations = [];
        this.state.extend_tables = [];
        getModel(this.state, newValue, this.vrChange);
      },
      immediate: true,
    },
    "Ids.toKey": {
      handler(newValue) {
        this.state.data = null;
        console.log(this.Ids);
        if (newValue) {
          let params = {
            extend_name: "",
            parent_id: this.Ids.fromKey,
            uuid: newValue,
          };
          // 获取表单反显信息
          getModel(this.state, this.modelName, this.vrChange).then((res) => {
            if (res) {
              getFormObj(this.Ids.to, "primary", params, this.state);
              // 获取走访信息
              let visitParams = {
                uuid: newValue,
                pid: this.Ids.fromKey,
                parent: this.Ids.from,
              };
              getVisitInfo(this.Ids.to, visitParams, this.state);
            }
          });
        }
      },
    },
    immediate: true,
  },
};
</script>

<style lang="scss" scoped>
.form-container {
  padding-bottom: 50px;
  box-sizing: border-box;
  height: 100%;
  overflow-y: auto;
}
.submitButtoms {
  width: 100%;
  height: 50px;
  border-radius: 0;
  color: $color-white;
  background: $uni-bg-color;
  position: fixed;
  bottom: 0px;
  z-index: 2;
  display: flex;
  text-align: center;
  @include font_size(28rpx);
  & > view {
    width: 50%;
  }
  .btn-visit {
    border: 1px solid #cecece;
    display: flex;
    flex-direction: column;
    justify-content: center;
    .btn-visit-title {
      color: $uni-text-color;
      @include font_size(32rpx);
    }
    .btn-visit-text {
      & > span:first-child {
        color: $uni-text-color-grey;
        margin-right: 5px;
      }
      & > span:last-child {
        color: $color-blue;
      }
    }
  }
  .btn-submit {
    line-height: 50px;
    @include bg_color();
    @include font_size(32rpx);
  }
}
.toGray {
  pointer-events: none;
  filter: opacity(0.4);
}
</style>
