<template>
  <view class="right-tree">
    <van-collapse v-model="activeNames[0]">
      <van-collapse-item
        :title="building.name"
        :name="building.uuid"
        v-for="building in data"
        :key="building.uuid"
        :is-link="isfalse"
        class="cell-active building"
      >
        <template #value>
          <span
            class="title-right"
            @click.stop="choose(peripheral, peripheral.pid, 'MODEL_BUILDING_PERIPHERAL_FACILITIES', '外围设施')"
            >采查外围</span
          >
          <span
            class="title-right"
            @click.stop="choose(building, '', 'MODEL_BUILDING', '')"
            >采查楼栋</span
          >
        </template>
        <van-collapse v-model="activeNames[1]">
          <van-collapse-item
            :name="unit.uuid"
            v-for="unit in building.children"
            :key="unit.uuid"
            title-class="ml16"
            :class="[
              'bottom_1px',
              activeNames[1].includes(unit.uuid) ? 'cell-active' : 'no-active',
            ]"
          >
            <template #title>
              <span class="title-left">{{ unit.name || "无" }}单元</span>
              <i
                class="iconfont iconshanchu1 ml10"
                @click.stop="
					del(unit, {
						modelName: 'MODEL_UNIT',
						pid: building.uuid,
						parent: 'MODEL_BUILDING',
					})
                "
                v-show="showIcon"
              ></i>
            </template>
            <template #value>
              <span
                class="title-right"
                @click.stop="
                  choose(
                    unit,
                    building.uuid,
                    'MODEL_UNIT',
                    unit.name || '无' + '单元'
                  )
                "
                >采查单元</span
              >
            </template>
            <van-collapse v-model="activeNames[2]">
              <van-collapse-item
                :name="floor.uuid"
                v-for="floor in unit.children"
                :key="floor.uuid"
                title-class="pl34"
                :class="[
                  'bottom_1px',
                  'floor',
                  activeNames[2].includes(floor.uuid)
                    ? 'cell-active'
                    : 'no-active',
                ]"
              >
                <template #title>
                  <span class="title-left">{{ floor.name }}层</span>
                  <i
                    class="iconfont iconshanchu1 ml10"
                    @click.stop="
                      del(floor, {
                        modelName: 'MODEL_FLOOR',
                        pid: unit.uuid,
                        parent: 'MODEL_UNIT',
                      })
                    "
                    v-show="showIcon"
                  ></i>
                </template>
                <template #value>
                  <span
                    class="title-right"
                    @click.stop="
                      choose(
                        floor,
                        unit.uuid,
                        'MODEL_FLOOR',
                        (unit.name || '无') + '单元 - ' + floor.name + '楼'
                      )
                    "
                    >采查楼层</span
                  >
                </template>
                <view class="house-wrap">
                  <view
                    v-for="house in floor.children"
                    :key="house.uuid"
                    :class="[
                      'house',
                      currentHouse == house.uuid ? 'active-house' : '',
                    ]"
                    @click.stop="
                      choose(
                        house,
                        floor.uuid,
                        'MODEL_HOUSE',
                         (unit.name || '无') + '单元 - ' + floor.name + '楼 - ' + house.name
                      )
                    "
                  >
                    <span>{{ house.name }}</span>
                    <i
                      class="iconfont iconshanchu1"
                      @click.stop="
                        del(house, {
                          modelName: 'MODEL_HOUSE',
                          pid: floor.uuid,
                          parent: 'MODEL_FLOOR',
                        })
                      "
                      v-show="showIcon"
                    ></i>
                  </view>
                </view>
              </van-collapse-item>
            </van-collapse>
          </van-collapse-item>
        </van-collapse>
      </van-collapse-item>
    </van-collapse>
  </view>
  <logout-model
    :confirmShow="confirmShow"
    @delCancel="cancel"
    @delClose="close"
  ></logout-model>
</template>

<script>
import { reactive, ref, onMounted, computed } from "vue";
import { Toast } from "vant";
import LogoutModel from "./logout-model";
import { DelMoel } from "@/api/form/form.js";
export default {
  name: "rightTree",
  components: {
    LogoutModel,
  },
  props: {
    data: Array,
    showLogoutIcon: Boolean,
	peripheral:Object
  },

  setup(props, { emit }) {
    const isfalse = ref(false);
    let activeNames = reactive([["0"], [], []]);
    const showIcon = computed(() => {
      return props.showLogoutIcon;
    });

    const cover = (activeNames, data, index) => {
      if (data.length) {
        activeNames[index] = [data[0].uuid];
        index++;
        if (data[0].children && data[0].children.length) {
          cover(activeNames, data[0].children, index);
        }
      }
    };
    onMounted(() => {
      let index = 0;
      cover(activeNames, props.data, index);
    });

    /* 
选择房屋
*/
    let currentHouse = ref("");

    const choose = (item, pid, model, address) => {
      if (model == "MODEL_HOUSE") {
        currentHouse.value = item.uuid;
      }
      item.model = model;
      item.address = address;
      item.pid = pid;
      switch (model) {
        case "MODEL_BUILDING":
          item.parent = "";
          break;
        case "MODEL_UNIT":
          item.parent = "MODEL_BUILDING";
          break;
        case "MODEL_FLOOR":
          item.parent = "MODEL_UNIT";
          break;
        case "MODEL_HOUSE":
          item.parent = "MODEL_FLOOR";
          break;
		case "MODEL_BUILDING_PERIPHERAL_FACILITIES":
			item.parent = "MODEL_BUILDING";
			break;
        default:
          break;
      }
      emit("clickNode", item);
    };

    /* 注销 */
    let confirmShow = ref(false);
    let currentItem = reactive({});
    const del = (item, pModel) => {
      confirmShow.value = true;
      currentItem = Object.assign(item, pModel);
    };

    const cancel = () => {
      console.log("cancel");
      confirmShow.value = false;
    };

    const close = (delReason) => {
      // 删除成功之后关闭注销弹窗,并刷新数据
      console.log("close");
      confirmShow.value = false;
      let params = Object.assign({}, { reason: delReason.value }, currentItem);
      DelMoel(params.modelName, params).then((res) => {
        console.log(res);
        Toast.success("删除成功");
      });
      emit("refreshData");
    };
    return {
      isfalse,
      activeNames,
      showIcon,
      del,
      choose,
      currentHouse,
      confirmShow,
      cancel,
      close,
    };
  },
};
</script>

<style lang="scss" scoped>
.right-tree {
  .title-right {
    font-size: 13px;
    color: $color-orange1;
    &:last-child {
      margin-left: 8px;
    }
  }
  .building {
    max-height: calc(100vh - 100px);
    overflow-y: auto;
  }
  .unit-title {
    padding-left: 20px;
  }
  .bottom_1px {
    border-bottom: solid 1px #fffffc;
  }
  .house-wrap {
    padding: 12px 0 0 16px;
    display: flex;
    flex-wrap: wrap;
    .house {
      height: 25px;
      line-height: 26px;
      position: relative;
      background: #ffffff;
      border: 0px solid #fffffc;
      border-radius: 2px;
      margin-right: 10px;
      margin-bottom: 12px;
      padding: 0 10px;
      color: $uni-text-color;
      span {
        display: inline-block;
        width: 100%;
        overflow: hidden;
      }
      .iconshanchu1 {
        position: absolute;
        top: -50%;
        right: -8px;
      }
    }
    .active-house {
      background: $color-orange1;
      color: #fff;
    }
  }
  .iconshanchu1 {
    color: #f11f1f;
  }
}
</style>

<style lang="scss">
.right-tree {
  .cell-active {
    .van-cell {
      background: rgba(243, 119, 37, 0.08);
    }
  }
  .no-active {
    .van-cell {
      background: transparent;
    }
  }
  .van-cell__title {
    text-align: left;
  }
  .van-collapse-item__content {
    padding: 0;
  }
  .van-icon-arrow {
    position: absolute;
    left: 8px;
    font-size: 12px;
  }
  .floor {
    .van-icon-arrow {
      left: 24px;
    }
    .pl34 {
      padding-left: 34px;
    }
    .van-collapse-item__content {
      background: #f6f7fb;
    }
  }
  .van-collapse-item--border::after {
    border-top: none;
  }
}
</style>