<template>
  <!-- 关联组件() -->
  <view>
    <van-collapse v-model="activeNames" class="relation" v-for="(relation, index) in modelRelations" :key="relation.relationType">
      <van-collapse-item :name="index" class="relation-item" :is-link="false">
        <template #title>
          <view class="relation-title">
            <van-icon
              name="play"
              class="relation-title-icon"
              :style="{
                transform: activeNames.includes(index) ? 'rotate(90deg)' : 'rotate(0deg)',
              }"
            />
            {{ relation.relationTypeName }}
          </view>
        </template>
        <view v-for="item in relation.relations" :key="item._key" @click="toModel(item)" class="relation-item-content" :id="item.children" v-show="isShow(item)">
          <span>
            {{ item.name }}
          </span>
          <view>
            <c-rightIcon :strategy="item.business_label" />
            <van-icon name="arrow" class="right-icon" />
          </view>
        </view>
      </van-collapse-item>
    </van-collapse>
  </view>
</template>

<script>
import { ref } from "vue";
export default {
  props: {
    parentIds: Object,
    modelRelations: Object,
  },
  inject: ["pathStart", "checked"],
  setup() {
    const activeNames = ref([]);
    return { activeNames };
  },
  computed: {
    isShow() {
      let show = true;
      return (item) => {
        if (this.checked.checked.length) {
          show = item.business_label.some((v) => {
            return this.checked.checked.includes(v);
          });
        } else {
          show = true;
        }
        return show;
      };
    },
  },
  methods: {
    toModel(item) {
      // relations显示规则调试
      this.$router.push({
        path: "/nextForm",
        query: {
          to: item.children,
          from: item.parent,
          name: item.name,
          fromKey: this.parentIds.toKey,
        },
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.relation {
  .relation-item {
    .relation-title {
      color: $color-blue;
      text-align: left;
      .relation-title-icon {
        transform: rotate(90deg);
      }
    }
    .relation-item-content {
      width: 95%;
      height: 44px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: relative;
      margin: 5px auto !important;
      padding: 8px 35px 8px 25px;
      border-radius: 5px;
      box-sizing: border-box;
      box-shadow: 0px 2px 5px #ccc;
      .right-icon {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        right: 0.2rem;
        font-size: 0.32rem;
      }
    }
  }
}
.relation:last-child {
  margin-bottom: 2.5rem;
}
</style>
<style lang="scss">
.relation {
  .van-collapse-item__content {
    padding-left: 0;
    padding-right: 0;
  }
}
</style>
