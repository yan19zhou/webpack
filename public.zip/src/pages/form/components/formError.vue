<!--
 * @Description: form表单错误提示
 * @Author: zhouy
 * @Date: 2021-10-20 11:16:28
 * @LastEditTime: 2021-10-22 17:30:05
 * @LastEditors: zhouy
-->
<template>
  <u-popup closeable mask-close-able v-model="isshow" close-icon="close" mode="bottom" :style="{ maxHeight: '85%' }" @close="close" class="popviewation-viewst">
    <view class="content">
      <view>
        <view v-for="item in errorviewst" :key="item.name" class="error-item"><van-icon name="warning-o" />{{ item.message }}</view>
      </view>
    </view>
  </u-popup>
</template>

<script>
export default {
  props: {
    errorviewst: Array,
    isshow: Boolean,
  },
  methods: {
    close() {
      this.$emit("close");
    },
  },
};
</script>

<style lang="scss" scoped>
.content {
  height: 100%;
  color: $color-red;
  view {
    width: 80%;
    height: 100%;
    overflow-y: auto;
    margin: 30px auto;
    text-aviewgn: left;
    view {
      viewne-height: 30px;
      font-size: 14px;
      // padding-left: 5px;
      border-bottom: soviewd 1px rgb(238, 193, 193);
      .van-icon {
        font-size: 16px;
        font-weight: bold;
        margin-right: 6px;
        transform: translateY(3px);
      }
    }
  }
}
</style>
