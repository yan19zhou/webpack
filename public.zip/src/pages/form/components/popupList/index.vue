<template>
  <!-- 通用表单 模型选择列表 -->
  <u-popup closeable v-model="show" close-icon="close" mode="bottom" :height="'85%'" @close="close" class="population-list">
    <view class="content" v-if="state.tableHeads">
      <view class="header">
        <view class="title">
          <text class="f16 text-dark mr16">{{ modelName || "人口" }}</text
          ><text class="f12 text-pl">共计{{ state.list.total || 0 }}条数据</text>
        </view>
        <input class="search-input" v-model="param.word" @input="search" :placeholder="getKeyName(state.tableHeads.keyList)" />
        <view v-if="!flag" class="search-bar">
          <!-- <SearchPath @getAddressUuid="getAddressUuid" /> -->
        </view>
      </view>
      <view class="table-wrap">
        <view class="data-table data-table-left">
          <table>
            <thead style="background: rgba(250, 250, 250, 1)">
              <tr>
                <th class="numeric-cell" v-for="head in state.tableHeads.keyList" :key="head.attr">
                  {{ head.name }}
                </th>
              </tr>
            </thead>
            <tbody ref="leftBody" @scroll="scrollLeft">
              <!-- <van-list :loading="state.loading" :finished="state.finished" finished-text="没有更多了" @load="onLoad">
                <tr @click="searchPosition(item)" class="no-right fab-close" v-for="item in state.list.records" :key="item">
                  <td class="numeric-cell" v-for="head in state.tableHeads.keyList" :key="head.attr">
                    {{ item[head.attr] }}
                  </td>
                </tr>
              </van-list> -->
            </tbody>
          </table>
        </view>
        <view class="data-table data-table-right">
          <table>
            <thead style="background: rgba(250, 250, 250, 1)">
              <tr>
                <th class="">操作</th>
              </tr>
            </thead>
            <tbody ref="rightBody" @scroll="scrollRight">
              <tr @click="deleteObj(item)" v-for="item in state.list.records" :key="item">
                <td class="label-cell">
                  <i class="iconfont iconlajitong1 color-red"></i>
                </td>
              </tr>
            </tbody>
          </table>
        </view>
      </view>
      <view class="population-add">
        <u-button type="primary" @click="addModel"><u-icon name="plus"></u-icon>新增</u-button>
      </view>
    </view>
    <view class="content" v-else>
      <u-empty class="pc" text="暂无数据" mode="list" />
    </view>
    <u-modal v-model="confirmShow" title="注销" className="model-logout" show-cancel-button @confirm="confirm">
      <p>请输入注销原因</p>
      <textarea type="text" class="logout-input" v-model="delReason" />
    </u-modal>
  </u-popup>
</template>

<script>
// import SearchPath from "../searchPath/index";
import { DelMoel } from "@/api/form/form.js";
import { initModelList, getModelData } from "./data.js";
import { debounce } from "@/utils/utils.js";

export default {
  components: {
    // SearchPath,
  },
  props: {
    isshow: Boolean,
    Ids: Object,
    modelName: String,
  },
  provide() {
    return {
      getpathList: () => this.state.tableHeads.pathList,
    };
  },
  data() {
    return {
      delReason: "",
      confirmShow: false,
      currentItem: null,
      state: {
        finished: false,
        tableHeads: {},
        list: { page: {} },
      },
      show: false,
      param: {
        page: {
          current: 1,
          size: 10,
        },
        word: "",
        pathList: [],
        pathMap: {},
      },
    };
  },
  computed: {
    flag() {
      return this.Ids.pathStart == this.Ids.to;
    },
  },
  methods: {
    _initModelList() {
      /* 初始化模型数据 */
      let modelParams = {
        flag: this.flag ? 0 : 1,
        start: this.Ids.pathStart || "MODEL_BUILDING",
      };

      initModelList(this.Ids.to, modelParams, state)
        .then((res) => {
          // 获取pathList
          if (res && res.length) {
            param.pathList = res[0].map((item) => {
              return item.key;
            });
          }
          if (flag) {
            param.pathList = [].concat(this.Ids.to);
          }
          this.onLoad();
        })
        .catch((err) => {
          console.log(err);
        });
    },
    onLoad() {
      getModelData(this.Ids.to, this.param, this.state);
    },
    close() {
      /*
      列表关闭
    */
      this.$emit("close");
      this.show = false;
    },
    getKeyName(list) {
      if (!list || !list.length) {
        return "请输入关键字";
      }
      var s = [];
      for (let l in list) {
        s.push(list[l].name);
      }
      return "输入" + s.join(",") + "等数据项关键字";
    },
    getAddressUuid(arr) {
      // 通过地址过滤
      let lastOne = arr[arr.length - 1];
      let key = lastOne.model;
      this.param.page.current = 1;
      this.param.pathMap = {};
      this.param.pathMap[key] = lastOne.key;
      this.onLoad();
    },
    search: debounce((e) => {
      // 关键字搜索
      this.param.page.current = 1;
      this.param.word = e.target.value;
      this.onLoad();
    }),

    addModel() {
      /*
    从模型列表页面新增表单
    */
      if (!this.flag && Object.keys(this.param.pathMap) < 1) {
        uni.showToast({ title: "请选择采集路径" });
        return;
      }
      uni.$emit("addForm", this.param.pathMap);
      this.close();
    },
    searchPosition(item) {
      this.$emit("changeValue", item);
    },
    deleteObj(e) {
      // 删除模型
      this.currentItem = e;
      this.confirmShow = true;
    },
    confirm() {
      let params = {
        uuid: this.currentItem.uuid,
        parent: this.currentItem.$parent_model,
        pid: this.currentItem.$parent_id,
        reason: this.delReason,
      };
      DelMoel(this.Ids.to, params).then(() => {
        uni.showToast({ title: "删除成功" });
        this.onLoad();
      });
    },
    scrollRight(e) {
      this.$refs.leftBody.scrollTop = e.target.scrollTop;
    },
    scrollLeft(e) {
      this.$refs.rightBody.scrollTop = e.target.scrollTop;
    },
  },
  watch: {
    isshow(newValue) {
      this.show = newValue;
    },
  },
};
</script>

<style lang="scss" scoped>
.content {
  height: 100%;
  .header {
    padding-top: 16px;
    padding-left: 25px;
    text-align: left;
    .search-input {
      width: 325px;
      height: 37px;
      background: #ffffff;
      border: 1px solid #b4b4b4;
      border-radius: 5px;
      padding-left: 10px;
      margin-top: 20px;
    }
    .search-bar {
      width: 345px;
      margin-bottom: -0.3rem;
    }
    .text-dark {
      @include font_size(32rpx);
    }
    .text-pl {
      @include font_size(24rpx);
    }
  }
  .table-wrap {
    height: calc(100% - 220px);
    margin-top: 0.3rem;
    margin-bottom: 0.5rem;
    margin-left: 0.5rem;
    margin-right: 0.2rem;
    overflow-y: hidden;
    .data-table-right tbody td:before,
    .data-table-right tbody th:before {
      border: none;
      height: 0px;
    }
    .data-table {
      overflow-x: auto;
    }
    .data-table,
    table {
      height: 100%;
      td,
      th {
        text-indent: 16px;
        @include font_size(24rpx);
      }
    }
    .data-table-left {
      float: left;
      width: calc(100% - 54px);
      thead {
        background: rgba(218, 218, 218, 0.2) !important;
      }
    }
    .data-table-right {
      width: 54px;
      overflow-x: hidden;
      box-shadow: -5px 0 5px -5px rgba(0, 0, 0, 0.3);
      thead {
        background: transparent !important;
      }
      td,
      th {
        width: 50px;
        line-height: 28px;
      }
    }
    .data-table table,
    table.data-table {
      width: 100%;
      border: none;
      padding: 0;
      margin: 0;
      border-collapse: collapse;
      text-align: left;
    }
    thead,
    tbody {
      display: block;
      overflow-y: scroll;
    }
    tbody {
      max-height: calc(100% - 30px);
    }
    .no-right.fab-close {
      float: none !important;
    }

    .iconlajitong1 {
      font-size: 20px;
      font-weight: 600;
      color: $color-red;
    }

    .numeric-cell {
      min-width: 100px;
      line-height: 28px;
      text-align: left;
      white-space: nowrap;
    }
    thead tr {
      display: table;
      width: 100%;
    }
  }
  .population-add {
    position: absolute;
    bottom: 10px;
    left: 50%;
    transform: translateX(-50%);
    width: 90%;
    height: 47px;
    background: #4287ff;
  }
}
.logout-input {
  height: 1.5rem;
  width: 80%;
  border-radius: 10px;
  margin-top: 10px;
  border-radius: 5px;
  border: solid 1px #ccc;
}
</style>
<style lang="scss">
.model-logout {
  .van-dialog__header {
    padding-top: 0.2rem;
    font-weight: bold;
  }
}
</style>
