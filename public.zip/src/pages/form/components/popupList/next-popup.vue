<template>
  <!-- 通用表单 模型选择列表 -->
  <van-popup
    closeable
    :show="isshow"
    close-icon="close"
    position="bottom"
    :style="{ height: '85%' }"
    @click-overlay="close"
    @click-close-icon="close"
    class="population-list"
  >
    <view class="content" v-if="state.tableHeads">
      <view class="header">
        <view class="title">
          <span class="f16 text-dark mr16">{{ state.modelName || "人口" }}</span
          ><span class="f12 text-pl"
            >共计{{ state.list.total || 0 }}条数据</span
          >
        </view>
        <input
          class="search-input"
          v-model="state.word"
          @input="search"
          :placeholder="getKeyName(state.tableHeads.keyList)"
        />
      </view>
      <view class="table-wrap">
        <view class="data-table data-table-left">
          <table>
            <thead style="background: rgba(250, 250, 250, 1)">
              <tr>
                <th
                  class="numeric-cell"
                  v-for="head in state.tableHeads.keyList"
                  :key="head.attr"
                >
                  {{ head.name }}
                </th>
              </tr>
            </thead>
            <tbody ref="leftBody" @scroll="scrollLeft">
              <van-list
                :loading="state.loading"
                :finished="state.finished"
                finished-text="没有更多了"
                @load="onLoad"
              >
                <tr
                  @click="searchPosition(item)"
                  class="no-right fab-close"
                  v-for="item in state.list.records"
                  :key="item"
                >
                  <td
                    class="numeric-cell"
                    v-for="head in state.tableHeads.keyList"
                    :key="head.attr"
                  >
                    {{ item[head.attr] }}
                  </td>
                </tr>
              </van-list>
            </tbody>
          </table>
        </view>
        <view class="data-table data-table-right">
          <table>
            <thead style="background: rgba(250, 250, 250, 1)">
              <tr>
                <th class="">操作</th>
              </tr>
            </thead>
            <tbody ref="rightBody" @scroll="scrollRight">
              <tr
                @click="deleteObj(item)"
                v-for="item in state.list.records"
                :key="item"
              >
                <td class="label-cell">
                  <i class="iconfont iconlajitong1 color-red"></i>
                </td>
              </tr>
            </tbody>
          </table>
        </view>
      </view>
      <view class="population-add">
        <van-button icon="plus" type="primary" @click="addModel"
          >新增</van-button
        >
      </view>
    </view>
    <view class="content" v-else>
      <van-empty class="pc" description="暂无数据" />
    </view>
    <van-dialog
      :show="confirmShow"
      title="注销"
      className="model-logout"
      show-cancel-button
      @confirm="confirm"
    >
      <p>请输入注销原因</p>
      <textarea type="text" class="logout-input" v-model="delReason" />
    </van-dialog>
  </van-popup>
</template>

<script>
import { reactive, getCurrentInstance,watch } from "vue";
import {  Toast } from "vant";
import { DelMoel } from "@/api/form/form.js";
import { initModelList, getListFromParent } from "./data.js";
import { debounce } from "@/utils/utils.js";

export default {
  props: {
    isshow: Boolean,
    Ids: Object,
    modelName: String,
  },
  data() {
    return {
      delReason: "",
      confirmShow: false,
      currentItem: null,
    };
  },
  setup(props, { emit }) {
    const { proxy } = getCurrentInstance();
    let state = reactive({
      finished: false,
      modelName: props.modelName,
      tableHeads: {},
      list: { page: {} },
      word: "",
    });
    /* 
      列表关闭
    */
    const close = () => {
      emit("close");
    };
	const onLoad = () => {
		getListFromParent(props.Ids.to,props.Ids.from,props.Ids.fromKey,param, state);
	};
	
    /* 初始化模型数据 */
    let modelParams = {
      flag: 0,
      start: "",
    };
	let param = {
		page: {
			current: 1,
			size: 10,
		},
		word: state.word,
		pathList: [],
		pathMap: {},
	};
    // initModelList(props.Ids.to, modelParams,state).then(() => {
		// onLoad();
    // }).catch(err=>{
		// console.log(err);
    // });
	
	watch(()=>props.Ids.to,(newValue)=>{
		modelParams = {
			flag: 0,
			start: "",
		};
		param = {
			page: {
				current: 1,
				size: 10,
			},
			word: state.word,
			pathList: [],
			pathMap: {},
		};
		state.modelName = props.Ids.name;
		initModelList(newValue, modelParams,state).then(() => {
			onLoad();
		}).catch(err=>{
			console.log(err);
		});
	},
	{ immediate: true, deep: true }
	);

    const getAddressUuid = (arr) => {
      // 通过地址过滤
      let lastOne = arr[arr.length - 1];
      let key = lastOne.model;
		param.page.current = 1;
		param.pathMap = {};
		param.pathMap[key] = lastOne.key;
      onLoad();
    };



    const search = debounce((e) => {
      // 关键字搜索
      param.page.current = 1;
      param.word = e.target.value;
      onLoad();
    });

    /* 
    从模型列表页面新增表单
    */
    const addModel = () => {
      //
      proxy.$bus.emit("addForm");
      close();
    };
	const getKeyName = (list)=>{
		if(!list || !list.length){
			return '请输入关键字';
		}
		var s = [];
		for(let l in list){
			s.push(list[l].name);
		}
		return '输入' + s.join(',') + '等数据项关键字';
	};
	const searchPosition =(item)=>{
		emit('changeValue',item);
	};
	
    return { state, close, onLoad, getAddressUuid, addModel, search,getKeyName,searchPosition};
  },
  methods: {
    deleteObj(e) {
      // 删除模型
      this.currentItem = e;
      this.confirmShow = true;
    },
    confirm() {
      let params = {
        uuid: this.currentItem.uuid,
        parent: this.currentItem.$parent_model,
        pid: this.currentItem.$parent_id,
        reason: this.delReason,
      };
      DelMoel(this.Ids.to,params).then(() => {
          Toast.success('删除成功');
        this.onLoad();
      });
    },
    scrollRight(e) {
      this.$refs.leftBody.scrollTop = e.target.scrollTop;
    },
    scrollLeft(e) {
      this.$refs.rightBody.scrollTop = e.target.scrollTop;
    },
  },
};
</script>

<style lang="scss" scoped>
.content {
  height: 100%;
  .header {
    padding-top: 16px;
    padding-left: 25px;
    text-align: left;
    .search-input {
      width: 325px;
      height: 37px;
      background: #ffffff;
      border: 1px solid #b4b4b4;
      border-radius: 5px;
      padding-left: 10px;
      margin-top: 20px;
    }
    .search-bar {
      width: 345px;
		margin-bottom: -0.3rem;
    }
  }
  .table-wrap {
    height: calc(100% - 220px);
	margin-top: 0.3rem;
    margin-bottom: 0.5rem;
    margin-left: 0.5rem;
    margin-right: 0.2rem;
    overflow-y: hidden;
    .data-table-right tbody td:before,
    .data-table-right tbody th:before {
      border: none;
      height: 0px;
    }
    .data-table {
      overflow-x: auto;
    }
    .data-table,
    table {
      height: 100%;
      td,
      th {
        text-indent: 16px;
      }
    }
    .data-table-left {
      float: left;
      width: calc(100% - 54px);
      thead {
        background: rgba(218, 218, 218, 0.2) !important;
      }
    }
    .data-table-right {
      width: 54px;
      overflow-x: hidden;
      box-shadow: -5px 0 5px -5px rgba(0, 0, 0, 0.3);
      thead {
        background: transparent !important;
      }
      td,
      th {
        width: 50px;
        line-height: 28px;
      }
    }
    .data-table table,
    table.data-table {
      width: 100%;
      border: none;
      padding: 0;
      margin: 0;
      border-collapse: collapse;
      text-align: left;
    }
    thead,
    tbody {
      display: block;
      overflow-y: scroll;
    }
    tbody {
      max-height: calc(100% - 30px);
    }
    .no-right.fab-close {
      float: none !important;
    }

    .iconlajitong1 {
      font-size: 20px;
      font-weight: 600;
      color: $color-red;
    }

    .numeric-cell {
      min-width: 100px;
      line-height: 28px;
      text-align: left;
      white-space: nowrap;
    }
    thead tr {
      display: table;
      width: 100%;
    }
  }
  .population-add {
    position: absolute;
    bottom: 10px;
    left: 50%;
    transform: translateX(-50%);
    .van-button {
      width: 323px;
      height: 47px;
      background: #4287ff;
    }
  }
}
.logout-input {
  height: 1.5rem;
  width: 80%;
  border-radius: 10px;
  margin-top: 10px;
  border-radius: 5px;
  border: solid 1px #ccc;
}
</style>
<style lang="scss">
.model-logout {
  .van-dialog__header {
    padding-top: 0.2rem;
    font-weight: bold;
  }
}
</style>

