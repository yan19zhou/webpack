import { initFormModelList } from "@/api/form/form.js";
import { getModelList,getModelListFromParent } from "@/api/form/form.js";

export function initModelList(model, params, state) {
  /* 通用模型列表初始化获取业务主键和筛选路径 */
  return new Promise((resolve) => {
    return initFormModelList(model, params)
      .then((res) => {
		if(!res.keyList.length){
			res.keyList = [{
				name:"主键ID【无法通过关键字搜索】",
				attr:"uuid"
			}];
		}
        state.tableHeads = res;
        resolve(res.pathList);
      })
      .catch((err) => {
        console.log(err);
      });
  });
}

/* 模型列表 */
export const getModelData = (model, param, state) => {
  console.log("请求查询模型列表数据-------------");
  getModelList(model, param).then((res) => {
    console.log(res);
    state.list = res;
    if (param.page.current == res.pages) {
      state.finished = true;
      return;
    }
    param.page.current++;
  });
};

export const getListFromParent = (model,parent,parentId,param,state)=>{
	console.log("请求查询模型列表数据Parent-------------");
	getModelListFromParent(model,parent,parentId, param).then((res) => {
		console.log(res);
		state.list = res;
		if (res.pages == 0 || param.page.current == res.pages) {
			state.finished = true;
			return;
		}
		param.page.current++;
	});
};
