<!--
 * @Description: 基礎表單，動態加載確定返回字段後更改
 * @Author: zhouy
 * @Date: 2021-10-09 09:52:36
 * @LastEditTime: 2021-11-02 11:47:54
 * @LastEditors: zhouy
-->
<template>
  <!-- ref根据表单ID来设置 暂时没有做 -->

  <u-form class="component-form" ref="formIn">
    <u-collapse v-model="activeNames" class="block">
      <u-collapse-item open>
        <view v-for="item in fields.attrs" :key="item.attr_name">
          <u-form-item :label="item.view_label" v-if="item.component_type=='inline'" label-width="150">
            <component :is="item.component_label" v-model="obj[item.attr_name]" :item="item" />
            <template #right>
              <c-rightIcon :strategy="item.strategy" />
            </template>
          </u-form-item>
            <component v-else :is="item.component_label" v-model="obj[item.attr_name]" :item="item" />
        </view>
      </u-collapse-item>
    </u-collapse>
  </u-form>
</template>
<script>
// import { getFormModel } from "@/api/form/form";

// import DatePick from "@/components/form-native-components/date.vue";
import { data } from "./data";
import { validateMessage } from "@/js/validator.js";
import addEvents from "../js/addEvents.js";
export default {
  props: {
    parentIds: Object | Array,
    modelAttrs: Object | Array,
    formData: Object,
  },
  data() {
    return {
      activeNames: [],
      fields: data,
      obj: { name: "AS0100,JSG0101",radio:"CO2" ,},
    };
  },
  watch: {
    obj: {
      handler(val) {
        console.log("----obj", val);
      },
      immediate: true,
      deep: true,
    },
  },
  methods: {},
  setup(props, { emit }) {
    /* 显示规则挂载 */
    const modelScript = window.modelScript;
    const _param = window._param;
    // const param = window.param;
    const inputTypes = ["input", "number", "textarea", "password"];
    const { proxy } = getCurrentInstance();
    const formIn = ref(null);
    // 通过props传入所有父级ID
    let base = reactive({});
    let primalData = {};

    let state = reactive({
      attrs: props.modelAttrs,
    });

    /*************** 打开关闭 *****************/
    const activeNames = ref([]);
    // 初始化数据
    for (let a in state.attrs) {
      if (state.attrs[a].modelAttributeType.is_spread) {
        activeNames.value.push(parseInt(a));
      }
    }
    /**************** 结束 ********************/
    if (state.attrs) initObj(state.attrs, base, primalData);
    let objVisiable = reactive(null);
    onMounted(() => {
      //新增表单重置表单数据

      // 采查策略筛选
      const strategysCheck = inject("checked");
      let taskFields = [];
      watch(
        () => strategysCheck,
        val => {
          console.log("strategysCheck", val.checked);
          if (!objVisiable) return;
          for (const key in base) {
            if (Object.hasOwnProperty.call(base, key)) {
              const show = objVisiable[key].show;
              const item = base[key];
              if (!val.checked.length) {
                item.show = show;
                continue;
              }
              item.show = false;
              if (item.business_label && item.business_label.length) {
                item.show = item.business_label.some(v => {
                  return val.checked.includes(v);
                });
              }
              // 任务字段
              if (taskFields.length) {
                item.show = taskFields.includes(key);
              }
            }
          }
        },
        { immediate: true, deep: true }
      );
      /*       proxy.$bus.on("strategysCheck", (checked) => {
        // console.log("checked", checked);
        // 通过checked过滤 base数据

      }); */

      // 点击筛选的时候缓存一份显示情况用来重置

      proxy.$bus.on("handlerSearch", () => {
        if (objVisiable) {
          return;
        }
        objVisiable = JSON.parse(JSON.stringify(base));
      });
    });

    // 初始化显示规则 把表单数据传进去
    modelScript.init(base);
    //验证规则测试

    function xx(val) {
      // console.log(val);
      if (val === null || val === "" || val === " " || val === undefined) {
        return false;
      }
      return true;
    }

    /* 提交 */
    let submitOjb = {};
    const failed = errorInfo => {
      base[errorInfo.errors[0].name].focus = true;
      emit("submit", { type: "error", info: errorInfo.errors });
    };
    const submit = () => {
      // 只取变化的部分
      for (const key in base) {
        if (Object.hasOwnProperty.call(base, key)) {
          if (!base[key].show) continue;
          if (props.formData) {
            const element = props.formData[key];
            if (base[key].value !== element || key == "uuid") {
              submitOjb[key] = base[key].value;
            } else if (submitOjb[key]) {
              delete submitOjb[key];
            }
          } else {
            submitOjb[key] = base[key].value;
          }
        }
      }
      emit("submit", "ok");
      return new Promise(resolve => {
        let keys = Object.keys(submitOjb);
        if (keys.includes("uuid") && keys.length == 1) {
          submitOjb = {};
        }
        resolve(submitOjb);
      });
    };
    /* 监听模型和反显数据变化 */
    watch(
      () => props.modelAttrs,
      newValue => {
        console.log("-----------props.modelAttrs----------", newValue);
        if (props.modelAttrs) {
          state.attrs = props.modelAttrs;
          initObj(props.modelAttrs, base, primalData);
          if (props.formData) {
            setFormData(props.formData, base);
          }
        }
      },
      { immediate: false, deep: true }
    );

    watch(
      () => props.formData,
      newValue => {
        if (newValue) {
          // form中传来的数据反显
          setFormData(newValue, base);
        }
      },
      { immediate: true, deep: true }
    );
    watch(
      () => base.DianTiShu,
      val => {
        if (val) {
          console.log("DianTiShu==", JSON.stringify(val));
        }
      },
      { immediate: false, deep: true }
    );
    return {
      state,
      activeNames,
      failed,
      base,
      xx,
      // submitBtn,
      modelScript,
      _param,
      inputTypes,
      validateMessage,
      primalData,
      submit,
      submitOjb,
      formIn,
      addEvents,
    };
  },
};

function initObj(attrs, base, primalData) {
  console.log("----------------");
  for (const key in base) {
    if (Object.hasOwnProperty.call(base, key)) {
      delete base[key];
      delete primalData[key];
    }
  }
  attrs.map(item => {
    item.fields.map(v => {
      base[v.name] = {
        value: v.base.default_value,
        show: v.base.is_show,
        required: v.business_label.includes("is_must"),
        is_readonly: v.base.is_readonly,
        business_label: v.business_label,
      };
      primalData[v.name] = v.base.default_value;
    });
  });
}
function setFormData(newValue, base) {
  if (!base) {
    base = {};
  }
  for (const key in newValue) {
    if (!base[key]) {
      base[key] = {};
    }
    if (Object.hasOwnProperty.call(newValue, key)) {
      const el = newValue[key];
      if (key == "uuid") {
        base["uuid"] = { value: el };
        continue;
      }
      base[key].value = el;
    }
  }
}
</script>
<style lang="scss">
.component-form {
  .van-collapse-item__content {
    padding-left: 0;
    padding-right: 0;
  }
  .van-cell__title,
  .van-cell__value {
    text-align: left;
  }
  // .van-field__error-message {
  //  display: none;
  // }
}
</style>
<style lang="scss" scoped>
.form-item-title {
  color: $color-green;
}
.block {
  width: 95%;
  margin: 5px auto !important;
  border-radius: 5px;
  box-shadow: 0px 2px 5px #ccc;
}
</style>
