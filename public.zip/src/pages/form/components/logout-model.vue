<template>
  <van-dialog
    :show="confirmShow"
    title="注销"
    className="model-logout"
    show-cancel-button
    @confirm="confirm"
    @cancel="cancel"
  >
    <p>请输入注销原因</p>
    <textarea type="text" class="logout-input border-1px" v-model="delReason" />
  </van-dialog>
</template>

<script>
import { ref } from "vue";
import { Toast } from "vant";

export default {
  props: ["confirmShow"],
  setup(props, { emit }) {
    let delReason = ref("");
    const confirm = () => {
      if (!delReason.value) {
        Toast("请输入注销原因!");
        return ;
      }
      emit("delClose",delReason);
      
    };
    const cancel = () => {
      emit("delCancel");
    };
    return { confirm, delReason, cancel };
  },
};
</script>
<style lang="scss" scoped>
.model-logout {
  .logout-input {
    height: 1.5rem;
    width: 80%;
    border-radius: 10px;
    margin-top: 10px;
    padding-left:10px ;
    border: solid 1px $color-deep;
  }
}
</style>
<style lang="scss" >
.model-logout {
  .van-dialog__header {
    padding-top: 0.2rem;
    font-weight: bold;
  }
}
</style>