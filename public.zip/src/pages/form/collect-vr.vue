<template>
  <view class="fullView collect-vr">
    <view class="building-name">楼栋{{ buildingName }}</view>
    <view class="title">
      <view>VR全景图</view>
    </view>
    <view class="vr-image">
		<view>
      <navigator :url="`/panoramaCollect?bid=${bid}&type=${type}`">
      	<van-image width="100" height="100" src="static/images/vr/add.png" />
      </navigator>
		</view>
      <view v-for="imageInfo in vrImageInfo" :key="imageInfo.sid">
        <!-- <van-popover
          v-model:show="showPopover[imageInfo.sid]"
          :actions="actions"
          placement="top"
          overlay="true"
          @select="(e)=>popoverSelect({text:e.text,name:imageInfo.name,key:imageInfo.key,sid:imageInfo.sid,userKey:userKey})"
        >
          <template #reference>
            <van-image width="100" height="100" :src="IMG_API+'/' + imageInfo.image" />
          </template>
        </van-popover> -->
        <view class="image-name">{{ imageInfo.title }}</view>
      </view>
    </view>
  </view>
</template>

<script>
import { removeVrImageInfo, getVrInfo } from "./js/getModel";
import { IMG_API } from "@/api/api-config";

export default {
  data() {
    let router = useRoute();
    return {
      vrImageInfo: [],
      bid: router.query.bid,
      type: router.query.type,
      showPopover: [],
    }
  },

  setup() {
    const actions = [{ text: "预览" }, { text: "编辑" }, { text: "删除" }];
    const userKey = sessionStorage.getItem("token");
    return {
      userKey,
      actions,
      IMG_API,
    };
  },

  created() {
    const userKey = sessionStorage.getItem("token");
    this.getVrImageInfo(userKey)
  },

  methods: {
    getVrImageInfo(userKey) {
      getVrInfo({ userKey, bid: this.bid, type: this.type }).then((data) => {
        if (data.scenes.length > 0) {
          this.vrImageInfo = data.scenes.map((a) => {
            this.showPopover[a.sid] = false;
            return {
              key: a.vid,
              image: a.preview,
              name: a.name,
              title: a.title,
              sid: a.sid,
            };
          });
        } else {
          this.vrImageInfo = []
        }
      });
    },

    popoverSelect(even) {
      console.log(even);
      switch (even.text) {
        case "预览":
          return this.perviewImage(even.name, even.key);
        case "编辑":
          return this.editorImage(even.name, even.key);
        default:
          return this.removeImage(even)
      }
    },

    perviewImage(name, vid) {
      window['wx'].miniProgram.navigateTo({ url: `/pages/vr/view?name=${name}&vid=${vid}` });
    },

    editorImage(name, vid) {
      window['wx'].miniProgram.navigateTo({ url: `/pages/vr/edit?name=${name}&vid=${vid}` });
    },

    removeImage(even) {
      removeVrImageInfo({ userKey: even.userKey, sceneId: even.sid, name: even.name }).then((res) => {
        if (res.code === 200) {
          uni.showToast({title:'删除成功'})
          this.getVrImageInfo(even.userKey)
        } else {
           uni.showToast({title:'删除失败'})
        }
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.collect-vr {
  .building-name {
    text-align: left;
    margin: 15px 20px;
    font-size: 18px;
  }

  .title {
    border-bottom: 1px solid #eeeeee;
    border-top: 1px solid #eeeeee;
    padding: 15px;
    color: #1160e8;
    font-size: 20px;
    font-weight: 600;
  }

  .vr-image {
    margin: 30px 10px;
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;

    .image-name {
      text-align: center;
      color: #333;
    }
  }
}
</style>
