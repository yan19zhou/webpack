import {
  getFormModel,
  getFormData,
  getVisitLast,
  saveVisit,
  removeVrImage,
  getVr,
  submitVr,
  uploadVrImage,
} from "@/api/form/form";

/* 获取模型数据 */
export const getModel = (state, modelName, _this) => {
  return new Promise((resolve, reject) => {
    if (hasModel(state, modelName, _this)) {
      resolve(true);
      return;
    }

    getFormModel(modelName)
      .then((result) => {
        if (!result) {
          resolve(true);
        }
        setState(state, result, _this);
        // 结果缓存到session中
        let obj = JSON.parse(sessionStorage.getItem("$ModelData")) || {};
        obj[modelName] = result;
        sessionStorage.setItem("$ModelData", JSON.stringify(obj));
        resolve(true);
      })
      .catch((err) => {
        console.log(err);
        reject(err);
      });
  });
};
function hasModel(state, modelName, _this) {
  let modelObj = JSON.parse(sessionStorage.getItem("$ModelData"));
  if (modelObj && modelObj[modelName]) {
    setState(state, modelObj[modelName], _this);
    return true;
  } else {
    return false;
  }
}
function setState(state, result, _this) {
  state.attrs = result.attrs;
  state.relations = result.relations;
  state.extend_tables = result.extend_tables;
  let vr = false;
  if (result.base && _this) {
    vr = result.base.is_vr;
    _this(vr);
  }
}
/* 表单返显数据 */
export const getFormObj = (model, sign, params, state, index, cb) => {
  //primary:主表，extend:子表
  getFormData(model, sign, params).then((res) => {
    if (sign == "primary") {
      state.data = res;
    } else {
      state.data[index] = res;
      cb(res);
    }

    console.log(res);
  });
};
/* 表单数据保存 */
export const saveFormObj = () => {
  //
};

/* 走访 */
//获取走访信息
export const getVisitInfo = (model, params, state) => {
  getVisitLast(model, params).then((res) => {
    state.visitTime = new Date(res.visitTime)
      .toLocaleDateString()
      .replace(/['/']/g, "-");
  });
};
// 更新走访信息
export const saveVisitInfo = (model, params, state) => {
  saveVisit(model, params).then((res) => {
    if (res) {
      console.log(res);
      state.visitTime = new Date().toLocaleDateString().replace(/['/']/g, "-");
    }
  });
};

export const removeVrImageInfo = (param) => {
  return removeVrImage(param)
}

export const getVrInfo = (param) => {
  return getVr(param)
}

export const submitVrInfo = (param) => {
  return submitVr(param)
}

export const uploadVrImageInfo = (param) => {
  return uploadVrImage(param)
}
