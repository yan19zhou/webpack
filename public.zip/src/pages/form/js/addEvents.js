export default function addEvents(events) {
  if (events.length < 1) {
    return {};
  }
  let obj = {};
  events.map((item) => {
    obj[item.event_key] = function() {
        eval(item.function);
    };
  });
  return obj;
}
