<template>
  <view style="overflow: hidden">
    <!-- nav导航栏 -->
    <!-- 筛选 -->
    <view class="header flex-bw">
      <text class="f18 text-dark">{{ Ids.name }}</text>
      <Strategys-search type="common" @change="strategysChange" />
    </view>
    <!-- VR -->
    <view v-if="showVr && Ids.toKey" @click="toVr">
      <view v-if="showVr" class="row link-VR flex-bw" style>
        <view style="display: flex; align-items: center">
          <text class="iconfont iconvedio"></text>
          <text>采集VR</text>
        </view>
        <u-icon name="arrow-right" color="#fff"></u-icon>
      </view>
    </view>
    <view class="form">
      <Form :Ids="Ids" @vrChange="vrChange" :modelName="Ids.to" />
    </view>
    <!-- 显示隐藏选择列表按钮 -->
    <view class="right-btns">
      <u-button class="handler-list mb8 fc" type="primary" @click="handlerList"
        ><u-icon name="search"></u-icon
      ></u-button>
      <c-toTop ele="form-container" />
    </view>
    <!-- 选择列表 -->
    <Popup :isshow="showPopup" :Ids="Ids" @changeValue="changeValue" :modelName="Ids.name" @close="closeP" />
  </view>
</template>

<script>
import Form from "./components/form";
import Popup from "./components/popupList/index";
import StrategysSearch from "./components/strategys-search";
import { pwdEncrypt } from "utils/utils.js";
export default {
  name: "common-form",
  components: {
    Form,
    Popup,
    StrategysSearch,
  },
  provide: {
    checked: () => this.strategys,
  },
  data() {
    return {
      Ids: null,
      showPopup: false,
      showVr: false,
      strategys: [],
    };
  },
  onLoad(e) {
    // 拿到路由传参
    this.initIds(e);
  },
  methods: {
    toVr() {
      // 进入vr页面
      this.$u.route({
        url: "pages/form/collect-vr",
        params: { bid: Ids.toKey, type: Ids.to },
      });
    },
    initIds(query) {
      // 进入页面后拿到路由传参和申明模块定义
      this.Ids = Object.assign({ toKey: null, from: null, fromKey: null }, query);
      console.log(this.Ids);
      /**
       * 缓存数据本次模型编辑的数据情况，防止页面重新刷新
       */
      const aesstring = pwdEncrypt(JSON.stringify(query));
      const data = sessionStorage.getItem(aesstring);
      if (data) {
        this.Ids = reactive(JSON.parse(data));
      }
      // 目录--通用列表添加
      uni.$on("addForm", data => {
        for (const key in data) {
          if (Object.hasOwnProperty.call(data, key)) {
            this.Ids.from = key;
            this.Ids.fromKey = data[key];
          }
        }
      });
      //通用采集key
      var k = "c" + (this.Ids.from || "") + (this.Ids.fromKey || "") + this.Ids.to;
      if (!this.Ids.toKey) {
        this.Ids.toKey = sessionStorage.getItem(k);
      }
      console.log(this.Ids.toKey);
      if (!this.Ids.toKey) {
        setTimeout(() => {
          this.showPopup = true;
        });
      }
    },
    handlerList() {
      this.showPopup = true;
    },
    vrChange(item) {
      if (item.type != null) {
        this.showVr = item.type;
      }
      if (item.toKey) {
        this.Ids.toKey = item.toKey;
      }
    },
    closeP() {
      this.showPopup = false;
    },
    strategysChange(v) {
      this.strategys.checked = v;
    },
    changeValue(item) {
      this.Ids.toKey = item.uuid;
      this.Ids.from = item.$parent_model || "";
      this.Ids.fromKey = item.$parent_id || "";
      /*********变更数据后缓存数据****************/
      const aesstr = pwdEncrypt(JSON.stringify(this.Ids));
      sessionStorage.setItem(aesstr, JSON.stringify(this.Ids));
      /*****************缓存结束****************/
      this.showPopup = false;
    },
  },
};
</script>

<style lang="scss" scoped>
.header {
  height: 40px;
  text {
    font-weight: 400;
  }
}
.form {
  height: calc(100% - 40px);
  overflow-y: auto;
}
.right-btns {
  width: 50px;
  position: fixed;
  right: 0;
  bottom: 56px;
  .handler-list {
    width: 40px;
    height: 40px;
    color: #fff;
    border-radius: 0;
  }
}
.flex-bw {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding-left: 20px;
  padding-right: 20px;
  padding-top: 0.4rem;
  padding-bottom: 0.4rem;
  box-sizing: border-box;
  .text-dark {
    @include font_size(36rpx);
  }
}
.link-VR {
  height: 30px;
  line-height: 30px;
  color: #fff;
  background: $color-blue;
  .iconvedio {
    margin-right: 6px;
    font-size: 14px;
    color: #fff;
  }
}
</style>
