<template>
  <view class="custom-form">
    <!-- nav 导航栏 -->

    <!-- 楼栋名称----筛选 -->
    <view class="header flex-bw">
      <view class="title">
        <p class="name f18 mb4">{{ Ids.name }}</p>
        <p class="address">
          <van-icon name="location" class="mr8" color="#999" />
          <span>{{ Ids.address || "龙华区龙华街道10号中山公园旁" }}</span>
        </p>
      </view>
        <Strategys-search type="custom" @change="strategysChange" />
    </view>
    <!-- 模型地址 -----重新定位按钮 -->
    <view class="path flex-bw border-top-1px">
      <view class="path-left">
        <i class="iconfont icondingwei1 mr10"></i>
        <span>{{ state.path || "无" }}</span>
      </view>
      <view class="path-right" @click="switchBuilding(true)">
        楼房切换
        <i class="iconfont iconqiehuan-"></i>
      </view>
    </view>
    <!-- VR -->
    <router-link
      v-if="showVr && Ids.toKey"
      :to="{ path: '/collectVr', query: { bid: Ids.toKey, type: Ids.to } }"
      exact
    >
      <view v-if="showVr" class="row link-VR flex-bw" style="">
        <view style="display: flex; align-items: center">
          <i class="iconfont iconvedio"></i><span>采集VR</span>
        </view>
        <van-icon name="arrow" color="#fff" />
      </view>
    </router-link>
    <!-- 楼房切换右边栏 -->
    <RightBar
      @refreshModel="refreshModel"
      @hideBar="switchBuilding(false)"
      @add="add"
      :buildingId="Ids.toKey"
      :name="Ids.name"
      :isShow="showRightBar"
    />
    <!-- 主体表单 -->
    <view class="form">
      <Form
        :Ids="Ids"
        @vrChange="vrChange"
        :modelName="Ids.to"
        :uuid="Ids.toKey"
      />
    </view>
    <!-- 返回顶部 -->
    <ToTop ele="form-container" class="back-top" />
    <!-- 选择添加模型弹窗 -->
    <AddDialog
      :isShow="isShowAddDialog"
      @cancel="isShowAddDialog = false"
      :pId="state.buildingId"
      @refreshModel="refreshModel"
    />
  </view>
</template>

<script>
import Form from "./components/form";
import RightBar from "./components/rightBar";
import ToTop from "@/components/toTop/index";
import StrategysSearch from "./components/strategys-search";
import AddDialog from "@/components/custom-add-path/index.vue";

import { useRoute } from "vue-router";
import { reactive, ref, toRefs, provide } from "vue";
export default {
  name:"customForm",
  components: {
    Form,
    RightBar,
    ToTop,
    StrategysSearch,
    AddDialog,
  },
  provide() {
    return {
      pathStart: this.Ids.pathStart,
    };
  },
  setup() {
    let route = useRoute();
    let Ids = reactive(route.query);
    // console.log(Ids);

    let state = reactive({ building: {}, buildingId: route.query.toKey });
    let leftBarState = reactive({
      showRightBar: false,
      switchBuilding(type) {
        leftBarState.showRightBar = type;
      },
      refreshModel(item) {
        // 楼房切换
        Ids.to = item.model; //模型名
        Ids.toKey = item.uuid; //uuid
        Ids.fromKey = item.pid; //父ID
        Ids.from = item.parent; //父模型名
        state.path = item.address;
        if (item.type == "add") {
          leftBarState.isShowAddDialog = false;
        } else {
          // 关闭侧边栏
          leftBarState.showRightBar = false;
        }
      },
      isShowAddDialog: false,
      add() {
        leftBarState.showRightBar = false;
        leftBarState.isShowAddDialog = true;
      },
    });

    let showVr = ref(false);
    const vrChange = (item) => {
      if (item.type) {
        showVr.value = item.type;
      }
      if (item.toKey) {
        Ids.toKey = item.toKey;
      }
    };
    /* 采查策略 */
    let strategys = reactive({ checked: [] });
    const strategysChange = (v) => {
      strategys.checked = v;
    };
    provide("checked", strategys);

    return {
      Ids,
      state,
      showVr,
      vrChange,
      ...toRefs(leftBarState),
      strategysChange,
    };
  },
};
</script>

<style lang="scss" scoped>
.header {
  padding-top: 6px;
  padding-bottom: 6px;
  .title {
    text-align: left;
    .name {
      font-weight: 800;
    }
    .address {
      color: $uni-text-color-grey;
      font-size: 12px;
      display: flex;
      align-items: center;
      .mr8 {
        font-size: 14px;
      }
    }
  }
}
.path {
  height: 40px;
  .path-left {
    i {
      color: #accaff;
    }
    span {
      color: $uni-text-color;
      font-size: 14px;
    }
  }
  .path-right {
    color: $color-blue;
  }
}
.link-VR {
  height: 30px;
  line-height: 30px;
  color: #fff;
  background: $color-blue;
  .iconvedio {
    margin-right: 6px;
    font-size: 14px;
    color: #fff;
  }
}
.flex-bw {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding-left: 20px;
  padding-right: 20px;
  box-sizing: border-box;
}
.back-top {
  width: 50px;
  position: fixed;
  right: 0;
  bottom: 56px;
}
.form {
  height: calc(100% - 150px);
}
</style>