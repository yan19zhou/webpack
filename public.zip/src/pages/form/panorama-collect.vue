<template>
  <view class="fullView panorama-collect">
    <view class="des-title">
      <span class="left">操作说明</span>
      <span class="right" @click="handleClick(describeShow)">{{ describeShow?'隐藏':'显示' }}</span>
    </view>
    <view class="des-content" v-show="describeShow==true">
      <view v-for="item in describeInfo" :key="item.key">
        <view class="item">{{ `${item.key}、${item.text}` }}</view>
      </view>
    </view>
    <van-form @submit="onSubmit">
      <view class="form">
        <van-field
          v-model="sceneName"
          name="sceneName"
			@blur="vali()"
          label="场景名称"
          placeholder="场景名称"
          :rules="[{ required: true, message: '请输入场景名称' }]"
        />
        <van-field
          v-model="describe"
          name="describe"
          label="描述"
			@blur="vali()"
          placeholder="描述"
          :rules="[{ required: true, message: '请输入描述' }]"
        />
        <view class="uploader" @click="uploaderClick">
          <van-image :src="image" />
          <view class="image" v-if="existImage==true">
            <van-button icon="exchange" type="primary">替换照片</van-button>
          </view>
        </view>
      </view>
      <van-button class="button bg-{{ clor }}" native-type="submit">生成场景</van-button>
    </van-form>
  </view>
</template>

<script>
import { Toast } from "vant";
import { submitVrInfo } from "./js/getModel";
import { upload } from "@/api/form/image.js";

export default {
  data() {
    return {
      existImage: false,
      sceneName: '',
      describe: '',
      mediaId: '',
      describeShow: true,
      image: require('@/assets/images/vr/vr-add.png'),
		clor:'gray'
    };
  },

  setup() {
    const describeInfo = [
      { key: 1, text: "请使用指定相机拍摄全景图片；" },
      { key: 2, text: "选择相册中已存在拍摄完成的VR全景图片；" },
      { key: 3, text: "填写VR场景的名称及描述，选择全景图进行上传；" },
    ];

    return {
      describeInfo,
    };
  },

  methods: {
    handleClick(value) {
      this.describeShow = !value;
    },
	vali(){
		debugger
		if(this.sceneName && this.describe && this.mediaId){
			this.clor = 'blue';
		}else{
			this.clor = 'gray';
		}
	},
    onSubmit() {
      const that = this;
		if(this.clor == 'gray'){
			Toast('请填写场景名称，场景描述，上传场景全景图。');
			return;
		}
      const query = that.$router.currentRoute.value.query

      if (!this.existImage) {
        Toast('全景图片不能为空')
      } else {
        const param = { bid: query.bid, media_id: that.mediaId, title: this.sceneName, type: query.type, remark: this.describe };
        submitVrInfo(param).then(() => {
          Toast('场景生成成功')
          that.$router.back();
        })
      }
    },

    uploaderClick() {
      const that = this;

      window["wx"].chooseImage({
        count: 1,
        sourceType: ['album'],
        sizeType: ['original'],
        success: function (res) {
          window["wx"].getLocalImgData({
            localId: res.localIds[0],
            success: function (res1) {
              var localData = res1.localData; // localData是图片的base64数据，可以用img标签显示
              if (localData.indexOf('data:image') != 0) {
                //判断是否有这样的头部
                localData = 'data:image/jpeg;base64,' + localData;
              }
              localData = localData.replace(/\r|\n/g, '').replace('data:image/jgp', 'data:image/jpeg');
              const param = { imageData: localData }
              upload(param).then((data) => {
                console.log(data);
                Toast('图片上传成功。');
                that.mediaId = data.fileId;
                that.image = res.localIds[0];
                that.existImage = true;
				that.vali();
              });
            },
            fail: function (e) {
              Toast('图片上传失败' + JSON.stringify(e));
            }
          });
        },
        fail: function (e) {
          Toast('保存服务器失败' + JSON.stringify(e))
        }
      });
    }

  }
};
</script>

<style lang="scss">
.panorama-collect {
  .des-title {
    margin: 20px 20px 0 20px;
    font-size: 13px;
    overflow: hidden;

    .left {
      float: left;
    }

    .right {
      float: right;
      color: #1989fa;
    }
  }

  .des-content {
    text-align: left;
    margin: 10px 20px;
    line-height: 16px;
    .item {
      padding-top: 6px;
    }
  }

  .form {
    margin: 20px;

    .van-cell {
      padding: 10px 0 !important;
    }

    .uploader {
      position: relative;
      margin-top: 20px;
      width: 100%;
      height: 150px;
      overflow: hidden;

      .van-image {
        width: 100%;
        height: 150px;
      }

      img {
        height: 150px;
      }

      .image {
        position: absolute;
        width: 100%;
        bottom: 25px;

        button {
          height: 30px;
          width: 230px;
        }
      }
    }
  }

  .button {
    position: absolute;
    bottom: 0;
    width: 100%;
    left: 0;
    background: #000;
    opacity: 0.5;
    color: #fff;
    height: 55px;
    font-size: 17px;
    border: none;
  }
}
</style>
