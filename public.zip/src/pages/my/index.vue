<template>
  <!-- 我的 -->
  <view class="my">
    <view class="header">
      <view class="info">
        <u-avatar :src="user.avatar" :size="140" @click="changeName"></u-avatar>
        <view class="name-grid">
          <p class="name">{{ user.name || "=姓名=" }}</p>
          <p class="phone">
            <span>{{ user.phone || "手机号" }}</span>
          </p>
        </view>
      </view>
      <u-icon
        @click="infoModify"
        class="infoModify"
        label="个人信息修改"
        label-pos="left"
        label-color="#fff"
        name="arrow-right"
        color="#fff"
        size="20"
        top="2"
      ></u-icon>
    </view>
    <view class="grid">
      <view class="grid-name">
        您目前正处在：
        <span class="text-dark">
          <u-icon name="reload" color="#333" :size="32" @click="clearDefault()"></u-icon>
          {{ currentGrid.label }}
        </span>
      </view>
      <!-- <u-dropdown>
        <u-dropdown-item v-model="currentGrid" :options="options" title="切换网格"> </u-dropdown-item>
      </u-dropdown>-->
      <c-dropdown v-model="currentGrid" :options="options">
        <template #reference>
          <view class="switch-grid">
            切换网格
            <text class="icon iconfont iconqiehuan- f12"></text>
          </view>
        </template>
      </c-dropdown>
    </view>
    <view class="main">
      <view v-for="(item, index) in list" :key="item.name" class="group">
        <view class="line" v-show="index !== 0"></view>
        <u-cell-group>
          <u-cell-item
            class="item"
            v-for="cell in item.list"
            :key="cell.icon"
            :icon="require('static/images/' + cell.icon + '.png')"
            icon-size="48"
            :title="cell.title"
            is-link
            @click="jump(cell.path)"
          >
            <view v-if="cell.title === '消息' && totalUnread > 0 " class="count">{{ totalUnread }}</view>
          </u-cell-item>
        </u-cell-group>
      </view>
    </view>
    <u-toast ref="uToast" />
  </view>
</template>

<script>
import { navList } from "./config";
import { Decrypt } from "utils/utils.js";
import { postNoReadMessage } from "@/api/my.js";
export default {
  data() {
    return {
      list: navList,
      userInfo: JSON.parse(sessionStorage.getItem("$USER_INFO")),
      currentGrid: {},
      hintShow: false,
      user: {},
      options: [],
      totalUnread: 0,
    };
  },
  onShow() {
    !this.gridName && this.initData();
    this.noRead();
  },
  methods: {
    // 未读信息
    noRead() {
      postNoReadMessage({
        token: sessionStorage.token,
      }).then(res => {
        this.totalUnread = res.noRead < 999 ? res.noRead : '999+';
      });
    },
    initData() {
      const gridCode = sessionStorage.getItem("$gridCode");
      const { name, avatar } = this.userInfo || {};
      this.user = {
        name,
        avatar,
        phone: Decrypt(this.userInfo?.mobile),
      };

      if (this.userInfo?.grids?.length) {
        this.options = this.userInfo.grids.map(item => {
          let text = item.isAdmin == "1" ? "【主管】" : "【代管】";
          const gridName = item.gridName + text;
          if (item.gridCode == gridCode) {
            this.currentGrid = { value: gridCode, label: gridName };
          }
          return { label: gridName, value: item.gridCode };
        });
      }
    },
    // 切换网格
    clearDefault() {
      uni.showModal({
        title: "系统提示",
        content: "是否清除默认网格，清除默认网格后，在进入系统后会提示您选择相应网格操作",
        duration: 2000,
        success: res => {
          if (res.cancel) return;
          localStorage.removeItem("$gridRemember");
          sessionStorage.removeItem("$gridCode");
          localStorage.removeItem("$gridCode");
          this.currentGrid.label = "";
          this.currentGrid.value = "";
          this.$refs.uToast.show({
            title: "清除默认网格成功！",
            type: "success",
          });
        },
      });
    },
    // 个人信息修改
    infoModify() {
      uni.navigateTo({
        url: "info-modify",
      });
    },
    jump(url) {
      uni.navigateTo({
        url: url.path,
      });
    },
  },
  watch: {
    currentGrid(val) {
      console.log(val);
      sessionStorage.setItem("$gridCode", val.value);
      localStorage.removeItem("$gridCode");
    },
  },
};
</script>

<style lang="scss" scoped>
.my {
  .header {
    width: 100%;
    height: 350rpx;
    background-image: url("/static/images/my_bg.png");
    background-size: 100% 100%;
    box-sizing: border-box;
    color: $color-white;

    .info {
      height: 140rpx;
      transform: translateY(160rpx);
      display: flex;
      align-items: center;
      padding-left: 48rpx;
      box-sizing: border-box;
      position: relative;
      .name-grid {
        margin-left: 40rpx;
        text-align: left;
        .name {
          font-weight: 400;
          @include font_size(40rpx);
        }
        .phone {
          padding-top: 20rpx;
          @include font_size(24rpx);
        }
      }
      .arrow {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        right: 40rpx;
      }
    }
    .infoModify {
      min-width: 266rpx;
      height: 62rpx;
      padding: 0 24rpx;
      border-radius: 60rpx;
      border: 2rpx solid #fff;
      position: absolute;
      top: 216rpx;
      right: 60rpx;
      /deep/ .u-icon__label {
        @include font_size(26rpx);
      }
    }
  }
  .grid {
    display: flex;
    padding: 60rpx 36rpx 40rpx;
    align-items: center;
    border-bottom: solid 2rpx #cfcfcf;
    .grid-name {
      color: $uni-text-color-grey;
      margin-right: 20rpx;
      @include font_size(28rpx);
    }
    .switch-grid {
      color: $text-blue;
      padding: 6rpx 16rpx;
      border: solid 2rpx $text-blue;
      border-radius: 22rpx;
      @include font_size(24rpx);
      white-space: nowrap;
    }
  }
  .main {
    .group {
      /deep/ .u-cell_title {
        @include font_size(28rpx);
      }
      .line {
        width: 100%;
        height: 18rpx;
        background: #f8f8f8;
        border: 0px solid #f1f1f1;
      }
      .item {
        &::after {
          right: 0;
          left: 0;
        }
      }
      /deep/ .u-cell__value {
        text-align: left;
        .count {
          color: #fff;
          width: 50rpx;
          height: 50rpx;
          display: inline-block;
          text-align: left;
          border-radius: 50%;
          line-height: 50rpx;
          margin-left: 20rpx;
          text-align: center;
          @include font_size(20rpx);
          background-color: #ff2525;
        }
      }
    }
  }
}
</style>
