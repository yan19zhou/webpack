<!--
 * @Description: {

 }
 * @Author: zhouy
 * @Date: 2021-11-03 14:17:43
 * @LastEditTime: 2021-11-16 11:58:03
 * @LastEditors: zhouy
-->
<template>
  <view class="theme">
    <nav-top>
      <template #left-slot>
        <view>主题切换</view>
      </template>
    </nav-top>

    <view class="container">
      <view class="overall-style">
        <view class="title">整体风格</view>
        <view class="content">
          <view @click="theme = true" :class="['img-box', theme ? 'img-box-active' : '']">
            <u-image class="u-avatar-demo" width="84rpx" height="138rpx" src="../../static/images/theme1.png"></u-image>
          </view>
          <view @click="theme = false" :class="['img-box', !theme ? 'img-box-active' : '']">
            <u-image class="u-avatar-demo" width="84rpx" height="138rpx" src="../../static/images/theme2.png"></u-image>
          </view>
        </view>
      </view>
      <view class="overall-style">
        <view class="title">主题配色</view>
        <view class="content">
          <view
            v-for="item in colorList"
            :key="item.id"
            class="colour"
            :style="{ backgroundColor: item.color }"
            @click="colorChange(item)"
          >
            <u-icon v-show="item.state" class="select" size="40" color="#fff" name="checkmark"></u-icon>
          </view>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
import navTop from "@/components/c-navTop/c-navTop.vue";
export default {
  components: {
    navTop,
  },
  data() {
    return {
      theme: uni.getStorageSync("lifeData").appNav ? true : false,
      colorList: [
        {
          id: 1,
          color: "#2D8CF0",
          state: true,
        },
        {
          id: 2,
          color: "#5FB878",
          state: false,
        },
        {
          id: 3,
          color: "#1E9FFF",
          state: false,
        },
        {
          id: 4,
          color: "#FFB800",
          state: false,
        },
        {
          id: 5,
          color: "#A9A9A9",
          state: false,
        },
      ],
    };
  },
  onLoad() {
    const appTheme = uni.getStorageSync("lifeData").appTheme;
    if (appTheme) {
      const index = appTheme.substring(5);
      this.colorList[0].state = false;
      this.colorList[index - 1].state = true;
    }
  },
  watch: {
    // 主题风格
    theme(newVal) {
      this.$u.vuex("appNav", newVal);
      window["wx"].miniProgram.navigateTo({
        url: "/pages/index/index",
      });
    },
  },
  methods: {
    // 主题配色
    colorChange(data) {
      const id = data.id;
      if (!data.state) {
        this.colorList.forEach(item => {
          if (item.id === id) {
            item.state = true;
          } else {
            item.state = false;
          }
        });
        let data = "theme" + id;
        this.$u.vuex("appTheme", data);
        document.body.setAttribute("data-theme", data);
        window["wx"].miniProgram.navigateTo({
          url: "/pages/index/index",
        });
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.theme {
  height: 100vh;
  background-color: #f4f6f8;
  .container {
    padding: 0 30rpx;
  }
  .overall-style {
    padding-top: 42rpx;
    .title {
      opacity: 0.7;
      color: #1d1d1d;
      margin-bottom: 22rpx;
      @include font_size(24rpx);
    }
    .content {
      padding: 40rpx;
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      border-radius: 20rpx;
      background-color: #fff;
      .img-box {
        border-radius: 8rpx;
        padding: 16rpx 18rpx;
        &:not(:last-child) {
          margin-right: 48rpx;
        }
      }
      .img-box-active {
        border: 6rpx solid #2d8cf0;
      }
      .colour {
        width: 64rpx;
        height: 64rpx;
        display: flex;
        align-content: center;
        justify-content: center;
        border-radius: 4rpx;
        &:not(:last-child) {
          margin-right: 44rpx;
          
        }
      }
    }
  }
}
</style>
