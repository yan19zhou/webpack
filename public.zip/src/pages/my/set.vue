<!--
 * @Description: @Description
 * @Author: zhouy
 * @Date: 2021-11-16 11:38:07
 * @LastEditTime: 2021-11-16 18:05:41
 * @LastEditors: zhouy
-->
<template>
  <view class="set">
    <nav-top>
      <template #left-slot>
        <view>设置</view>
      </template>
    </nav-top>
    <view class="content">
      <u-cell-group>
        <u-cell-item @click="jump('modify-font')" class="iconfont iconziti" title="字体大小" value="标准"></u-cell-item>
        <u-cell-item @click="jump('theme')" class="iconfont iconpifu" title="主题" value="深色"></u-cell-item>
      </u-cell-group>
      <u-cell-group>
        <u-cell-item @click="clear" title="清除缓存"></u-cell-item>
      </u-cell-group>
    </view>
  </view>
</template>

<script>
import navTop from "@/components/c-navTop/c-navTop.vue";
export default {
  components: {
    navTop,
  },
  methods: {
    jump(url) {
      uni.navigateTo({
        url,
      });
    },
    // 清除缓存
    clear() {
      const data = uni.getStorageSync("lifeData");
      localStorage.clear();
      sessionStorage.clear();
      data.appTheme && this.$u.vuex("appTheme", data.appTheme);
      data.scaling && this.$u.vuex("scaling", data.scaling);
      data.appNav && this.$u.vuex("appNav", data.appNav);
      uni.showToast({
        title: "清除缓存成功",
        duration: 2000,
      });
      window["wx"].miniProgram.navigateTo({
        url: "/pages/index/index",
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.set {
  height: 100vh;
  background-color: #f4f6f8;
  .content {
    padding: 30rpx;
    /deep/ .u-cell-box {
      margin-bottom: 34rpx;
      .u-cell-item-box {
        border-radius: 20rpx;
      }
      .iconfont {
        @include font_size(36rpx);
      }
      .u-cell_title {
        color: #666;
        margin-left: 10rpx;
        @include font_size(28rpx);
      }
      .u-cell__value {
        color: #1d1d1d;
        @include font_size(28rpx);
      }
      .iconziti,
      .iconpifu {
        color: #4687f7;
        @include font_size(40rpx);
      }
    }
  }
}
</style>
