<template>
  <view class="news">
    <nav-top>
      <template #left-slot>
        <view>消息</view>
      </template>
      <template #right-slot>
        <view @click="unread">{{isUnread ? '只看未读' : '全部'}}</view>
      </template>
    </nav-top>

    <u-dropdown title-size="40" style="height:80rpx" menu-icon-size="30" inactive-color="#000">
      <u-dropdown-item @change="typeChange" v-model="value" :title="label" :options="typeList"></u-dropdown-item>
    </u-dropdown>

    <scroll-view @scrolltolower="loadMore" scroll-y="true" class="container">
      <view v-for="(item, key) in messageList.result" :key="item.id" class="box">
        <view class="time">{{ key }}</view>
        <view v-for="msg in item" :key="msg.id" class="info">
          <u-image class="portrait" width="60rpx" height="60rpx" :src="src"></u-image>
          <view class="right">
            <view class="title">
              {{ msg.message_title }}
              <span :style="{color: msg.is_new ? '#ed2323' : '#999'}" class="red">NEW</span>
            </view>
            <view class="desc">
              {{ msg.message_content }}
            </view>
            <view class="">
              <u-icon
                class="details"
                name="arrow-right"
                size="20"
                color="#4687F7"
                label-color="#4687F7"
                label="查看详情"
                label-pos="left"
              ></u-icon>
            </view>
          </view>
        </view>
      </view>
    </scroll-view>
  </view>
</template>

<script>
import navTop from "@/components/c-navTop/c-navTop.vue";
import { postUserMessage } from "@/api/my.js";
import { timeGroup } from "@/utils/timeGroup.js";
export default {
  components: {
    navTop,
  },
  data() {
    return {
      src: "../../static/images/face.jpg",
      messageList: [],
      value: '',
      label: '全部',
      typeList: [
        { label: "全部", value: "" },
        { label: "任务通知", value: "task" },
        { label: "系统反馈", value: "feedback" },
        { label: "系统公告", value: "notice" },
      ],
      isUnread: true,
      isLoadMore: false,
      pageNum: 1
    };
  },
  onLoad() {
    this.initData();
  },
  methods: {
    // 上拉加载更多
    loadMore() {
      if (this.isLoadMore) {
        return;
      }
      if (this.messageList.pageCount > 1 && this.messageList.pageCount > this.pageNum) {
        this.isLoadMore = true;
        this.initData(++this.pageNum);
      }
    },
    // 下拉列表
    typeChange(value) {
      this.typeList.forEach(item => {
        if(item.value === value) {
          this.label = item.label
        }
      })
      this.initData()
    },
    // 初始化数据
    initData() {
      let list = {};
      this.value && (list.message_type = this.value);
      list.is_new = this.isUnread ? 0 : 1;
      list.pageNum = this.pageNum;
      postUserMessage(list).then(res => {
        let group;
        let result = {};
        this.pageNum = res.pageNum;
        res.data &&
          res.data.forEach(item => {
            group = timeGroup(item.operate_time, "日");
            if (result[group]) {
              result[group].push(item);
            } else {
              result[group] = [item];
            }
          });
        res.result = result;
        if (this.pageNum > 1) {
          this.isLoadMore = false;
          res.result[group] = [...this.messageList.result[group], ...res.result[group]];
        }
        this.messageList = res;
      });
    },
    // 只看未读
    unread() {
      this.isUnread = !this.isUnread
      this.initData()
    },
  },
};
</script>

<style lang="scss" scoped>
.news {
  height: 100vh;
  display: flex;
  flex-direction: column;
  background-color: #f4f6f8;
  /deep/ .u-dropdown {
    flex: inherit;
    background-color: #fff;
  }
  .container {
    flex: 1;
    overflow-y: hidden;
  }
  .box {
    margin: 48rpx 0;
    .time {
      color: #999;
      text-align: center;
      @include font_size(24rpx);
    }
    .info {
      padding: 24rpx 40rpx 0;
      display: flex;
      .portrait {
        width: 60rpx;
        height: 60rpx;
        flex-shrink: 0;
        margin-right: 26rpx;
      }
      .right {
        flex: 1;
        padding-top: 40rpx;
        border-radius: 14rpx;
        background-color: #fffffc;
        .title,
        .desc {
          padding: 0 30rpx;
        }
        .title {
          color: #000;
          font-weight: bold;
          @include font_size(32rpx);
        }
        .desc {
          color: #999;
          margin: 32rpx 0;
          @include font_size(24rpx);
        }
        .details {
          display: flex;
          padding: 30rpx 40rpx;
          @include font_size(24rpx);
          border-top: 2rpx solid #d1d1d1;
        }
      }
    }
  }
  .red {
    margin-left: 16rpx;
    @include font_size(20rpx);
  }
}
</style>
