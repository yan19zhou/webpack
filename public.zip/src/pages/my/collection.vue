<template>
  <view class="collection">
    <nav-top>
      <template #left-slot>
        <view>采查情况</view>
      </template>
    </nav-top>

    <view class="time">
      <view @click="timeChange('start')" class="time-box">
        <u-icon
          name="arrow-down-fill"
          label="开始时间"
          label-pos="left"
          label-color="#000"
          color="#B8B8B8"
          size="10"
          margin-right="16"
        ></u-icon>
      </view>
      <view @click="timeChange('end')" class="time-box">
        <u-icon
          name="arrow-down-fill"
          label="结束时间"
          label-pos="left"
          label-color="#000"
          color="#B8B8B8"
          size="10"
          margin-right="16"
        ></u-icon>
      </view>
      <u-picker @confirm="startTime" mode="time" v-model="show" :params="params"></u-picker>
    </view>

    <view class="content">
      <view class="tips">
        共采集
        <span class="blue">108</span> 条数据，其中：楼栋 <span class="blue">8</span> 条，单元
        <span class="blue">8</span> 条，楼层 <span class="blue">8</span> 条， 房间 <span class="blue">8</span> 条 ,其他
        <span class="blue">84</span> 条。
      </view>
      <u-time-line>
        <u-time-line-item nodeTop="2">
          <!-- 此处自定义了左边内容，用一个图标替代 -->
          <template v-slot:node>
            <view class="u-node">
              <!-- 此处为uView的icon组件 -->
              <u-icon
                name="pushpin-fill"
                label="楼栋"
                label-pos="bottom"
                label-color="#5787F5"
                color="#fff"
                :size="20"
              ></u-icon>
            </view>
          </template>
          <template v-slot:content>
            <view class="u-order-time">晚上21：15</view>
            <view class="container">
              <view class="u-order-box">
                <view class="left">
                  [自提柜]您的快件已放在楼下侧门，直走前方53.6米，左拐约10步，再右拐直走，见一红灯笼停下，叩门三下，喊“芝麻开门”即可。
                </view>
                <view @click="isDetails" class="right">{{ btnState ? "收起" : "详情" }}</view>
              </view>
              <u-table v-show="btnState">
                <u-tr>
                  <u-th>变更项</u-th>
                  <u-th>
                    变更前
                    <view class="blue">查看详情</view>
                  </u-th>
                  <u-th>
                    变更后
                    <view class="blue">查看详情</view>
                  </u-th>
                </u-tr>
                <u-tr>
                  <u-td>浙江大学</u-td>
                  <u-td>二年级</u-td>
                  <u-td>22</u-td>
                </u-tr>
                <u-tr>
                  <u-td>清华大学</u-td>
                  <u-td>05班</u-td>
                  <u-td>20</u-td>
                </u-tr>
              </u-table>
            </view>
          </template>
        </u-time-line-item>
        <u-time-line-item>
          <!-- 此处没有自定义左边的内容，会默认显示一个点 -->
          <template v-slot:content>
            <view class="u-order-time">晚上21：15</view>
            <view class="container">
              <view class="u-order-box">
                <view class="left">
                  [自提柜]您的快件已放在楼下侧门，直走前方53.6米，左拐约10步，再右拐直走，见一红灯笼停下，叩门三下，喊“芝麻开门”即可。
                </view>
                <view @click="isDetails" class="right">{{ btnState ? "收起" : "详情" }}</view>
              </view>
              <u-table v-show="btnState">
                <u-tr>
                  <u-th>变更项</u-th>
                  <u-th>
                    变更前
                    <view class="blue">查看详情</view>
                  </u-th>
                  <u-th>
                    变更后
                    <view class="blue">查看详情</view>
                  </u-th>
                </u-tr>
                <u-tr>
                  <u-td>浙江大学</u-td>
                  <u-td>二年级</u-td>
                  <u-td>22</u-td>
                </u-tr>
                <u-tr>
                  <u-td>清华大学</u-td>
                  <u-td>05班</u-td>
                  <u-td>20</u-td>
                </u-tr>
              </u-table>
            </view>
          </template>
        </u-time-line-item>
      </u-time-line>
    </view>
  </view>
</template>

<script>
import NavTop from "@/components/c-navTop/c-navTop.vue";
export default {
  components: {
    NavTop,
  },
  data() {
    return {
      params: {
        year: true,
        month: true,
        day: true,
      },
      show: false,
      timeText: "",
      btnState: false,
    };
  },
  methods: {
    // 时间弹窗
    timeChange(val) {
      this.show = true;
      this.timeText = val;
    },
    // 时间选择
    startTime(e) {
      console.log(e, this.timeText);
    },
    // 是否收起
    isDetails() {
      this.btnState = !this.btnState;
    },
  },
};
</script>

<style lang="scss" scoped>
.collection {
  height: 100vh;
  background: #f4f6f8;
  .time {
    display: flex;
    padding: 30rpx 40rpx;
    background-color: #fff;
    .time-box:not(:last-child) {
      margin-right: 150rpx;
    }
    /deep/ .u-icon__label {
      @include font_size(28rpx);
    }
  }
  .content {
    padding: 44rpx;
    .tips {
      color: #333;
      margin-bottom: 46rpx;
      @include font_size(24rpx);
      .blue {
        color: #4687f7;
      }
    }
    /deep/ .u-node .u-icon__label {
      @include font_size(20rpx);
    }
    .u-order-time {
      color: #868686;
      text-align: center;
      margin-bottom: 24rpx;
      @include font_size(20rpx);
    }
    /deep/ .container {
      background-color: #ffffff;
      .u-table,
      .u-th,
      .u-td {
        border: 0 !important;
        background-color: #fff !important;
      }
      .blue {
        color: #5787f5;
        margin: 12rpx 0;
      }
      .u-th {
        width: 30%;
        color: #333;
        @include font_size(24rpx);
      }
      .u-td {
        width: 30%;
        display: block;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        color: #666 !important;
        @include font_size(24rpx);
      }
    }
    .u-order-box {
      padding: 20rpx;
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-radius: 20rpx;
      box-shadow: 0px 18rpx 48rpx 0px rgba(0, 0, 0, 0.04);
      .left {
        color: #333;
        @include font_size(24rpx);
      }
      .right {
        color: #666;
        margin-left: 40rpx;
        white-space: nowrap;
        @include font_size(24rpx);
      }
    }
    /deep/ .u-icon__icon {
      width: 48rpx;
      height: 48rpx;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      background: #5787f5;
    }
    /deep/ .u-time-axis-node {
      top: 50% !important;
      background: transparent !important;
    }
    /deep/ .u-time-axis::before {
      border-left: 2rpx dashed #5787f5;
    }
  }
}
</style>
