<template>
  <view class="modify-font">
    <nav-top>
      <template #left-slot>
        <view>字体大小</view>
      </template>
    </nav-top>

    <view class="content">
      <view class="slider">
        <u-slider v-model="value" step="32" block-width="56"></u-slider>
        <view class="label-list">
          <view class="small">小</view>
          <view class="standard">标准</view>
          <view class="large">大</view>
          <view class="oversized">超大</view>
        </view>
      </view>
      <view class="text">
        黑格尔《美学》
        <br />
        <span class="desc">一个深广的心灵总是把兴趣的领域推广到无数事物 上去。 </span>
      </view>
    </view>
  </view>
</template>

<script>
import navTop from "@/components/c-navTop/c-navTop.vue";
export default {
  components: {
    navTop,
  },
  data() {
    return {
      // 获取字体修改状态
      value: uni.getStorageSync("lifeData").scaling ? uni.getStorageSync("lifeData").scaling.value : 32,
    };
  },
  watch: {
    // 监听字体修改状态
    value(newVal, oldVal) {
      if (newVal !== oldVal) {
        var size;
        switch (newVal) {
          case 0:
            size = 0.8;
            break;
          case 32:
            size = 1;
            break;
          case 64:
            size = 1.2;
            break;
          case 96:
            size = 1.5;
            break;
        }
        this.$u.vuex("scaling", { size, value: this.value });
        document.body.setAttribute("data-size", size);
        uni.showToast({
          title: "字体大小修改成功",
          duration: 2000,
        });
        window["wx"].miniProgram.navigateTo({
          url: "/pages/index/index",
        });
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.modify-font {
  height: 100vh;
  background-color: #f4f6f8;
  /deep/ .slider {
    padding: 40rpx;
    margin-top: 18rpx;
    background-color: #fff;
    .label-list {
      display: flex;
      margin-top: 40rpx;
      align-items: center;
      counter-reset: #1d1d1d;
      justify-content: space-between;
    }
    .small {
      font-size: 24rpx;
    }
    .standard {
      font-size: 28rpx;
    }
    .large {
      font-size: 32rpx;
    }
    .oversized {
      font-size: 36rpx;
    }
  }
  .text {
    margin: 50rpx;
    color: #333;
    @include font_size(32rpx);
    font-weight: bold;
    .desc {
      display: block;
      color: #333;
      @include font_size(28rpx);
      margin-top: 38rpx;
      font-weight: 400;
    }
  }
}
</style>
