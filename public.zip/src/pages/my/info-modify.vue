<template>
  <view class="info-modify">
    <nav-top>
      <template #left-slot>
        <view>个人信息修改</view>
      </template>
      <template #right-slot>
        <view>完成</view>
      </template>
    </nav-top>
    <view class="content">
      <!-- 基本信息 -->
      <view class="basic">
        <view class="title">基本信息</view>
        <view class="form">
          <u-cell-group>
            <u-cell-item title="头像" :arrow="false">
              <u-avatar @tap="chooseAvatar" slot="right-icon" size="96" :src="basic.avatar"></u-avatar>
            </u-cell-item>
            <u-cell-item title="设备终端号" :arrow="false">
              <u-input
                v-model="basic.mobile"
                input-align="right"
                height="54"
                placeholder="请输入设备终端号"
                slot="right-icon"
                type="text"
              />
            </u-cell-item>
            <u-cell-item title="设备登录名" :arrow="false">
              <u-input
                v-model="basic.user_name"
                input-align="right"
                height="54"
                placeholder="请输入设备登录名"
                slot="right-icon"
                type="text"
              />
            </u-cell-item>
            <u-cell-item title="真实姓名" :arrow="false">
              <u-input
                v-model="basic.emp_name"
                input-align="right"
                height="54"
                placeholder="请输入真实姓名"
                slot="right-icon"
                type="text"
              />
            </u-cell-item>
            <u-cell-item title="身份证号" :arrow="false">
              <u-input
                v-model="basic.idcard"
                input-align="right"
                height="54"
                placeholder="请输入身份证号"
                slot="right-icon"
                type="text"
              />
            </u-cell-item>
          </u-cell-group>
        </view>
      </view>
      <!-- 扩展信息 -->
      <view class="basic">
        <view class="title">扩展信息</view>
        <view class="form">
          <u-cell-group>
            <u-cell-item title="胸牌号" :arrow="false">
              <u-input
                v-model="extend.brand_number"
                input-align="right"
                height="54"
                placeholder="请输入胸牌号"
                slot="right-icon"
                type="text"
              />
            </u-cell-item>
            <u-cell-item title="婚姻状况" :arrow="false">
              <u-input
                v-model="extend.marital_status"
                @click="isMarriage = true"
                height="54"
                width="310"
                type="select"
                placeholder="请选择婚姻状况"
              />
              <u-action-sheet :list="list" v-model="isMarriage" @click="marriageChange"></u-action-sheet>
            </u-cell-item>
            <u-cell-item title="生日" :arrow="false">
              <u-calendar @change="birth_dateChange" v-model="isbirth_date"></u-calendar>
              <u-input
                v-model="extend.birth_date"
                @click="isbirth_date = true"
                height="54"
                width="310"
                type="select"
                placeholder="请选择生日"
              />
            </u-cell-item>
            <u-cell-item title="民族" :arrow="false">
              <u-input
                v-model="basic.nation"
                input-align="right"
                height="54"
                placeholder="请输入民族"
                slot="right-icon"
                type="text"
              />
            </u-cell-item>
            <u-cell-item title="出生地" :arrow="false">
              <u-input
                v-model="basic.birth_place"
                input-align="right"
                height="54"
                placeholder="请输入出生地"
                slot="right-icon"
                type="text"
              />
            </u-cell-item>
            <u-cell-item title="血型" :arrow="false">
              <u-input
                v-model="basic.blood_type"
                input-align="right"
                height="54"
                placeholder="请输入血型"
                slot="right-icon"
                type="text"
              />
            </u-cell-item>
            <u-cell-item title="籍贯" :arrow="false">
              <u-input
                v-model="basic.native_place"
                input-align="right"
                height="54"
                placeholder="请输入籍贯"
                slot="right-icon"
                type="text"
              />
            </u-cell-item>
            <u-cell-item title="户籍" :arrow="false">
              <u-input
                v-model="basic.household_register"
                input-align="right"
                height="54"
                placeholder="请输入户籍"
                slot="right-icon"
                type="text"
              />
            </u-cell-item>
            <u-cell-item title="政治面貌" :arrow="false">
              <u-input
                v-model="basic.politic_countenance"
                input-align="right"
                height="54"
                placeholder="请输入政治面貌"
                slot="right-icon"
                type="text"
              />
            </u-cell-item>
            <u-cell-item title="教育背景" :arrow="false">
              <u-input
                v-model="basic.educational_background"
                input-align="right"
                height="54"
                placeholder="请输入教育背景"
                slot="right-icon"
                type="text"
              />
            </u-cell-item>
            <u-cell-item title="所学专业" :arrow="false">
              <u-input
                v-model="basic.major"
                input-align="right"
                height="54"
                placeholder="请输入所学专业"
                slot="right-icon"
                type="text"
              />
            </u-cell-item>
            <u-cell-item title="职称" :arrow="false">
              <u-input
                v-model="extend.professional_titles"
                @click="isMarriage = true"
                height="54"
                width="310"
                type="select"
                placeholder="请选择职称"
              />
              <u-action-sheet :list="list" v-model="isMarriage" @click="marriageChange"></u-action-sheet>
            </u-cell-item>
            <u-cell-item title="入职时间" :arrow="false">
              <u-calendar @change="birth_dateChange" v-model="isbirth_date"></u-calendar>
              <u-input
                v-model="extend.hiredate"
                @click="isbirth_date = true"
                height="54"
                width="310"
                type="select"
                placeholder="请选择入职时间"
              />
            </u-cell-item>
            <u-cell-item title="参加工作时间" :arrow="false">
              <u-calendar @change="birth_dateChange" v-model="isbirth_date"></u-calendar>
              <u-input
                v-model="extend.join_work_date"
                @click="isbirth_date = true"
                height="54"
                width="310"
                type="select"
                placeholder="请选择参加工作时间"
              />
            </u-cell-item>
            <u-cell-item title="进入网格时间" :arrow="false">
              <u-calendar @change="birth_dateChange" v-model="isbirth_date"></u-calendar>
              <u-input
                v-model="extend.join_grid_date"
                @click="isbirth_date = true"
                height="54"
                width="310"
                type="select"
                placeholder="请选择进入网格时间"
              />
            </u-cell-item>
            <u-cell-item title="星级" :arrow="false">
              <u-input
                v-model="basic.star_level"
                input-align="right"
                height="54"
                placeholder="请输入星级"
                slot="right-icon"
                type="text"
              />
            </u-cell-item>
            <u-cell-item title="副岗" :arrow="false">
              <u-input
                v-model="basic.deputy_post"
                input-align="right"
                height="54"
                placeholder="请输入副岗"
                slot="right-icon"
                type="text"
              />
            </u-cell-item>
            <u-cell-item title="是否兵役" :arrow="false">
              <u-input
                v-model="extend.is_military_service"
                @click="isMarriage = true"
                height="54"
                width="310"
                type="select"
                placeholder="请选择是否兵役"
              />
              <u-action-sheet :list="list" v-model="isMarriage" @click="marriageChange"></u-action-sheet>
            </u-cell-item>
          </u-cell-group>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
import NavTop from "@/components/c-navTop/c-navTop.vue";
import CryptoJS from "crypto-js";
import { Task_API } from "@/api/api-config";
// import {} from "@/api/personal-data.js";
export default {
  components: {
    NavTop,
  },
  data() {
    return {
      basic: {
        avatar: "https://cdn.uviewui.com/uview/common/logo.png", // 头像
        mobile: "", // 设备终端号
        user_name: "", // 设备登录名
        emp_name: "", // 真实姓名
        idcard: "", // 身份证号
      },
      extend: {
        brand_number: "", // 胸牌号
        marital_status: "", // 婚姻状况
        birth_date: "", // 生日
        nation: "", // 民族
        birth_place: "", // 出生地
        blood_type: "", // 血型
        native_place: "", // 籍贯
        household_register: "", // 户籍
        politic_countenance: "", // 政治面貌
        educational_background: "", // 教育背景
        major: "", // 所学专业
        professional_titles: "", // 职称
        hiredate: "", // 入职时间
        join_work_date: "", // 参加工作时间
        join_grid_date: "", // 进入网格时间
        star_level: "", // 星级
        deputy_post: "", // 副岗
        is_military_service: "", // 是否兵役
      },
      isMarriage: false,
      isbirth_date: false,
      list: [
        {
          value: "1",
          text: "已婚",
        },
        {
          value: "2",
          text: "未婚",
        },
        {
          value: "3",
          text: "保密",
        },
      ],
      userInfo: JSON.parse(sessionStorage.getItem("$USER_INFO")),
    };
  },
  onLoad() {
    this.uploadFile();
  },
  methods: {
    // 1.手机号、身份证2.前面保留的位数3.后面保留的位数
    plusXing(phone, startLength, endLength) {
      if (!phone) return "";
      const len = phone.length - startLength - endLength;
      if (len > 0) {
        let xing = "";
        for (let i = 0; i < len; i++) {
          xing += "*";
        }
        return phone.substr(0, startLength) + xing + phone.substr(phone.length - endLength);
      } else {
        return phone;
      }
    },
    // 解密方法
    Decrypt(word) {
      let key = CryptoJS.enc.Utf8.parse("1234567887654321");
      let iv = CryptoJS.enc.Utf8.parse("1234567887654321");
      if (!word) return "";
      let decrypt = CryptoJS.AES.decrypt(word, key, {
        iv: iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.ZeroPadding,
      });
      try {
        decrypt = CryptoJS.enc.Utf8.stringify(decrypt).toString();
      } catch {
        decrypt = "";
      }
      return decrypt;
    },
    uploadFile() {
      // 监听从裁剪页发布的事件，获得裁剪结果
      uni.$on("uAvatarCropper", path => {
        // this.avatar = path;
        console.log(path);
        // 可以在此上传到服务端
        uni.uploadFile({
          url: `${Task_API}/dynamic-form/v1/file/sysfeedback/upload`,
          filePath: path,
          name: "file",
          complete: res => {
            let obj = JSON.parse(res.data);
            this.basic.avatar = obj.data.message;
            console.log(obj);
          },
        });
      });
    },
    // 婚姻
    marriageChange(index) {
      this.extend.marriage = this.list[index].text;
    },
    // 生日
    birth_dateChange(e) {
      console.log(e);
    },
    // 图片裁切 
    chooseAvatar() {
      // // 此为uView的跳转方法，详见"文档-JS"部分，也可以用uni的uni.navigateTo
      this.$u.route({
        // 关于此路径，请见下方"注意事项"
        url: "/uview-ui/components/u-avatar-cropper/u-avatar-cropper",
        // 内部已设置以下默认参数值，可不传这些参数
        params: {
          // 输出图片宽度，高等于宽，单位px
          destWidth: 300,
          // 裁剪框宽度，高等于宽，单位px
          rectWidth: 200,
          // 输出的图片类型，如果'png'类型发现裁剪的图片太大，改成"jpg"即可
          fileType: "jpg",
        },
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.info-modify {
  height: 100vh;
  display: flex;
  flex-direction: column;
  background-color: #f4f6f8;
  .content {
    flex: 1;
    overflow-y: auto;
    margin-bottom: 40rpx;
  }
  .basic {
    padding: 40rpx 30rpx 0;
    .title {
      opacity: 0.7;
      @include font_size(26rpx);
      color: #1d1d1d;
      margin-bottom: 22rpx;
    }
    /deep/ .form {
      border-radius: 20rpx;
      background-color: #ffffff;
      .u-cell_title,
      .u-input__input {
        @include font_size(28rpx);
      }
      .u-action-sheet-item {
        @include font_size(32rpx);
      }
      .u-cell__value {
        color: #333;
      }
      .uni-input-placeholder,
      .uni-input-input {
        text-align: right;
      }
      .u-avatar__img {
        border-radius: 0 !important;
      }
    }
  }
}
</style>
