<template>
  <view class="feedback">
    <nav-top>
      <template #left-slot>
        <view>反馈</view>
      </template>
      <template #right-slot>
        <view @click="myFeedback">我的反馈</view>
      </template>
    </nav-top>

    <view class="content">
      <view class="title">反馈</view>
      <u-form :model="form" ref="uForm">
        <view class="info">
          <u-form-item label-width="190" label="反馈分类" prop="classify">
            <u-input v-model="classify" @click="show = true" type="select" placeholder="请选择反馈分类" />
            <u-action-sheet :list="list" v-model="show" @click="classifyChange"></u-action-sheet>
          </u-form-item>
          <u-form-item label-width="160" label-position="top" label="反馈标题(简短文字描述问题)" prop="title">
            <u-input v-model="form.title" placeholder="请输入问题概要" />
          </u-form-item>
          <u-form-item label-width="160" label-position="top" label="联系方式(我们有必要联系您)" prop="contact">
            <u-input v-model="form.contact" placeholder="请输入联系方式" />
          </u-form-item>
          <u-form-item
            prop="content"
            border="false"
            label-width="160"
            label-position="top"
            label="反馈内容(您遇到的问题，想解决什么问题？)"
          >
            <u-input v-model="form.content" :border="true" height="246" type="textarea" placeholder="请输入内容" />
          </u-form-item>
        </view>
        <view class="title">附件截图</view>
        <view class="enclosure">
          <view class="imgList" v-for="(item, index) in fileList" :key="item.id">
            <u-image v-if="item.type === 'img'" @click="previewImage(item.url)" :src="item.url"></u-image>
            <video v-else-if="item.type === 'video'" id="video_play" @play="playVedio" :src="item.url" :loop="true"></video>
            <u-icon @click="deleteImg(index)" name="close-circle-fill" class="close" size="50" color="red"></u-icon>
          </view>
          <view @click="uploadType" class="uploadBtn" style="border: 4rpx dashed #bbb;">
            <u-icon name="plus" size="60"></u-icon>
          </view>
        </view>
      </u-form>
      <u-button class="submit" @click="submit">提交</u-button>
    </view>
  </view>
</template>

<script>
import navTop from "@/components/c-navTop/c-navTop.vue";
import { postFeedback, postUploadAttachment, postDeleteAttachment } from "@/api/my.js";
import { Task_API } from "@/api/api-config";
export default {
  components: {
    navTop,
  },
  data() {
    return {
      show: false,
      classify: "",
      Task_API:Task_API,
      form: {
        type: "",
        title: "",
        contact: "",
        content: "",
      },
      fileList: [],
      rules: {
        type: [
          {
            required: true,
            message: "请选择反馈分类",
            trigger: "change",
          },
        ],
        title: [
          {
            required: true,
            message: "请输入问题概要",
            trigger: "blur",
          },
        ],
        contact: [
          {
            required: true,
            message: "请输入联系方式",
            trigger: "blur",
          },
          {
            pattern: /^1[3456789]\d{9}$/,
            // 正则检验前先将值转为字符串
            transform(value) {
              return String(value);
            },
            message: "联系方式不正确",
            trigger: "blur",
          },
        ],
        content: [
          {
            required: true,
            message: "请输入反馈内容",
            trigger: "blur",
          },
        ],
      },
      list: [
        {
          value: "JY",
          text: "建议",
        },
        {
          value: "YC",
          text: "异常反馈",
        },
      ],
      action: `${Task_API}/dynamic-form/v1/file/sysfeedbackattachment/upload`,
      imageList: [],
    };
  },
  methods: {
    // 重置表单
    resetForm() {
      this.classify = "";
      this.form = {
        type: "",
        title: "",
        contact: "",
        content: "",
      };
      this.imageList = [];
      this.fileList = [];
      this.$nextTick(() => {
        this.$refs.uForm.resetFields(this.rules);
      });
    },
    // 选择上传类型
    uploadType() {
      uni.showActionSheet({
        title: "选择上传类型",
        itemList: ["图片", "视频"],
        success: res => {
          if (res.tapIndex == 0) {
            this.chooseImages();
          } else {
            this.chooseVideo();
          }
        },
      });
    },
    // 上传接口
    uploadFile(data) {
      data.forEach(item => {
        uni.uploadFile({
          url: this.action,
          filePath: item.url,
          name: "file",
          header: { Authorization: sessionStorage.getItem("token") },
          success: res => {
            let obj = JSON.parse(res.data);
            this.imageList.push({
              file_path: obj.data.fileName,
              file_type: item.file_type
            });
            this.fileList.push({ url: obj.data.message, type: item.file_type });
            console.log(this.fileList)
          },
        });
      });
    },
    // 上传图片
    chooseImages() {
      uni.chooseImage({
        sizeType: ["original"],
        sourceType: ["album"], //从相册选择
        success: res => {
          let data = []
          res.tempFilePaths.map(item => {
            data.push({url: item,file_type: 'img'})
          })
          this.uploadFile(data);
        },
        fail: error => {
          uni.showModal({
            content: "图片上传失败",
          });
          console.log(error);
        },
      });
    },
    // 上传视频
    chooseVideo() {
      uni.chooseVideo({
        sourceType: ["album"],
        success: res => {
          let data = [{
            url: res.tempFilePath,
            file_type: 'video'
          }]
          this.uploadFile(data);
        },
        fail: error => {
          uni.showModal({
            content: "视频上传失败",
          });
          console.log(error);
        },
      });
    },
    // 视频播放
    playVedio() {
      this.videoContext = uni.createVideoContext('video_play');
      this.videoContext.requestFullScreen();
    },
    // 预览附件
    previewImage(url) {
      uni.previewImage({
        indicator: "number",
        urls: [url],
        current: url,
        fail: error => {
          console.log(error);
        },
      });
    },
    // 删除附件
    deleteImg(index) {
      postDeleteAttachment({
        model: "sysfeedbackattachment",
        file: this.imageList[index].file_path,
      }).then(res => {
        this.imageList.splice(index, 1);
        this.fileList.splice(index, 1);
        console.log(this.imageList, this.fileList);
      });
    },
    // 我的反馈
    myFeedback(type) {
      if (type === "showModal") {
        uni.showModal({
          title: "提示",
          content: "是否要进入我的反馈",
          success: res => {
            if (res.confirm) {
              this.myFeedback();
            }
          },
        });
      } else {
        uni.navigateTo({
          url: "my-feedback",
        });
      }
      this.resetForm();
    },
    // 反馈分类
    classifyChange(index) {
      this.classify = this.list[index].text;
      this.form.type = this.list[index].value;
    },
    // 上传附件
    uploadAnnex(id) {
      this.imageList.forEach(item => {
        item.feed_id = id;
      });
      postUploadAttachment(this.imageList).then(res => {
        console.log(res);
        this.resetForm();
        this.myFeedback("showModal");
      });
    },
    // 提交表单
    submit() {
      this.$refs.uForm.validate(valid => {
        if (valid) {
          postFeedback(this.form).then(res => {
            if (this.imageList.length > 0) {
              this.uploadAnnex(res);
            }
            this.resetForm();
            this.myFeedback("showModal");
          });
        }
      });
    },
  },
  onReady() {
    this.$refs.uForm.setRules(this.rules);
  },
};
</script>

<style lang="scss" scoped>
.feedback {
  height: 100vh;
  display: flex;
  flex-direction: column;
  background-color: #f4f6f8;
  .content {
    flex: 1;
    overflow-y: auto;
    padding: 40rpx 30rpx;
    margin-bottom: 120rpx;
    .title {
      opacity: 0.7;
      color: #1d1d1d;
      margin-bottom: 22rpx;
      @include font_size(26rpx);
    }
    /deep/ .u-form-item {
      @include font_size(28rpx);
      .u-input__input {
        @include font_size(28rpx);
      }
    }
    .info {
      margin-bottom: 40rpx;
      border-radius: 20rpx;
      background-color: #fff;
    }
    .enclosure {
      display: flex;
      flex-wrap: wrap;
      padding: 40rpx 30rpx;
      border-radius: 20rpx;
      background-color: #fff;
      /deep/ .u-list-item {
        margin: 0;
        margin-right: 12rpx;
      }
      .uploadBtn {
        width: 174rpx;
        height: 174rpx;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-right: 12rpx;
        margin-bottom: 12rpx;
      }
      /deep/ .imgList {
        position: relative;
        display: flex;
        align-items: center;
        .u-image,
        .uni-video-container,
        uni-video {
          width: 174rpx !important;
          height: 174rpx !important;
          margin-right: 12rpx;
          margin-bottom: 12rpx;
        }
        .close {
          position: absolute;
          top: 0;
          right: 0;
          z-index: 999;
        }
      }
    }
    .submit {
      position: fixed;
      left: 0;
      right: 0;
      bottom: 0;
      height: 106rpx;
      color: #ffffff;
      font-weight: bold;
      line-height: 106rpx;
      text-align: center;
      // border-radius: 20rpx;
      @include bg_color();
      @include font_size(32rpx);
    }
  }
}
</style>
