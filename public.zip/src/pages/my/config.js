
export const taskNavList = [
  // { title: "已分派", name: 'assigned', icon: "fenpai", path: { path: '/myTask', query: { name: 'assigned' } } },
  // { title: "已完成", name: 'completed', icon: "wancheng", path: { path: '/myTask', query: { name: 'completed' } } },
  // { title: "今日采查", name: 'find', icon: "caicha", path: { path: '/myTask', query: { name: 'find' } } },
  // { title: "今日走访", name: 'gone', icon: "zoufang", path: { path: '/myTask', query: { name: 'gone' } } },
  { title: "采集情况", name: 'gone', icon: "zoufang", path: { path: 'collection' } },
]

export let navList = [
  {
    type: "message",
    list: [{ title: "消息", name: '消息', icon: "xinxi", path: {path: 'news'} }],
  },
  {
    type: "visit",
    list: taskNavList,
  },
  {
    type: "about",
    list: [
      { title: "设置", name: '设置', icon: "fenpai", path: { path: 'set' } },
      { title: "反馈", name: '反馈', icon: "fankui", path: { path: 'feedback' } },
      { title: "关于", name: '关于', icon: "women", path: { path: 'about' } },
    ],
  },
];