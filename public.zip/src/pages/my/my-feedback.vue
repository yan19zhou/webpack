<template>
  <view class="my-feedback">
    <nav-top>
      <template #left-slot>
        <view>我的反馈</view>
      </template>
    </nav-top>

    <scroll-view @scrolltolower="loadMore" scroll-y="true" class="content">
      <view v-for="(item, key) in list.result" :key="key" class="box">
        <view class="month">{{ key }}月</view>
        <view v-for="val in item" :key="val.id" class="feedback">
          <view class="feedback-top">
            <view class="title">{{ val.title || "" }}</view>
            <view class="tips">{{ val.type === "JY" ? "建议" : "异常反馈" }}</view>
          </view>
          <u-read-more :toggle="true" show-height="160">
            <rich-text :nodes="val.content || ''"></rich-text>
          </u-read-more>
          <view class="feedback-bottom">
            <view class="time">{{ val.operate_time }}</view>
            <view class="feedback-btn">
              <u-icon
                @click="screenshot(val)"
                class="iconfont iconjietu"
                label-pos="bottom"
                label-color="#FAA319"
                label-size="24"
                label="查看截图"
              ></u-icon>
              <u-icon
                @click="reply(val)"
                class="iconfont icontianbao"
                label-pos="bottom"
                label-color="#1989FA"
                label-size="24"
                label="查看回复"
              ></u-icon>
            </view>
          </view>
          <!-- 截图 -->
          <view v-show="val.isScreenshot" class="screenshot">
            <view class="screenshot-title">截图</view>
            <view v-if="val.screenshotList.data" class="img-list">
              <view v-for="img in val.screenshotList.data" :key="img.id">
                <u-image
                  v-if="img.file_type === 'img'"
                  width="174"
                  height="174"
                  @click="previewImage(img.file_path)"
                  :src="img.file_path"
                ></u-image>
                <video v-else id="video_play" @play="playVedio" :src="img.file_path" :loop="true"></video>
              </view>
            </view>
            <view class="universal-tips">暂无截图</view>
          </view>
          <!-- 回复 -->
          <view v-show="val.isReply" class="reply screenshot">
            <view class="screenshot-title">管理员回复</view>
            <view v-if="val.replyList.data" class="comment">
              <view v-for="reply in val.replyList.data" :key="reply.id" class="comment-box">
                <u-image class="portrait" width="60" height="60" src="../../static/images/face.jpg"></u-image>
                <view class="comment-right">
                  <view class="info">
                    <view class="name">{{ reply.reply_username ? reply.reply_username : "小丁" }}</view>
                    <view class="time">{{ reply.result_time | tiemFormat }}</view>
                  </view>
                  <view class="text">
                    {{ reply.result_content }}
                  </view>
                </view>
              </view>
            </view>
            <view v-else class="universal-tips">暂无回复</view>
          </view>
        </view>
      </view>
    </scroll-view>
  </view>
</template>

<script>
import navTop from "@/components/c-navTop/c-navTop.vue";
import { getMyFeedback, getSeeAttachment, getFeedbackResult, getFileShow } from "@/api/my.js";
import { formatTime } from "@/utils/formatTime.js";
import { timeGroup } from "@/utils/timeGroup.js";
export default {
  components: {
    navTop,
  },
  data() {
    return {
      list: [],
      isLoadMore: false,
      pageNum: 1,
    };
  },
  onLoad() {
    this.initData(1);
  },
  // 下拉刷新
  onPullDownRefresh() {
    this.list = [];
    this.isLoadMore = false;
    this.pageNum = 1;
    this.initData(1);
    setTimeout(function() {
      uni.stopPullDownRefresh();
    }, 1000);
  },
  filters: {
    tiemFormat(val) {
      return formatTime(new Date(val));
    },
  },
  methods: {
    // 上拉加载更多
    loadMore() {
      if (this.isLoadMore) {
        return;
      }
      if (this.list.pageCount > 1 && this.list.pageCount > this.pageNum) {
        this.isLoadMore = true;
        this.initData(++this.pageNum);
      }
    },
    initData(pageNum) {
      getMyFeedback({ pageNum }).then(res => {
        let result = {};
        this.pageNum = res.pageNum;
        let group;
        res.data &&
          res.data.forEach(item => {
            item.isScreenshot = false;
            item.isReply = false;
            item.screenshotList = [];
            item.replyList = [];
            item.operate_time = formatTime(new Date(item.operate_time));
            group = timeGroup(item.operate_time, "月");
            if (result[group]) {
              result[group].push(item);
            } else {
              result[group] = [item];
            }
          });
        res.result = result;
        if (this.pageNum > 1) {
          this.isLoadMore = false;
          res.result[group] = [...this.list.result[group], ...res.result[group]];
        }
        this.list = res;
      });
    },
    // 预览附件
    previewImage(url) {
      uni.previewImage({
        indicator: "number",
        urls: [url],
        current: url,
      });
    },
    // 视频播放
    playVedio() {
      this.videoContext = uni.createVideoContext('video_play');
      this.videoContext.requestFullScreen();
    },
    // 查看截图
    screenshot(data) {
      data.isScreenshot = !data.isScreenshot;
      if (data.isScreenshot) {
        getSeeAttachment({ feed_id: data.id }).then(res => {
          res.data &&
            res.data.forEach(item => {
              getFileShow({ file: item.file_path, model: "sysfeedbackattachment" }).then(res => {
                item.file_path = res;
                console.log(item.file_path,res)
              });
            });
          data.screenshotList = res;
        });
      }
    },
    // 查看回复
    reply(data) {
      data.isReply = !data.isReply;
      if (data.isReply) {
        getFeedbackResult({ feed_id: data.id }).then(res => {
          data.replyList = res;
          console.log(res);
        });
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.my-feedback {
  height: 100vh;
  display: flex;
  flex-direction: column;
  box-sizing: border-box;
  background-color: #f4f6f8;
  .universal-tips {
    text-align: center;
    @include font_size(32rpx);
  }
  .content {
    flex: 1;
    overflow-y: hidden;
    padding: 0 40rpx 40rpx;
    box-sizing: border-box;
    .box {
      margin-top: 48rpx;
      &:not(:last-child) {
        margin-bottom: 48rpx;
      }
      .month {
        color: #999;
        margin-bottom: 22rpx;
        @include font_size(26rpx);
      }
      .feedback {
        padding: 26rpx;
        border-radius: 14rpx;
        background-color: #fff;
        &:not(:last-child) {
          margin-bottom: 16px;
        }
        .feedback-top {
          display: flex;
          margin-bottom: 34rpx;
          align-items: center;
          justify-content: space-between;
          .title {
            color: #000;
            @include font_size(32rpx);
          }
          .tips {
            color: #f0521a;
            @include font_size(24rpx);
          }
        }
        /deep/ .u-content {
          @include font_size(26rpx);
        }
        .feedback-bottom {
          display: flex;
          align-items: flex-end;
          justify-content: space-between;
          .time {
            color: #999;
            @include font_size(24rpx);
          }
          .feedback-btn {
            display: flex;
            align-items: center;
            /deep/ .u-icon__label {
              white-space: nowrap;
              @include font_size(24rpx);
            }
            .iconjietu {
              color: #faa319;
              margin-right: 32rpx;
              @include font_size(36rpx);
            }
            .icontianbao {
              color: #1989fa;
              @include font_size(36rpx);
            }
          }
        }
      }
      .screenshot {
        margin-top: 26rpx;
        border-top: 2rpx solid #f1f1ef;
        .screenshot-title {
          color: #999;
          margin-top: 26rpx;
          @include font_size(24rpx);
        }
        .img-list {
          display: flex;
          flex-wrap: wrap;
          margin-top: 36rpx;
          .u-image {
            margin-right: 20rpx;
            margin-bottom: 20rpx;
          }
          .uni-video-container,
          uni-video {
            width: 174rpx !important;
            height: 174rpx !important;
            margin-right: 20rpx;
            margin-bottom: 20rpx;
          }
        }
      }
      .comment {
        .comment-box {
          display: flex;
          margin-top: 42rpx;
        }
        .portrait {
          min-width: 60rpx;
        }
        .comment-right {
          margin-left: 28rpx;
        }
        .info {
          display: flex;
          align-items: center;
          .name,
          .time {
            @include font_size(24rpx);
          }
          .time {
            color: #999;
            margin-left: 12rpx;
          }
        }
        .text {
          color: #333;
          margin-top: 24rpx;
          @include font_size(24rpx);
        }
      }
    }
    ::v-deep .u-content {
      text-indent: 0 !important;
    }
  }
}
</style>
