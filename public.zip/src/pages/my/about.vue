<template>
  <view class="about">
    <nav-top>
      <template #left-slot>
        <view>关于我们</view>
      </template>
    </nav-top>

    <view class="content">
      <view class="introduce">
        <view class="title">应用介绍</view>
        <view class="box">这是一个用纯文本的简单卡片。但卡片可以包含自己的页头，页脚，列表视图，图像，和里面的任何元素。</view>
      </view>
      <view class="contact introduce">
        <view class="title">联系我们</view>
        <view class="box">
          <view>你可以通过以下方式联系客服技术</view>
          <view class="img-list">
            <view class="img-box">
              <u-image width="100%" height="320rpx" src="../../static/images/face.jpg"></u-image>
              <view class="img-text">客服qq群</view>
            </view>
            <view class="img-box">
              <u-image width="100%" height="320rpx" src="../../static/images/face.jpg"></u-image>
              <view class="img-text">技术客服微信</view>
            </view>
          </view>
          <view class="information">
            <view class="information-box">
              <i class="iconfont icondianhua"></i>
              <view class="phone">技术咨询电话：18665839320</view>
            </view>
            <view class="information-box">
              <i class="iconfont iconQQ"></i>
              <view class="phone">远程支持qq：2964929616</view>
            </view>
            <view class="information-box">
              <i class="iconfont iconyouxiang"></i>
              <view class="phone">投诉邮箱：30260998@qq.com</view>
            </view>
          </view>
        </view>
      </view>
    </view>
    <view class="footer">
      <view>版本 V2.0.20211027 技术支持</view>
      <view>版权所有 深圳市宝安区网格管理办公室</view>
      <view>深圳中科保泰科技有限公司</view>
    </view>
  </view>
</template>

<script>
import navTop from "@/components/c-navTop/c-navTop.vue";
export default {
  components: {
    navTop
  },
};
</script>

<style lang="scss" scoped>
.about {
  height: 100vh;
  overflow-y: auto;
  background: #f4f6f8;
  .content {
    padding: 42rpx 30rpx;
  }
  .introduce {
    .title {
      opacity: 0.7;
      color: #1d1d1d;
      @include font_size(26rpx);
    }
    .box {
      padding: 38rpx;
      color: #1d1d1d;
      margin-top: 22rpx;
      line-height: 44rpx;
      border-radius: 20rpx;
      background-color: #fff;
      @include font_size(24rpx);
    }
  }
  .contact {
    margin-top: 28rpx;
    .img-list {
      display: flex;
      padding: 0 20rpx;
      margin-top: 28rpx;
      justify-content: space-between;
    }
    .img-box {
      flex: 1;
      &:not(:last-child) {
        margin-right: 60rpx;
      }
      .img-text {
        color: #999;
        margin-top: 28rpx;
        text-align: center;
        @include font_size(26rpx);
      }
    }
  }
  .information {
    margin-top: 92rpx;
    .information-box {
      display: flex;
      align-items: center;
      margin-bottom: 26rpx;
      line-height: 32rpx;
      .iconfont {
        color: #4687F7;
      }
      .phone {
        margin-left: 26rpx;
        @include font_size(26rpx);
      }
    }
  }
  .footer {
    color: #999;
    margin: 60rpx 0;
    text-align: center;
    line-height: 42rpx;
    @include font_size(24rpx);
  }
}
</style>
