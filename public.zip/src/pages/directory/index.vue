<template>
  <!-- 目录 -->
  <view class="dir-wrap">
    <!-- <c-navTop /> -->
    <view class="dir" v-for="(part, index) in list" :key="part.type">
      <view class="dir-build">
        <view class="title">{{ part.name }}</view>
        <view class="items">
          <view class="item" v-for="node in part.nodes" :key="node.key" @click="addModel(node, part.type)">
            <text :class="['iconfont icon', 'f18', node.icon || 'iconloudongweixianpin']"></text>
            <text :class="node.name.length > 4 ? 'item-name' : ''">
              {{ node.name }}
            </text>
          </view>
        </view>
      </view>
      <view class="line" v-if="index !== list.length - 1"></view>
    </view>
    <u-top-tips ref="uTips">
      <view class="tips"
        ><img src="static/images/deng.png" alt="" srcset="" /> <span class="tip-content">点击图标快速采查</span></view
      >
    </u-top-tips>
  </view>
</template>

<script>
import { GetParts } from "@/api/directory.js";
export default {
  data() {
    return {
      list: {},
    };
  },
  onLoad() {
    this.getParts();
  },
  onShow() {
    // 调用顶部提示信息
    this.$nextTick(() => {
      this.$refs.uTips.show({
        duration: "2000",
      });
    });
  },
  methods: {
    async getParts() {
      const res = await GetParts();
      this.list = res || [];
    },
    addModel(item, type) {
      console.log(item, type);
      //跳转到对应新增表单页面
      this.$u.route({
        url: "pages/form/common-form",
        params: { to: item.key, name: item.name, toKey: "", pathStart: type || item.key },
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.dir-wrap {
  width: 100vw;
  height: 100vh;
  overflow-y: auto;
  padding-bottom: 40px;
  box-sizing: border-box;
  @include font_size(24rpx);
  .dir {
    width: 100%;
    // min-height: calc(100vh - 50px);
    // padding-bottom: 50px;
    box-sizing: border-box;
    overflow-y: auto;
    background: rgba(149, 157, 174, 0.04);
    .dir-build {
      // height: 278px;
      padding-bottom: 20px;
    }
    .line {
      width: 100%;
      height: 6px;
      background: #b4b4b4;
      opacity: 0.2;
    }
    .dir-build,
    .dir-part {
      padding-top: 25px;
      padding-left: 26px;
      box-sizing: border-box;
      text-align: left;
      .title {
        font-weight: bold;
        color: #ec891f;
        margin-bottom: 28px;
        @include font_size(38rpx);
      }
      .items {
        display: flex;
        flex-wrap: wrap;

        .item {
          width: 120rpx;
          height: 120rpx;
          display: flex;
          justify-content: center;
          flex-direction: column;
          align-items: center;
          margin-right: 12rpx;
          margin-bottom: 15px;
          background: #fffffc;
          box-shadow: 0px 3px 12px 1px rgba(24, 24, 24, 0.07);
          border-radius: 10px;
          .iconfont {
            color: $color-black;
          }
          .item-name {
            width: 100%;
            padding: 0 6px;
            box-sizing: border-box;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
          }
        }
      }
    }
  }
}

.tips {
  img {
    height: 22px;
    margin-right: 11px;
  }
}
.tip-content {
  padding: 4px 8px;
  color: #2372fe;
  @include font_size(28rpx);
}
/deep/ .u-tips {
  background: rgba(80, 143, 254, 0.12);
}
</style>
