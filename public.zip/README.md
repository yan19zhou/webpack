
# 采集端重构
> 使用框架：uni-app
> 使用ui框架：uview
> css预处理语音：scss
> 鉴权：获取小程序端webview中url携带的userkey(该逻辑写在main.js中)
> 格式化规范：prettier+eslint
## 项目目录
collect-app-new
├─ .env                   --为项目环境变量配置文件 可配置相关环境中需使用的变量值
├─ .env.development
├─ .env.production
├─ .env.test
├─ .eslintrc.js           --
├─ babel.config.js
├─ package-lock.json
├─ package.json
├─ postcss.config.js       -- PostCSS相关插件的配置
├─ prettier.config.js
├─ public
│  └─ index.html
├─ README.md
├─ src
│  ├─ api               --http请求
│  ├─ App.vue  
│  ├─ components       --公共组件，全局组件统一c-*格式
│  ├─ js
│  ├─ main.js          --入口
│  ├─ manifest.json    --uni-app的配置
│  ├─ pages            --页面
│  │  ├─ directory
│  │  ├─ form
│  │  ├─ map
│  │  │  ├─ components   --页面组件
│  │  │  ├─ index.vue    --主页面代码
│  │  │  ├─ js           --页面逻辑
│  │  ├─ my
│  │  └─ task
│  ├─ pages.json      --页面配置
│  ├─ static          --静态资源
│  │  ├─ iconfont
│  │  └─ images
│  ├─ store           --vuex 
│  │  ├─ $u.mixin.js
│  │  └─ index.js
│  ├─ style          --公共样式及公共类
│  │  ├─ global.scss
│  │  ├─ index.scss
│  │  ├─ reset.scss
│  │  └─ utils.scss
│  ├─ uni.scss      --样式变量，项目变量已经全部合并到这里，$uni开头的是uni原来的变量，其他为本项目根据ui自定义的变量
│  ├─ utils         --工具方法
│  │  ├─ formatTime.js
│  │  ├─ utils.js
│  │  └─ watermark.js
│  └─ uview-ui  --使用ui框架
└─ tsconfig.json

## 项目说明
 ### 四个根模块
 - 任务：
 - 地图：
    - 使用地图组件：arcgis，目前已测试可用
    - 其他功能见ui
 - 目录：
    - 该页面为采集快捷入口，页面已经重构完成
 - 我的：
    - 用户基础信息，网格变更及任务入口
    - 主页面已重构部分

### 表单设计
 - 表单组件
   - 组件目录：src/components 
   - 表单构成：基础表单+扩展表+左右关系
   - 基础表单：使用动态组件加载，所有事件绑定及内部传值，及规则校验从动态组件传入
              <component  :is=""  v-on[event]=""  v-model="" v-bind="" / >
   - 组件设计：uview中有的用uview的组件，针对自定义组件部分，注意需要调用小程序或h5api的部分 使用uniapp兼容方案
   - 模型数据 ：1、返回模型属性和视图属性更改状态，如果数据不为最新则缓存最新数据，请求视图数据
               2、请求视图数据：渲染视图，因为模板是根据数据来渲染的 在配置端重构之前先写两套模板（流式布局和手风琴懒加载）， 根据accordion来判断使用哪套。

